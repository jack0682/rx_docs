use super::*;
#[tonic::async_trait]
impl cell::cell_service_server::CellService for PlatformIngress {
    async fn open(
        &self,
        request: Request<cell::CellHello>,
    ) -> Result<Response<cell::CellSession>, Status> {
        let (fingerprint, principal) = self.certificate(&request)?;
        let hello = request.into_inner();
        if hello.peer_id != principal.as_str()
            || hello.base_manifest_hash != base_hash()
            || hello.cell_manifest_hash != cell_hash()
            || hello.shared_clock_id != self.configuration.installation.clock_id
        {
            return Err(Status::failed_precondition(
                "cell manifest/peer/clock mismatch",
            ));
        }
        let identity = Identity {
            principal: principal.clone(),
            session: id(&hello.base_session_id)?,
            terminal: None,
        };
        let Reply::ServicePeer(peer) = self
            .call(Command::InspectServicePeer(identity.clone()))
            .await?
        else {
            return Err(Status::internal("service peer reply"));
        };
        let definition = digest(&hello.cell_definition_digest)?;
        let command = match peer {
            rx_application::ServicePeer::Host(producer) => {
                if producer.authentication_binding != self.authentication_binding(fingerprint)? {
                    return Err(Status::unauthenticated("session/certificate mismatch"));
                }
                Command::NegotiateEvidenceCell {
                    identity,
                    definition,
                }
            }
            rx_application::ServicePeer::Executor(executor) => {
                if executor.authentication_binding
                    != self.executor_authentication_binding(fingerprint)?
                {
                    return Err(Status::unauthenticated("session/certificate mismatch"));
                }
                Command::NegotiateExecutorCell {
                    identity,
                    definition,
                }
            }
        };
        let Reply::CellName(cell) = self.call(command).await? else {
            return Err(Status::internal("cell negotiation reply"));
        };
        let hash = canonical::digest(
            "RX-CELL-NEGOTIATION-v1",
            &(&hello.base_session_id, cell, definition),
        )
        .map_err(|_| Status::internal("cell negotiation identity"))?;
        let mut bytes = [0; 16];
        bytes.copy_from_slice(&hash.as_bytes()[..16]);
        bytes[6] = (bytes[6] & 15) | 0x80;
        bytes[8] = (bytes[8] & 63) | 0x80;
        Ok(Response::new(cell::CellSession {
            session_id: uuid::Uuid::from_bytes(bytes).to_string(),
            base_session_id: hello.base_session_id,
            peer_id: principal.to_string(),
            manifest_hash: cell_hash(),
        }))
    }

    async fn inspect(
        &self,
        _: Request<cell::CellCall>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn evaluate(
        &self,
        _: Request<cell::EvaluateRequest>,
    ) -> std::result::Result<Response<cell::EvaluationSet>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn start_run(
        &self,
        _: Request<cell::StartRunRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn get_start_attempt(
        &self,
        _: Request<cell::GetStartAttemptRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn begin_part_attempt(
        &self,
        request: Request<cell::BeginPartAttemptRequest>,
    ) -> Result<Response<cell::PartAttempt>, Status> {
        let call = request
            .get_ref()
            .call
            .as_ref()
            .ok_or_else(|| Status::invalid_argument("CellCall required"))?;
        let identity = self
            .validated_executor_identity(&request, call.context.as_ref())
            .await?;
        let value = request.into_inner();
        let call = value
            .call
            .ok_or_else(|| Status::invalid_argument("CellCall required"))?;
        let context = call
            .context
            .ok_or_else(|| Status::invalid_argument("context required"))?;
        if context.expected_revision.is_some()
            || call.expected_cell_revision == Some(0)
            || value.expected_budget_revision == 0
        {
            return Err(Status::invalid_argument("invalid revision placement/value"));
        }
        let key = id(context
            .request_key
            .as_deref()
            .ok_or_else(|| Status::invalid_argument("request key required"))?)?;
        let command = rx_application::BeginPartRequest {
            cell: rx_protocol_adapter::name(&call.cell_id)?,
            run: id(&value.run_id)?,
            mandate: id(&value.mandate_id)?,
            expected_budget: Counter(value.expected_budget_revision),
            expected_cell: call.expected_cell_revision.map(Counter),
        };
        let Reply::PartSnapshot(snapshot) = self
            .call(Command::ExecutorBeginPart {
                identity,
                key,
                command,
            })
            .await?
        else {
            return Err(Status::internal("part reply"));
        };
        let view = rx_protocol_adapter::workflow::part_view(&snapshot);
        rx_protocol::json::to_value(&view)?;
        Ok(Response::new(view))
    }

    async fn submit_operation(
        &self,
        request: Request<cell::SubmitOperationRequest>,
    ) -> Result<Response<base::Receipt>, Status> {
        let call = request
            .get_ref()
            .call
            .as_ref()
            .ok_or_else(|| Status::invalid_argument("CellCall required"))?;
        let identity = self
            .validated_executor_identity(&request, call.context.as_ref())
            .await?;
        let value = request.into_inner();
        let call = value
            .call
            .ok_or_else(|| Status::invalid_argument("CellCall required"))?;
        let context = call
            .context
            .ok_or_else(|| Status::invalid_argument("context required"))?;
        let base_request = value
            .request
            .ok_or_else(|| Status::invalid_argument("SubmitOperation required"))?;
        let nested = base_request
            .context
            .as_ref()
            .ok_or_else(|| Status::invalid_argument("nested context required"))?;
        if nested != &context || context.expected_revision.is_some() {
            return Err(Status::invalid_argument(
                "nested contexts must match; base revision must be absent",
            ));
        }
        let key = id(context
            .request_key
            .as_deref()
            .ok_or_else(|| Status::invalid_argument("request key required"))?)?;
        if value.expected_case_revision.is_some() {
            return Err(Status::failed_precondition(
                "recovery admission is not enabled",
            ));
        }
        let expected_cell = call
            .expected_cell_revision
            .filter(|v| *v > 0)
            .ok_or_else(|| Status::invalid_argument("cell revision required"))?;
        let expected_run = value
            .expected_run_revision
            .filter(|v| *v > 0)
            .ok_or_else(|| Status::invalid_argument("run revision required"))?;
        let Some(cell::permit_parent::Value::MandateId(mandate)) =
            value.parent.and_then(|p| p.value)
        else {
            return Err(Status::failed_precondition(
                "run mandate parent required; recovery binding is not enabled",
            ));
        };
        let intent = rx_protocol::json::intent_to_domain(
            &base_request
                .intent
                .ok_or_else(|| Status::invalid_argument("intent required"))?,
        )?;
        let command = rx_application::ExecutorSubmitRequest {
            cell: rx_protocol_adapter::name(&call.cell_id)?,
            mandate: id(&mandate)?,
            work: rx_application::SubmitWork {
                run: id(base_request
                    .run_id
                    .as_deref()
                    .ok_or_else(|| Status::invalid_argument("run_id required"))?)?,
                activation: id(base_request
                    .activation_id
                    .as_deref()
                    .ok_or_else(|| Status::invalid_argument("activation_id required"))?)?,
                part: value.part_attempt_id.as_deref().map(id).transpose()?,
                slot: rx_protocol_adapter::name(
                    base_request
                        .slot
                        .as_deref()
                        .ok_or_else(|| Status::invalid_argument("slot required"))?,
                )?,
                intent,
                expected_cell: Counter(expected_cell),
                expected_run: Counter(expected_run),
            },
        };
        let Reply::AdmissionReceipt(receipt) = self
            .call(Command::ExecutorSubmit {
                identity,
                key,
                command: Box::new(command),
            })
            .await?
        else {
            return Err(Status::internal("admission reply"));
        };
        let receipt = rx_protocol_adapter::workflow::admission_receipt(&receipt);
        rx_protocol::json::to_value(&receipt)?;
        Ok(Response::new(receipt))
    }

    async fn hold(
        &self,
        _: Request<cell::HoldRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn clear_transient_block(
        &self,
        _: Request<cell::ClearTransientBlockRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn open_case(
        &self,
        _: Request<cell::OpenCaseRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn record_procedure(
        &self,
        _: Request<cell::RecordProcedureRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn set_recovery_plan(
        &self,
        _: Request<cell::SetRecoveryPlanRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn prepare_restart(
        &self,
        _: Request<cell::PrepareRestartRequest>,
    ) -> std::result::Result<Response<cell::RestartPreparation>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn get_restart_preparation(
        &self,
        _: Request<cell::GetRestartPreparationRequest>,
    ) -> std::result::Result<Response<cell::RestartPreparation>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn prepare_close(
        &self,
        _: Request<cell::PrepareCloseRequest>,
    ) -> std::result::Result<Response<cell::Clearance>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn restart_run(
        &self,
        _: Request<cell::RestartRunRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn close_without_restart(
        &self,
        _: Request<cell::CloseWithoutRestartRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn record_change(
        &self,
        _: Request<cell::RecordChangeRequest>,
    ) -> std::result::Result<Response<cell::ChangeRecord>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn register_qualification(
        &self,
        _: Request<cell::RegisterQualificationRequest>,
    ) -> std::result::Result<Response<cell::Qualification>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn get_case(
        &self,
        _: Request<cell::GetCaseRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }

    async fn get_material(
        &self,
        _: Request<cell::GetMaterialRequest>,
    ) -> std::result::Result<Response<cell::MaterialState>, Status> {
        Err(Status::unimplemented(
            "This cell method is not enabled in this binding",
        ))
    }
}
