use axum::{
    Router,
    body::{Body, to_bytes},
    extract::ConnectInfo,
    http::{Request, StatusCode, header},
};
use rx_api::{
    LocalPolicy,
    auth::{Credentials, LocalAccount, password_hash},
    router,
};
use rx_application::*;
use rx_domain::types::*;
mod support;
use rx_runtime::{
    application::{Application, Command, Handle},
    writer::Writer,
};
use rx_storage::SqliteRepository;
use serde_json::{Value, json};
use std::{
    net::SocketAddr,
    sync::{
        Arc, OnceLock,
        atomic::{AtomicU64, Ordering},
    },
};
use support::configuration;
use tower::ServiceExt;

fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
fn id() -> Id {
    Id::new(uuid::Uuid::new_v4().to_string()).unwrap()
}
#[derive(Clone)]
struct ClockSource(Arc<AtomicU64>);
impl Clock for ClockSource {
    fn now(&self) -> TimePoint {
        TimePoint {
            clock_id: "test-clock".into(),
            ticks_ns: Counter(self.0.load(Ordering::SeqCst)),
        }
    }
}
struct Deny;
impl QualificationAuthority for Deny {
    fn verify(&self, _: &CellConfiguration, _: &[ArtifactRef], _: &[Digest]) -> bool {
        false
    }
}
type AppHandle = Handle<Application<SqliteRepository, ClockSource, Deny>>;
struct Fixture {
    _dir: tempfile::TempDir,
    app: Router,
    handle: AppHandle,
    clock: ClockSource,
    admin: Identity,
    reader: Principal,
    configuration: CellConfiguration,
}
fn principal(label: &str, roles: &[Role], cells: &[&str]) -> Principal {
    Principal {
        id: name(label),
        client_namespace: name(&format!("client/{label}")),
        roles: roles.iter().copied().collect(),
        cells: cells.iter().map(|s| name(s)).collect(),
        active: true,
    }
}
fn credentials() -> Credentials {
    static HASH: OnceLock<String> = OnceLock::new();
    let hash = HASH.get_or_init(|| password_hash("test-password-only").unwrap());
    Credentials {
        schema: "rx.local-credentials.v1".into(),
        accounts: ["admin", "reader", "host/sim"]
            .into_iter()
            .map(|p| LocalAccount {
                principal: name(p),
                password_hash: hash.clone(),
            })
            .collect(),
    }
}
async fn fixture() -> Fixture {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("p.db");
    let clock = ClockSource(Arc::new(AtomicU64::new(1000)));
    let engine_clock = clock.clone();
    let reader = principal("reader", &[Role::Observer], &["cell/a"]);
    let setup_reader = reader.clone();
    let cell_config = configuration("cell/a");
    let setup_config = cell_config.clone();
    let admin_session = id();
    let session = admin_session.clone();
    let writer = Writer::start(move || {
        let mut engine = Engine::open(
            SqliteRepository::open(path)?,
            engine_clock,
            Deny,
            id(),
            principal(
                "admin",
                &[
                    Role::AccountAdmin,
                    Role::Engineer,
                    Role::Operator,
                    Role::RecoveryLead,
                    Role::Observer,
                ],
                &["cell/a", "cell/b", "cell/c"],
            ),
        )?;
        engine.authenticated_session(
            &name("admin"),
            session.clone(),
            TimePoint {
                clock_id: "test-clock".into(),
                ticks_ns: Counter(u64::MAX),
            },
        )?;
        let admin = Identity {
            principal: name("admin"),
            session,
            terminal: None,
        };
        engine.put_principal(&admin, setup_reader, None)?;
        engine.put_principal(
            &admin,
            principal("host/sim", &[Role::Host], &["cell/a"]),
            None,
        )?;
        engine.install_cell(&admin, setup_config)?;
        engine.install_cell(&admin, configuration("cell/b"))?;
        Ok(Application::new(engine))
    })
    .await
    .unwrap();
    let handle = Handle::new(writer);
    let app = router(
        Arc::new(handle.clone()),
        credentials(),
        LocalPolicy::new("http://127.0.0.1:8080").unwrap(),
    )
    .unwrap();
    Fixture {
        _dir: dir,
        app,
        handle,
        clock,
        admin: Identity {
            principal: name("admin"),
            session: admin_session,
            terminal: None,
        },
        reader,
        configuration: cell_config,
    }
}
fn request(method: &str, path: &str, cookie: Option<&str>, body: String) -> Request<Body> {
    let mut r = Request::builder()
        .method(method)
        .uri(path)
        .header("host", "127.0.0.1:8080")
        .header("origin", "http://127.0.0.1:8080")
        .header("content-type", "application/json")
        .header("x-rx-client", "browser-v1");
    if let Some(cookie) = cookie {
        r = r.header(header::COOKIE, cookie);
    }
    let mut request = r.body(Body::from(body)).unwrap();
    request.extensions_mut().insert(ConnectInfo(
        "127.0.0.1:40000".parse::<SocketAddr>().unwrap(),
    ));
    request
}
async fn send(app: &Router, r: Request<Body>) -> (StatusCode, Value, Option<String>) {
    let response = app.clone().oneshot(r).await.unwrap();
    let status = response.status();
    assert_eq!(response.headers()[header::CACHE_CONTROL], "no-store");
    let cookie = response
        .headers()
        .get(header::SET_COOKIE)
        .map(|v| v.to_str().unwrap().to_owned());
    let bytes = to_bytes(response.into_body(), 2 * 1024 * 1024)
        .await
        .unwrap();
    let value = serde_json::from_slice(&bytes).unwrap_or(Value::Null);
    (status, value, cookie)
}
async fn login(app: &Router, principal: &str) -> String {
    let (status, profile, cookie) = send(
        app,
        request(
            "POST",
            "/api/v1/session",
            None,
            json!({"principal":principal,"password":"test-password-only"}).to_string(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::OK, "{profile}");
    assert!(profile.get("session").is_none());
    let cookie = cookie.unwrap();
    assert!(cookie.contains("HttpOnly; SameSite=Strict"));
    cookie.split(';').next().unwrap().to_owned()
}

#[tokio::test]
async fn scoped_snapshot_login_logout_and_current_revocation() {
    let f = fixture().await;
    let cookie = login(&f.app, "reader").await;
    let (status, overview, _) = send(
        &f.app,
        request("GET", "/api/v1/overview", Some(&cookie), String::new()),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(overview["cells"].as_array().unwrap().len(), 1);
    assert_eq!(overview["cells"][0]["cell"]["value"]["id"], "cell/a");
    assert!(overview["cells"][0]["cell"]["value"]["qualification"].is_null());
    assert!(!overview.to_string().contains("cell/b"));
    assert!(overview.get("seq").is_none());
    assert_eq!(
        send(
            &f.app,
            request(
                "GET",
                "/api/v1/cell?id=cell%2Fb",
                Some(&cookie),
                String::new()
            )
        )
        .await
        .0,
        StatusCode::FORBIDDEN
    );
    let mut reader = f.reader.clone();
    reader.active = false;
    f.handle
        .call(Command::PutPrincipal {
            identity: f.admin.clone(),
            value: reader,
            expected: Some(Counter(1)),
        })
        .await
        .unwrap();
    assert_eq!(
        send(
            &f.app,
            request("GET", "/api/v1/overview", Some(&cookie), String::new())
        )
        .await
        .0,
        StatusCode::FORBIDDEN
    );
    let admin_cookie = login(&f.app, "admin").await;
    assert_eq!(
        send(
            &f.app,
            request(
                "POST",
                "/api/v1/session/end",
                Some(&admin_cookie),
                "{}".into()
            )
        )
        .await
        .0,
        StatusCode::NO_CONTENT
    );
    assert_eq!(
        send(
            &f.app,
            request(
                "GET",
                "/api/v1/overview",
                Some(&admin_cookie),
                String::new()
            )
        )
        .await
        .0,
        StatusCode::UNAUTHORIZED
    );
    f.handle.close();
    f.handle.closed().await;
}

#[tokio::test]
async fn strict_ingress_and_credentials_never_create_authority_from_headers() {
    let f = fixture().await;
    for principal in ["missing", "admin", "host/sim"] {
        let password = if principal == "host/sim" {
            "test-password-only"
        } else {
            "wrong-password"
        };
        let (status, _, cookie) = send(
            &f.app,
            request(
                "POST",
                "/api/v1/session",
                None,
                json!({"principal":principal,"password":password}).to_string(),
            ),
        )
        .await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);
        assert!(cookie.is_none());
    }
    for body in [
        r#"{"principal":"admin","principal":"reader","password":"test-password-only"}"#,
        r#"{"principal":"admin","password":"test-password-only","roles":["ACCOUNT_ADMIN"]}"#,
    ] {
        assert_eq!(
            send(
                &f.app,
                request("POST", "/api/v1/session", None, body.into())
            )
            .await
            .0,
            StatusCode::BAD_REQUEST
        );
    }
    for field in ["origin", "host", "x-rx-client"] {
        let mut req = request("POST", "/api/v1/session", None, "{}".into());
        req.headers_mut().remove(field);
        assert_eq!(send(&f.app, req).await.0, StatusCode::FORBIDDEN);
    }
    let mut req = request("GET", "/api/v1/health", None, String::new());
    req.extensions_mut().insert(ConnectInfo(
        "192.168.0.1:40000".parse::<SocketAddr>().unwrap(),
    ));
    assert_eq!(send(&f.app, req).await.0, StatusCode::FORBIDDEN);
    let cookie = login(&f.app, "admin").await;
    let duplicate = format!("{cookie}; {cookie}");
    assert_eq!(
        send(
            &f.app,
            request("GET", "/api/v1/overview", Some(&duplicate), String::new())
        )
        .await
        .0,
        StatusCode::UNAUTHORIZED
    );
    f.handle.close();
    f.handle.closed().await;
}

#[tokio::test]
async fn mutations_are_durable_idempotent_and_terminal_bypass_is_rejected() {
    let f = fixture().await;
    let cookie = login(&f.app, "admin").await;
    let payload = json!({"request_key":id(),"command":{
        "cell":"cell/a","recipe_digest":f.configuration.recipe.sha256,
        "site_config_digest":f.configuration.site_config_digest,"expected_cell":"1"}});
    let (status, run, _) = send(
        &f.app,
        request("POST", "/api/v1/runs", Some(&cookie), payload.to_string()),
    )
    .await;
    assert_eq!(status, StatusCode::OK, "{run}");
    let repeated = send(
        &f.app,
        request("POST", "/api/v1/runs", Some(&cookie), payload.to_string()),
    )
    .await;
    assert_eq!(repeated.1, run);
    let mut changed = payload.clone();
    changed["command"]["recipe_digest"] = json!(Digest::from_bytes([99; 32]));
    assert_eq!(
        send(
            &f.app,
            request("POST", "/api/v1/runs", Some(&cookie), changed.to_string())
        )
        .await
        .1["code"],
        "KEY_CONFLICT"
    );
    let mut req=request("POST","/api/v1/runs/start",Some(&cookie),json!({"request_key":id(),"command":{
        "run":run["id"],"envelope_digest":f.configuration.envelope.sha256,"purpose":"PRODUCTION","budget_unit":"PART_ATTEMPT",
        "budget_limit":"2","expected_cell":"1","expected_run":"1"}}).to_string());
    req.headers_mut()
        .insert("x-rx-terminal", "panel/main".parse().unwrap());
    req.headers_mut()
        .insert("x-rx-roles", "OPERATOR".parse().unwrap());
    assert_eq!(send(&f.app, req).await.0, StatusCode::FORBIDDEN);
    let installed = json!({"request_key":id(),"command":configuration("cell/c")});
    assert_eq!(
        send(
            &f.app,
            request(
                "POST",
                "/api/v1/cells",
                Some(&cookie),
                installed.to_string()
            )
        )
        .await
        .1["revision"],
        "1"
    );
    assert_eq!(
        send(
            &f.app,
            request(
                "POST",
                "/api/v1/cells",
                Some(&cookie),
                installed.to_string()
            )
        )
        .await
        .1["revision"],
        "1"
    );
    let hold = json!({"request_key":id(),"command":{"cell":"cell/a"}});
    let first = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cells/hold",
            Some(&cookie),
            hold.to_string(),
        ),
    )
    .await;
    let repeat = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cells/hold",
            Some(&cookie),
            hold.to_string(),
        ),
    )
    .await;
    assert_eq!(first.0, StatusCode::OK);
    assert_eq!(first.1, repeat.1);
    assert_eq!(first.1["epoch"], "2");
    f.handle.close();
    f.handle.closed().await;
}

#[tokio::test]
async fn expired_session_and_stopped_writer_never_return_cached_success() {
    let f = fixture().await;
    let cookie = login(&f.app, "reader").await;
    f.clock.0.store(3_600_000_001_001, Ordering::SeqCst);
    assert_eq!(
        send(
            &f.app,
            request("GET", "/api/v1/overview", Some(&cookie), String::new())
        )
        .await
        .0,
        StatusCode::UNAUTHORIZED
    );
    f.handle.close();
    f.handle.closed().await;
    let reply = send(
        &f.app,
        request("GET", "/api/v1/overview", Some(&cookie), String::new()),
    )
    .await;
    assert_eq!(reply.0, StatusCode::SERVICE_UNAVAILABLE);
    assert_eq!(reply.1["outcome_unknown"], true);
}

#[tokio::test]
async fn actual_tcp_listener_uses_verified_socket_origin_and_real_writer() {
    let f = fixture().await;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let origin = format!("http://{address}");
    let app = router(
        Arc::new(f.handle.clone()),
        credentials(),
        LocalPolicy::new(&origin).unwrap(),
    )
    .unwrap();
    let (stop, done) = tokio::sync::oneshot::channel::<()>();
    let server = tokio::spawn(async move {
        axum::serve(
            listener,
            app.into_make_service_with_connect_info::<SocketAddr>(),
        )
        .with_graceful_shutdown(async {
            let _ = done.await;
        })
        .await
        .unwrap()
    });
    let client = reqwest::Client::new();
    let login = client
        .post(format!("{origin}/api/v1/session"))
        .header("origin", &origin)
        .header("x-rx-client", "browser-v1")
        .json(&json!({"principal":"reader","password":"test-password-only"}))
        .send()
        .await
        .unwrap();
    assert_eq!(login.status(), StatusCode::OK);
    let cookie = login.headers()[header::SET_COOKIE]
        .to_str()
        .unwrap()
        .split(';')
        .next()
        .unwrap()
        .to_owned();
    let response = client
        .get(format!("{origin}/api/v1/overview"))
        .header("cookie", cookie)
        .send()
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::OK);
    let body: Value = response.json().await.unwrap();
    assert_eq!(body["cells"].as_array().unwrap().len(), 1);
    stop.send(()).unwrap();
    server.await.unwrap();
    f.handle.close();
    f.handle.closed().await;
}

#[tokio::test]
async fn checkpoint_wire_and_exact_artifact_are_scoped_to_current_user_access() {
    use sha2::{Digest as _, Sha256};
    let f = fixture().await;
    let cookie = login(&f.app, "admin").await;
    let payload = json!({"request_key":id(),"command":{
        "cell":"cell/a","recipe_digest":f.configuration.recipe.sha256,
        "site_config_digest":f.configuration.site_config_digest,"expected_cell":"1"}});
    let (status, run, _) = send(
        &f.app,
        request("POST", "/api/v1/runs", Some(&cookie), payload.to_string()),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    let run_id = run["id"].as_str().unwrap();
    let path = format!("/api/v1/run/checkpoint?id={run_id}");
    let reader_cookie = login(&f.app, "reader").await;
    let (status, view, _) = send(
        &f.app,
        request("GET", &path, Some(&reader_cookie), String::new()),
    )
    .await;
    assert_eq!(status, StatusCode::OK, "{view}");
    let wire: rx_protocol::base::RunView =
        rx_protocol::json::from_slice(&serde_json::to_vec(&view).unwrap()).unwrap();
    assert_eq!(wire.run_id, run_id);
    assert_eq!(view["state"], "PREPARED");
    assert_eq!(view["revision"], "1");
    assert_eq!(view["checkpoint"]["revision"], "1");
    assert_eq!(view["checkpoint"]["activations"], json!([]));
    assert!(view.get("executor_session_id").is_none());
    let reference = &view["checkpoint"]["payload"];
    let artifact_path = format!(
        "/api/v1/run/checkpoint/artifact?run={run_id}&sha256={}&schema_id={}&size_bytes={}",
        reference["sha256"].as_str().unwrap(),
        reference["schema_id"].as_str().unwrap(),
        reference["size_bytes"].as_str().unwrap()
    );
    let response = f
        .app
        .clone()
        .oneshot(request(
            "GET",
            &artifact_path,
            Some(&reader_cookie),
            String::new(),
        ))
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::OK);
    assert_eq!(response.headers()[header::CONTENT_TYPE], "application/json");
    assert_eq!(response.headers()[header::CACHE_CONTROL], "no-store");
    let bytes = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();
    let digest = Digest::from_bytes(Sha256::digest(&bytes).into());
    assert_eq!(digest.to_string(), reference["sha256"].as_str().unwrap());
    assert_eq!(
        bytes.len().to_string(),
        reference["size_bytes"].as_str().unwrap()
    );
    let state: rx_application::checkpoint_artifact::ExecutorState =
        rx_domain::canonical::decode_json(&bytes).unwrap();
    assert_eq!(state.run.id.to_string(), run_id);
    assert_eq!(state.revision, Counter(1));
    assert_eq!(
        send(&f.app, request("GET", &artifact_path, None, String::new()))
            .await
            .0,
        StatusCode::UNAUTHORIZED
    );
    for malformed in [
        format!("{path}&id={run_id}"),
        format!("{path}&extra=true"),
        artifact_path.replace("size_bytes=", "size_bytes=0"),
    ] {
        assert_eq!(
            send(
                &f.app,
                request("GET", &malformed, Some(&reader_cookie), String::new())
            )
            .await
            .0,
            StatusCode::BAD_REQUEST
        );
    }
    let mut restricted = f.reader.clone();
    restricted.cells.clear();
    f.handle
        .call(Command::PutPrincipal {
            identity: f.admin.clone(),
            value: restricted,
            expected: Some(Counter(1)),
        })
        .await
        .unwrap();
    for restricted_path in [&path, &artifact_path] {
        assert_eq!(
            send(
                &f.app,
                request("GET", restricted_path, Some(&reader_cookie), String::new())
            )
            .await
            .0,
            StatusCode::FORBIDDEN
        );
    }
    f.handle.close();
    f.handle.closed().await;
}

#[tokio::test]
async fn case_acknowledgment_records_reading_without_changing_containment_or_scope() {
    let f = fixture().await;
    let cookie = login(&f.app, "admin").await;
    let body = json!({"request_key":id(),"command":{"cell":"cell/a","kind":"FAULT_RECOVERY","scopes":[],"procedure":{"sha256":"9595959595959595959595959595959595959595959595959595959595959595","schema_id":"rx.test.procedure.v1","size_bytes":"1"},"lead":"admin","operation_ids":[],"material_ids":[]}});
    let (status, opened, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/open",
            Some(&cookie),
            body.to_string(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(opened["case"]["state"], "CONTAINMENT_PENDING");
    let before = send(
        &f.app,
        request("GET", "/api/v1/overview", Some(&cookie), String::new()),
    )
    .await
    .1;
    let command = json!({"request_key":id(),"command":{"cell":"cell/a","case":opened["case"]["id"],"expected_case":opened["revision"],"occurred_at":"2026-09-11T01:02:03Z"}});
    let (status, acked, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/acknowledge",
            Some(&cookie),
            command.to_string(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(acked["snapshot"]["case"]["state"], "CONTAINMENT_PENDING");
    assert_eq!(acked["acknowledgments"].as_array().unwrap().len(), 1);
    let (_, repeated, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/acknowledge",
            Some(&cookie),
            command.to_string(),
        ),
    )
    .await;
    assert_eq!(acked, repeated);
    let after = send(
        &f.app,
        request("GET", "/api/v1/overview", Some(&cookie), String::new()),
    )
    .await
    .1;
    assert_eq!(
        before["cells"][0]["cell"]["value"]["epoch"],
        after["cells"][0]["cell"]["value"]["epoch"]
    );
    assert_eq!(
        before["cells"][0]["cell"]["value"]["blocks"],
        after["cells"][0]["cell"]["value"]["blocks"]
    );
    let reader = login(&f.app, "reader").await;
    let (status, _, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/acknowledge",
            Some(&reader),
            command.to_string(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::FORBIDDEN);
    let (status, list, _) = send(
        &f.app,
        request(
            "GET",
            "/api/v1/cases?cell=cell%2Fa",
            Some(&reader),
            String::new(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(list["cases"].as_array().unwrap().len(), 1);
}

#[tokio::test]
async fn stale_external_procedure_report_returns_its_durable_fact_ids() {
    use rx_application::procedure::*;
    use sha2::Digest as _;
    let f = fixture().await;
    let cookie = login(&f.app, "admin").await;
    let procedure = ArtifactRef {
        sha256: Digest::from_bytes([95; 32]),
        schema_id: name("rx.test.procedure.v1"),
        size_bytes: Counter(1),
    };
    let body = json!({"request_key":id(),"command":{"cell":"cell/a","kind":"DIAGNOSTIC_ONLY","scopes":[],"procedure":procedure,"lead":"admin","operation_ids":[],"material_ids":[]}});
    let (status, opened, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/open",
            Some(&cookie),
            body.to_string(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::OK);
    let case: rx_application::intervention::CaseSnapshot = serde_json::from_value(opened).unwrap();
    let ack = json!({"request_key":id(),"command":{"cell":"cell/a","case":case.case.id,"expected_case":case.revision,"occurred_at":"2026-09-11T01:00:00Z"}});
    assert_eq!(
        send(
            &f.app,
            request(
                "POST",
                "/api/v1/cases/acknowledge",
                Some(&cookie),
                ack.to_string()
            )
        )
        .await
        .0,
        StatusCode::OK
    );
    let assertions = Assertions {
        schema: name("rx.procedure-assertions.v1"),
        case_id: case.case.id.clone(),
        case_revision: case.revision,
        procedure_digest: procedure.sha256,
        actor: name("admin"),
        action: Action::WorkStarted,
        occurred_at: "2026-09-11T01:01:00Z".into(),
        scope_ids: f.configuration.scopes.clone(),
        source: name("admin"),
        physical_claims: vec![Claim {
            subject: name("fixture/material"),
            predicate: name("manual-work"),
            value: TypedValue::Boolean(true),
        }],
        source_event: Some(id()),
        step: Some(name("work-start")),
        people: vec![name("admin")],
        evidence_ids: vec![],
        observed_at: None,
        valid_until: None,
        certainty: Some(Certainty::Unknown),
    };
    let bytes = rx_domain::canonical::bytes(&assertions).unwrap();
    let reference = ArtifactRef {
        sha256: Digest::from_bytes(sha2::Sha256::digest(&bytes).into()),
        schema_id: name("rx.procedure-assertions.v1"),
        size_bytes: Counter(bytes.len() as u64),
    };
    let record = rx_application::procedure::Record {
        id: id(),
        case: case.case.id.clone(),
        case_revision: case.revision,
        action: Action::WorkStarted,
        actor: name("admin"),
        scope_ids: assertions.scope_ids.clone(),
        occurred_at: assertions.occurred_at.clone(),
        evidence_ids: vec![],
        assertions: reference,
    };
    let command = Submission {
        cell: f.configuration.id.clone(),
        expected_cell: Some(Counter(1)),
        expected_case: case.revision,
        record: record.clone(),
        assertions: Some(assertions),
    };
    let body = json!({"request_key":id(),"command":command}).to_string();
    let (status, result, _) = send(
        &f.app,
        request(
            "POST",
            "/api/v1/cases/procedure",
            Some(&cookie),
            body.clone(),
        ),
    )
    .await;
    assert_eq!(status, StatusCode::CONFLICT);
    assert_eq!(result["code"], "STALE_REVISION");
    assert_eq!(result["facts_recorded"], true);
    assert_eq!(result["record_id"], record.id.to_string());
    let repeated = send(
        &f.app,
        request("POST", "/api/v1/cases/procedure", Some(&cookie), body),
    )
    .await;
    assert_eq!(result, repeated.1);
    let detail = send(
        &f.app,
        request(
            "GET",
            &format!("/api/v1/case?cell=cell%2Fa&case={}", case.case.id),
            Some(&cookie),
            String::new(),
        ),
    )
    .await
    .1;
    assert_eq!(detail["procedure_records"].as_array().unwrap().len(), 1);
    assert_eq!(detail["snapshot"]["acknowledgment_count"], "1");
    assert_eq!(detail["snapshot"]["procedure_record_count"], "1");
    assert_eq!(detail["snapshot"]["case"]["state"], "ESCALATED");
}
