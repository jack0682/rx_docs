export class ApiFailure extends Error {
  constructor(
    public code: string,
    public unknownOutcome = false,
    public status = 0,
  ) {
    super(code);
  }
}
export async function api(
  path: string,
  options: { body?: unknown; signal?: AbortSignal } = {},
): Promise<unknown> {
  const mutation = options.body !== undefined;
  let response: Response;
  try {
    response = await fetch(path, {
      method: mutation ? 'POST' : 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: mutation ? { 'Content-Type': 'application/json', 'X-RX-Client': 'browser-v1' } : {},
      body: mutation ? JSON.stringify(options.body) : undefined,
      signal: options.signal ?? AbortSignal.timeout(15000),
      redirect: 'error',
    });
  } catch (error) {
    if (options.signal?.aborted) throw error;
    throw new ApiFailure('CONNECTION_LOST', mutation);
  }
  let result: unknown = null;
  if (response.status !== 204) {
    try {
      result = await response.json();
    } catch {
      throw new ApiFailure('INVALID_RESPONSE', mutation, response.status);
    }
  }
  if (!response.ok) {
    const value = result as { code?: unknown; outcome_unknown?: unknown } | null;
    throw new ApiFailure(
      typeof value?.code === 'string' ? value.code : 'REQUEST_FAILED',
      value?.outcome_unknown === true || (mutation && response.status >= 500),
      response.status,
    );
  }
  return result;
}
const messages: Record<string, string> = {
  UNAUTHENTICATED: '로그인이 필요하거나 세션이 만료되었습니다.',
  FORBIDDEN: '현재 계정 또는 단말에 이 요청의 권한이 없습니다.',
  CONNECTION_LOST: '서버와 연결할 수 없습니다.',
  INVALID_RESPONSE: '응답 형식을 확인할 수 없습니다.',
  STALE_REVISION: '상태나 구성이 변경되었습니다. 최신 상태를 확인한 뒤 다시 요청하세요.',
  KEY_CONFLICT: '같은 요청 번호에 다른 내용이 연결되어 있습니다. 담당자의 확인이 필요합니다.',
  NOT_COMMISSIONED: '현장 검증과 운전 자격 등록이 필요합니다.',
  BUSY: '요청이 많습니다. 잠시 후 다시 시도하세요.',
  INVALID_INPUT: '입력 형식이나 구성 내용을 확인하세요.',
  BLOCKED_BY_CASE: '개입 사유를 해결해야 합니다.',
};
export function explain(error: unknown) {
  if (error instanceof ApiFailure && error.code === 'CONNECTION_LOST' && error.unknownOutcome)
    return '요청 처리 결과를 수신하지 못했습니다.';
  return error instanceof ApiFailure
    ? (messages[error.code] ?? `요청 처리 확인 필요 · ${error.code}`)
    : '표시할 상태를 검증할 수 없습니다.';
}
