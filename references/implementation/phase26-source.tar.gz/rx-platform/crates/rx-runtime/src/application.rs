//! Internal typed writer messages. These are not wire DTOs and do not accept caller roles.
use crate::writer::{Priority, Processor, Writer, WriterError};
use rx_application::{
    projection::{Overview, UserProfile},
    *,
};
use rx_domain::types::*;
use rx_ports::{Repository, StoreError};

pub enum Command {
    PrepareCheckpoint {
        identity: Identity,
        target: CheckpointTarget,
    },
    CommitCheckpoint {
        identity: Identity,
        key: Id,
        command: Box<CommitCheckpoint>,
    },
    RecordReconciliationObservations {
        identity: Identity,
        operation: Id,
        request: Id,
        observations: Vec<HandoverObservation>,
    },
    RequestReconciliation {
        identity: Identity,
        operation: Id,
    },
    PendingReconciliations {
        identity: Identity,
        after: Option<Id>,
        limit: usize,
    },
    PlanReconciliation {
        identity: Identity,
        operation: Id,
        request: Id,
    },
    UpdateReconciliation {
        identity: Identity,
        operation: Id,
        request: Id,
        state: ReconciliationState,
        issue: Option<ReconciliationIssue>,
    },
    PauseExecutorRun {
        identity: Identity,
        key: Id,
        command: PauseRunRequest,
    },
    ExecutionSnapshot {
        identity: Identity,
        run: Id,
        visit: Counter,
    },
    ExecutorArtifact {
        identity: Identity,
        run: Id,
        reference: ArtifactRef,
    },
    ExecutorSubmit {
        identity: Identity,
        key: Id,
        command: Box<ExecutorSubmitRequest>,
    },
    ExecutorWork {
        identity: Identity,
        operation: Id,
    },
    ExecutorBeginPart {
        identity: Identity,
        key: Id,
        command: BeginPartRequest,
    },
    ExecutorResolveActivation {
        identity: Identity,
        key: Id,
        command: ResolveActivationRequest,
    },
    OpenExecutorPeer {
        principal: Name,
        peer_boot: Id,
        authentication_binding: Digest,
    },
    InspectServicePeer(Identity),
    NegotiateExecutorCell {
        identity: Identity,
        definition: Digest,
    },
    ExecutorRunCheckpoint {
        identity: Identity,
        run: Id,
    },
    RunCheckpoint {
        identity: Identity,
        run: Id,
    },
    CheckpointArtifact {
        identity: Identity,
        run: Id,
        reference: ArtifactRef,
    },
    ProcessProgress {
        identity: Identity,
        run: Id,
        visit: Counter,
    },
    ChooseBranch {
        identity: Identity,
        key: Id,
        run: Id,
        node: Name,
        visit: Counter,
        expected_run: Counter,
    },
    StartProcessWait {
        identity: Identity,
        key: Id,
        run: Id,
        node: Name,
        visit: Counter,
        expected_run: Counter,
    },
    CheckProcessWait {
        identity: Identity,
        run: Id,
        node: Name,
        visit: Counter,
        expected_run: Counter,
    },
    PendingDeliveries {
        after: Option<Id>,
        limit: usize,
    },
    PlanDelivery {
        identity: Identity,
        message: Id,
    },
    DeliveryAttention {
        message: Id,
        issue: DeliveryIssue,
    },
    RecordReceipt {
        identity: Identity,
        message: Id,
        receipt: HostReceipt,
    },
    FinishArm {
        identity: Identity,
        message: Id,
        ack: ArmAcknowledgment,
    },
    FinishFence {
        identity: Identity,
        message: Id,
        ack: FenceAcknowledgment,
    },
    ReconciliationWork {
        identity: Identity,
        after: Option<Id>,
        limit: usize,
    },
    InspectWork {
        identity: Identity,
        operation: Id,
    },
    InspectRun {
        identity: Identity,
        run: Id,
    },
    BeginPart {
        identity: Identity,
        key: Id,
        run: Id,
        expected_budget: Counter,
    },
    ResolveActivation {
        identity: Identity,
        run: Id,
        node: Name,
        visit: Counter,
        expected_run: Counter,
    },
    SubmitWork {
        identity: Identity,
        key: Id,
        command: Box<SubmitWork>,
    },
    ReleaseResources {
        identity: Identity,
        key: Id,
        command: ReleaseResources,
    },
    CompletePart {
        identity: Identity,
        key: Id,
        part: Id,
        expected_run: Counter,
    },
    OpenEvidenceProducer {
        principal: Name,
        peer_boot: Id,
        journal: Id,
        authentication_binding: Digest,
    },
    NegotiateEvidenceCell {
        identity: Identity,
        definition: Digest,
    },
    InspectEvidenceProducer(Identity),
    CurrentEvidenceProducer(Name),
    IngestEvidence {
        identity: Identity,
        batch: EvidenceBatch,
    },
    PublishEvidence {
        identity: Identity,
        batch: EvidenceBatch,
    },
    GetNativeEvidence {
        identity: Identity,
        evidence: Id,
    },
    Installation,
    OpenUserSession {
        principal: Name,
        id: Id,
        ttl_ns: Counter,
    },
    UserProfile(Identity),
    EndUserSession(Identity),
    Overview(Identity),
    InspectCell {
        identity: Identity,
        cell: Name,
    },
    InstallCell {
        identity: Identity,
        key: Id,
        configuration: Box<CellConfiguration>,
    },
    PutPrincipal {
        identity: Identity,
        value: Principal,
        expected: Option<Counter>,
    },
    CreateRun {
        identity: Identity,
        key: Id,
        command: CreateRun,
    },
    StartRun {
        identity: Identity,
        key: Id,
        command: StartRun,
    },
    Hold {
        identity: Identity,
        key: Id,
        cell: Name,
    },
}
pub enum Reply {
    CheckpointPreparation(Box<CheckpointPreparation>),
    ReconciliationRequests(Vec<ReconciliationRequest>),
    ReconciliationPlan(Box<ReconciliationPlan>),
    ExecutionSnapshot(Box<ExecutionSnapshot>),
    AdmissionReceipt(AdmissionReceipt),
    PartSnapshot(PartSnapshot),
    ActivationSnapshot(rx_application::checkpoint_artifact::ActivationSnapshot),
    ServicePeer(ServicePeer),
    RunCheckpoint(Box<rx_application::checkpoint_artifact::RunSnapshot>),
    ArtifactBytes(Vec<u8>),
    ProcessProgress(Box<ProcessProgress>),
    BranchChoice(rx_process_contract::frontier::BranchChoice),
    WaitWindow(WaitWindow),
    WaitProgress(Option<rx_process_contract::frontier::WaitProgress>),
    PendingDeliveries(Vec<PendingDelivery>),
    DeliveryPlan(Box<DeliveryPlan>),
    Work(Box<Work>),
    ReconciliationWork(Vec<Work>),
    VersionedRun(Counter, Run),
    Part(PartAttempt),
    Activation(Activation),
    Producer(EvidenceProducer),
    EvidenceCommit(EvidenceCommit),
    NativeEvidence(NativeEvidence),
    CellName(Name),
    Installation(Installation),
    Session(Session),
    Profile(UserProfile),
    Overview(Box<Overview>),
    Cell(Counter, Box<Cell>),
    Run(Run),
    Attempt(StartAttempt),
    Held(Box<Cell>),
    Done,
    Revision(Counter),
}

pub struct Application<R, C, A> {
    engine: Engine<R, C, A>,
}
impl<R, C, A> Application<R, C, A> {
    pub fn new(engine: Engine<R, C, A>) -> Self {
        Self { engine }
    }
}
impl<R: Repository + Send + 'static, C: Clock + 'static, A: QualificationAuthority + 'static>
    Processor for Application<R, C, A>
{
    type Command = Command;
    type Reply = Reply;
    type Error = StoreError;
    fn priority(command: &Command) -> Priority {
        match command {
            Command::PauseExecutorRun { .. }
            | Command::Hold { .. }
            | Command::OpenExecutorPeer { .. }
            | Command::EndUserSession(_)
            | Command::PutPrincipal { .. }
            | Command::DeliveryAttention { .. }
            | Command::FinishFence { .. } => Priority::Control,
            _ => Priority::Normal,
        }
    }
    fn process(&mut self, command: Command) -> rx_ports::Result<Reply> {
        match command {
            Command::PrepareCheckpoint { identity, target } => self
                .engine
                .prepare_process_checkpoint(&identity, target)
                .map(|v| Reply::CheckpointPreparation(Box::new(v))),
            Command::CommitCheckpoint {
                identity,
                key,
                command,
            } => self
                .engine
                .commit_process_checkpoint(&identity, key.as_str(), *command)
                .map(|v| Reply::RunCheckpoint(Box::new(v))),
            Command::RecordReconciliationObservations {
                identity,
                operation,
                request,
                observations,
            } => self
                .engine
                .record_reconciliation_observations(&identity, &operation, &request, &observations)
                .map(|()| Reply::Done),
            Command::RequestReconciliation {
                identity,
                operation,
            } => self
                .engine
                .request_reconciliation(&identity, &operation)
                .map(|w| Reply::Work(Box::new(w))),
            Command::PendingReconciliations {
                identity,
                after,
                limit,
            } => self
                .engine
                .pending_reconciliations(&identity, after.as_ref(), limit)
                .map(Reply::ReconciliationRequests),
            Command::PlanReconciliation {
                identity,
                operation,
                request,
            } => self
                .engine
                .plan_reconciliation(&identity, &operation, &request)
                .map(|p| Reply::ReconciliationPlan(Box::new(p))),
            Command::UpdateReconciliation {
                identity,
                operation,
                request,
                state,
                issue,
            } => self
                .engine
                .update_reconciliation(&identity, &operation, &request, state, issue)
                .map(|()| Reply::Done),
            Command::PauseExecutorRun {
                identity,
                key,
                command,
            } => self
                .engine
                .pause_executor_run(&identity, key.as_str(), command)
                .map(|r| Reply::RunCheckpoint(Box::new(r))),
            Command::ExecutionSnapshot {
                identity,
                run,
                visit,
            } => self
                .engine
                .execution_snapshot(&identity, &run, visit)
                .map(|v| Reply::ExecutionSnapshot(Box::new(v))),
            Command::ExecutorArtifact {
                identity,
                run,
                reference,
            } => self
                .engine
                .executor_artifact(&identity, &run, &reference)
                .map(Reply::ArtifactBytes),
            Command::ExecutorSubmit {
                identity,
                key,
                command,
            } => self
                .engine
                .executor_submit(&identity, key.as_str(), *command)
                .map(Reply::AdmissionReceipt),
            Command::ExecutorWork {
                identity,
                operation,
            } => self
                .engine
                .executor_work(&identity, &operation)
                .map(|w| Reply::Work(Box::new(w))),
            Command::ExecutorBeginPart {
                identity,
                key,
                command,
            } => self
                .engine
                .executor_begin_part(&identity, key.as_str(), command)
                .map(Reply::PartSnapshot),
            Command::ExecutorResolveActivation {
                identity,
                key,
                command,
            } => self
                .engine
                .executor_resolve_activation(&identity, key.as_str(), command)
                .map(Reply::ActivationSnapshot),
            Command::OpenExecutorPeer {
                principal,
                peer_boot,
                authentication_binding,
            } => self
                .engine
                .open_executor_peer(&principal, peer_boot, authentication_binding)
                .map(Reply::Session),
            Command::InspectServicePeer(identity) => self
                .engine
                .inspect_service_peer(&identity)
                .map(Reply::ServicePeer),
            Command::NegotiateExecutorCell {
                identity,
                definition,
            } => self
                .engine
                .negotiate_executor_cell(&identity, definition)
                .map(Reply::CellName),
            Command::ExecutorRunCheckpoint { identity, run } => self
                .engine
                .executor_run_checkpoint(&identity, &run)
                .map(|s| Reply::RunCheckpoint(Box::new(s))),
            Command::RunCheckpoint { identity, run } => self
                .engine
                .run_checkpoint(&identity, &run)
                .map(|snapshot| Reply::RunCheckpoint(Box::new(snapshot))),
            Command::CheckpointArtifact {
                identity,
                run,
                reference,
            } => self
                .engine
                .checkpoint_artifact(&identity, &run, &reference)
                .map(Reply::ArtifactBytes),
            Command::ProcessProgress {
                identity,
                run,
                visit,
            } => self
                .engine
                .process_progress(&identity, &run, visit)
                .map(|progress| Reply::ProcessProgress(Box::new(progress))),
            Command::ChooseBranch {
                identity,
                key,
                run,
                node,
                visit,
                expected_run,
            } => self
                .engine
                .choose_process_branch(&identity, key.as_str(), &run, &node, visit, expected_run)
                .map(Reply::BranchChoice),
            Command::StartProcessWait {
                identity,
                key,
                run,
                node,
                visit,
                expected_run,
            } => self
                .engine
                .start_process_wait(&identity, key.as_str(), &run, &node, visit, expected_run)
                .map(Reply::WaitWindow),
            Command::CheckProcessWait {
                identity,
                run,
                node,
                visit,
                expected_run,
            } => self
                .engine
                .check_process_wait(&identity, &run, &node, visit, expected_run)
                .map(Reply::WaitProgress),
            Command::PendingDeliveries { after, limit } => self
                .engine
                .pending_deliveries_after(after.as_ref(), limit)
                .map(Reply::PendingDeliveries),
            Command::PlanDelivery { identity, message } => self
                .engine
                .plan_delivery(&identity, &message)
                .map(|p| Reply::DeliveryPlan(Box::new(p))),
            Command::DeliveryAttention { message, issue } => self
                .engine
                .note_delivery_attention(&message, issue)
                .map(|()| Reply::Done),
            Command::RecordReceipt {
                identity,
                message,
                receipt,
            } => self
                .engine
                .record_host_receipt(&identity, &message, receipt)
                .map(|w| Reply::Work(Box::new(w))),
            Command::FinishArm {
                identity,
                message,
                ack,
            } => self
                .engine
                .finish_arm_delivery(&identity, &message, ack)
                .map(Reply::Attempt),
            Command::FinishFence {
                identity,
                message,
                ack,
            } => self
                .engine
                .finish_fence_delivery(&identity, &message, ack)
                .map(|()| Reply::Done),
            Command::ReconciliationWork {
                identity,
                after,
                limit,
            } => self
                .engine
                .reconciliation_work(&identity, after.as_ref(), limit)
                .map(Reply::ReconciliationWork),
            Command::InspectWork {
                identity,
                operation,
            } => self
                .engine
                .inspect_work(&identity, &operation)
                .map(|w| Reply::Work(Box::new(w))),
            Command::InspectRun { identity, run } => self
                .engine
                .inspect_run(&identity, &run)
                .map(|(r, v)| Reply::VersionedRun(r, v)),
            Command::BeginPart {
                identity,
                key,
                run,
                expected_budget,
            } => self
                .engine
                .begin_part(&identity, key.as_str(), &run, expected_budget)
                .map(Reply::Part),
            Command::ResolveActivation {
                identity,
                run,
                node,
                visit,
                expected_run,
            } => self
                .engine
                .resolve_activation(&identity, &run, &node, visit, expected_run)
                .map(Reply::Activation),
            Command::SubmitWork {
                identity,
                key,
                command,
            } => self
                .engine
                .submit(&identity, key.as_str(), *command)
                .map(|w| Reply::Work(Box::new(w))),
            Command::ReleaseResources {
                identity,
                key,
                command,
            } => self
                .engine
                .release_resources(&identity, key.as_str(), command)
                .map(|w| Reply::Work(Box::new(w))),
            Command::CompletePart {
                identity,
                key,
                part,
                expected_run,
            } => self
                .engine
                .complete_part(&identity, key.as_str(), &part, expected_run)
                .map(Reply::Part),
            Command::OpenEvidenceProducer {
                principal,
                peer_boot,
                journal,
                authentication_binding,
            } => self
                .engine
                .open_evidence_producer(&principal, peer_boot, journal, authentication_binding)
                .map(Reply::Session),
            Command::NegotiateEvidenceCell {
                identity,
                definition,
            } => self
                .engine
                .negotiate_evidence_cell(&identity, definition)
                .map(Reply::CellName),
            Command::InspectEvidenceProducer(identity) => self
                .engine
                .inspect_evidence_producer(&identity)
                .map(Reply::Producer),
            Command::CurrentEvidenceProducer(principal) => self
                .engine
                .current_evidence_producer(&principal)
                .map(Reply::Producer),
            Command::IngestEvidence { identity, batch } => self
                .engine
                .ingest_evidence_commit(&identity, batch)
                .map(Reply::EvidenceCommit),
            Command::PublishEvidence { identity, batch } => self
                .engine
                .publish_evidence(&identity, batch)
                .map(Reply::EvidenceCommit),
            Command::GetNativeEvidence { identity, evidence } => self
                .engine
                .inspect_native_evidence(&identity, &evidence)
                .map(Reply::NativeEvidence),
            Command::Installation => Ok(Reply::Installation(self.engine.installation.clone())),
            Command::OpenUserSession {
                principal,
                id,
                ttl_ns,
            } => self
                .engine
                .authenticated_user_session(&principal, id, ttl_ns)
                .map(Reply::Session),
            Command::UserProfile(identity) => {
                self.engine.session_profile(&identity).map(Reply::Profile)
            }
            Command::EndUserSession(identity) => self
                .engine
                .end_user_session(&identity)
                .map(|()| Reply::Done),
            Command::Overview(identity) => self
                .engine
                .overview(&identity)
                .map(|v| Reply::Overview(Box::new(v))),
            Command::InspectCell { identity, cell } => self
                .engine
                .inspect_cell(&identity, &cell)
                .map(|(r, v)| Reply::Cell(r, Box::new(v))),
            Command::InstallCell {
                identity,
                key,
                configuration,
            } => self
                .engine
                .install_cell_request(&identity, key.as_str(), *configuration)
                .map(Reply::Revision),
            Command::PutPrincipal {
                identity,
                value,
                expected,
            } => self
                .engine
                .put_principal(&identity, value, expected)
                .map(Reply::Revision),
            Command::CreateRun {
                identity,
                key,
                command,
            } => self
                .engine
                .create_run(&identity, key.as_str(), command)
                .map(Reply::Run),
            Command::StartRun {
                identity,
                key,
                command,
            } => self
                .engine
                .start_run(&identity, key.as_str(), command)
                .map(Reply::Attempt),
            Command::Hold {
                identity,
                key,
                cell,
            } => self
                .engine
                .hold(&identity, key.as_str(), &cell)
                .map(|v| Reply::Held(Box::new(v))),
        }
    }
}

pub type CallResult = Result<Reply, WriterError<StoreError>>;
pub type CallFuture<'a> =
    std::pin::Pin<Box<dyn std::future::Future<Output = CallResult> + Send + 'a>>;
/// Type-erased service boundary; implemented by the actual dedicated writer handle.
pub trait ApplicationPort: Send + Sync {
    fn request(&self, command: Command) -> CallFuture<'_>;
    fn status(&self) -> crate::writer::Status;
}
impl<P: Processor<Command = Command, Reply = Reply, Error = StoreError>> ApplicationPort
    for Handle<P>
{
    fn request(&self, command: Command) -> CallFuture<'_> {
        Box::pin(self.call(command))
    }
    fn status(&self) -> crate::writer::Status {
        self.status()
    }
}

/// The only service-owned access to the application. No repository handle escapes.
pub struct Handle<P: Processor<Command = Command, Reply = Reply, Error = StoreError>>(Writer<P>);
impl<P: Processor<Command = Command, Reply = Reply, Error = StoreError>> Clone for Handle<P> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}
impl<P: Processor<Command = Command, Reply = Reply, Error = StoreError>> Handle<P> {
    pub fn new(writer: Writer<P>) -> Self {
        Self(writer)
    }
    pub async fn call(&self, command: Command) -> Result<Reply, WriterError<StoreError>> {
        self.0.enqueue(command)?.wait().await
    }
    pub fn status(&self) -> crate::writer::Status {
        self.0.status()
    }
    pub fn close(&self) {
        self.0.close()
    }
    pub async fn closed(&self) -> crate::writer::Status {
        self.0.closed().await
    }
}
