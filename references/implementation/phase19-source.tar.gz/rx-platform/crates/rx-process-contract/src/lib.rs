//! Shared declarative process semantics. No BT engine, transport, filesystem or execution authority.
pub mod frontier;
pub mod model;
pub mod validation;
pub use model::*;
