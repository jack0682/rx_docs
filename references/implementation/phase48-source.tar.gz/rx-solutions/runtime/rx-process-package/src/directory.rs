//! Acquire immutable candidate bytes and publish a new directory without replacing an existing artifact.
use crate::{Candidate, Error, Result};
use rx_package::{PackagePath, SignatureEnvelope};
use std::{
    collections::BTreeMap,
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
};
pub fn candidate(path: &Path) -> Result<Candidate> {
    crate::from_files(rx_package::directory::acquire_directory(
        path,
        32,
        4 * 1024 * 1024,
    )?)
}
pub fn publish(
    candidate: &Candidate,
    signature: Option<&SignatureEnvelope>,
    out: &Path,
) -> Result<()> {
    let mut files = candidate.files().clone();
    files.insert(
        PackagePath::new("manifest.json").expect("literal"),
        rx_package::manifest_bytes(candidate.manifest())?,
    );
    if let Some(signature) = signature {
        files.insert(
            PackagePath::new("manifest.sig.json").expect("literal"),
            rx_domain::canonical::bytes(signature).map_err(|e| Error::Invalid(e.to_string()))?,
        );
    }
    publish_files(files, out)
}
pub fn publish_files(files: BTreeMap<PackagePath, Vec<u8>>, out: &Path) -> Result<()> {
    if out.exists() || fs::symlink_metadata(out).is_ok() {
        return Err(Error::Invalid("output already exists".into()));
    }
    let parent = out
        .parent()
        .ok_or_else(|| Error::Invalid("output parent missing".into()))?;
    if !parent.is_dir() {
        return Err(Error::Invalid("output parent must already exist".into()));
    }
    let staging = tempfile::Builder::new()
        .prefix(".rx-package-")
        .tempdir_in(parent)?;
    let mut directories = vec![staging.path().to_path_buf()];
    for (name, bytes) in files {
        let path = staging.path().join(name.as_str());
        let parent = path.parent().expect("package parent");
        fs::create_dir_all(parent)?;
        let mut ancestor = parent;
        while ancestor != staging.path() {
            directories.push(ancestor.to_path_buf());
            ancestor = ancestor.parent().expect("staging ancestor");
        }
        let mut file = OpenOptions::new().write(true).create_new(true).open(path)?;
        file.write_all(&bytes)?;
        file.sync_all()?;
    }
    directories.sort();
    directories.dedup();
    for dir in directories.into_iter().rev() {
        fs::File::open(dir)?.sync_all()?;
    }
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    rustix::fs::renameat_with(
        rustix::fs::CWD,
        staging.path(),
        rustix::fs::CWD,
        out,
        rustix::fs::RenameFlags::NOREPLACE,
    )
    .map_err(std::io::Error::from)?;
    #[cfg(not(any(target_os = "linux", target_os = "macos")))]
    return Err(Error::Invalid(
        "atomic package publication is currently supported on Linux and macOS".into(),
    ));
    fs::File::open(parent)?.sync_all()?;
    Ok(())
}
