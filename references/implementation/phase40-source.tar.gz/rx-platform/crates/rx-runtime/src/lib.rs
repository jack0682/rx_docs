//! Runtime scheduling primitives. Device I/O belongs to outbox consumers, not the state writer.
pub mod application;
pub mod writer;

mod service_health;
