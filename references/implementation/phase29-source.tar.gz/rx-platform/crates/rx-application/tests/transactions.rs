use rx_application::*;
use rx_domain::{condition::Condition, fault::Rejection, intent::*, types::*};
use rx_ports::{Record, Repository, StoreError, StoredEvent};
use rx_storage::SqliteRepository;
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::{
        Arc,
        atomic::{AtomicU8, AtomicU64, Ordering},
    },
};

fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
fn id() -> Id {
    Id::new(uuid::Uuid::now_v7().to_string()).unwrap()
}
fn artifact(n: u8, schema: &str) -> ArtifactRef {
    ArtifactRef {
        sha256: Digest::from_bytes([n; 32]),
        schema_id: name(schema),
        size_bytes: Counter(1),
    }
}
#[derive(Clone)]
struct ManualClock(Arc<AtomicU64>);
impl Clock for ManualClock {
    fn now(&self) -> TimePoint {
        TimePoint {
            clock_id: "test/boottime".into(),
            ticks_ns: Counter(self.0.load(Ordering::SeqCst)),
        }
    }
}
struct SimulationAuthority;
impl QualificationAuthority for SimulationAuthority {
    fn verify(&self, c: &CellConfiguration, e: &[ArtifactRef], d: &[Digest]) -> bool {
        c.environment == Environment::Simulation
            && e == [artifact(9, "rx.validation.simulation.v1")]
            && d.contains(&c.definition.sha256)
            && d.contains(&c.envelope.sha256)
            && d.contains(&c.recipe.sha256)
            && d.contains(&c.site_config_digest)
    }
}
struct FaultRepository {
    inner: SqliteRepository,
    mode: Arc<AtomicU8>,
}
impl Repository for FaultRepository {
    fn pending_outbox_after(
        &mut self,
        after: Option<&Id>,
        limit: usize,
    ) -> rx_ports::Result<Vec<rx_ports::OutboxRecord>> {
        self.inner.pending_outbox_after(after, limit)
    }
    fn control_events_after(
        &mut self,
        after: Counter,
        limit: usize,
    ) -> rx_ports::Result<Vec<StoredEvent>> {
        self.inner.control_events_after(after, limit)
    }
    fn control_snapshot(&mut self) -> rx_ports::Result<(Counter, Vec<Record>)> {
        self.inner.control_snapshot()
    }
    fn journal_head(&mut self) -> rx_ports::Result<Counter> {
        self.inner.journal_head()
    }
    fn pending_outbox(&mut self, limit: usize) -> rx_ports::Result<Vec<rx_ports::OutboxRecord>> {
        self.inner.pending_outbox(limit)
    }
    fn transact<T>(
        &mut self,
        operation: impl FnOnce(&mut dyn rx_ports::Transaction) -> rx_ports::Result<T>,
    ) -> rx_ports::Result<T> {
        let mode = self.mode.swap(0, Ordering::SeqCst);
        let result = self.inner.transact(|tx| {
            let value = operation(tx)?;
            if mode == 1 {
                return Err(StoreError::Unavailable("injected before commit".into()));
            }
            Ok(value)
        })?;
        if mode == 2 {
            return Err(StoreError::Unavailable("committed, response lost".into()));
        }
        Ok(result)
    }
    fn snapshot(&mut self) -> rx_ports::Result<(Counter, Vec<Record>)> {
        self.inner.snapshot()
    }
    fn events_after(&mut self, a: Counter, l: usize) -> rx_ports::Result<Vec<StoredEvent>> {
        self.inner.events_after(a, l)
    }
}
type App = Engine<FaultRepository, ManualClock, SimulationAuthority>;
struct Fixture {
    _directory: tempfile::TempDir,
    app: App,
    clock: ManualClock,
    failure: Arc<AtomicU8>,
    admin: Identity,
    operator: Identity,
    executor: Identity,
    hosts: Vec<Identity>,
    configuration: CellConfiguration,
    registrations: Vec<HostRegistration>,
}
fn principal(label: &str, roles: &[Role]) -> Principal {
    Principal {
        id: name(label),
        client_namespace: name(&format!("client/{label}")),
        roles: roles.iter().copied().collect(),
        cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
        active: true,
    }
}
fn expiry(ticks: u64) -> TimePoint {
    TimePoint {
        clock_id: "test/boottime".into(),
        ticks_ns: Counter(ticks),
    }
}
fn fixture(host_count: usize, qualify: bool) -> Fixture {
    fixture_mode(host_count, qualify, false)
}
fn fixture_mode(host_count: usize, qualify: bool, maintained: bool) -> Fixture {
    fixture_complete(host_count, qualify, maintained, false)
}
fn fixture_complete(
    host_count: usize,
    qualify: bool,
    maintained: bool,
    native_result: bool,
) -> Fixture {
    fixture_with_process(host_count, qualify, maintained, native_result, None)
}
#[derive(Clone, Copy)]
enum TestProcess {
    Branch,
    Wait,
}
fn fixture_with_process(
    host_count: usize,
    qualify: bool,
    maintained: bool,
    native_result: bool,
    process: Option<TestProcess>,
) -> Fixture {
    fixture_with_peer(
        host_count,
        qualify,
        maintained,
        native_result,
        process,
        false,
    )
}
fn fixture_with_peer(
    host_count: usize,
    qualify: bool,
    maintained: bool,
    native_result: bool,
    process: Option<TestProcess>,
    peer_mode: bool,
) -> Fixture {
    let directory = tempfile::tempdir().unwrap();
    let failure = Arc::new(AtomicU8::new(0));
    let repository = FaultRepository {
        inner: SqliteRepository::open(directory.path().join("platform.db")).unwrap(),
        mode: failure.clone(),
    };
    let clock = ManualClock(Arc::new(AtomicU64::new(1000)));
    let admin_p = principal(
        "admin",
        &[
            Role::AccountAdmin,
            Role::Engineer,
            Role::Verifier,
            Role::Observer,
        ],
    );
    let mut app = Engine::open(
        repository,
        clock.clone(),
        SimulationAuthority,
        id(),
        admin_p,
    )
    .unwrap();
    let login = app
        .authenticated_session(&name("admin"), id(), expiry(100000))
        .unwrap();
    let admin = Identity {
        principal: name("admin"),
        session: login.id,
        terminal: None,
    };
    let operator = add_identity(
        &mut app,
        &admin,
        "operator",
        &[Role::Operator, Role::Observer],
    );
    let executor = if peer_mode {
        app.put_principal(
            &admin,
            principal("executor", &[Role::Executor, Role::Observer]),
            None,
        )
        .unwrap();
        let session = app
            .open_executor_peer(&name("executor"), id(), Digest::from_bytes([71; 32]))
            .unwrap();
        Identity {
            principal: name("executor"),
            session: session.id,
            terminal: None,
        }
    } else {
        add_identity(
            &mut app,
            &admin,
            "executor",
            &[Role::Executor, Role::Observer],
        )
    };
    let hosts = (0..host_count)
        .map(|i| add_identity(&mut app, &admin, &format!("host/{i}"), &[Role::Host]))
        .collect::<Vec<_>>();
    let terminal = Terminal {
        id: name("panel/main"),
        certificate_digest: Digest::from_bytes([77; 32]),
        cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
        active: true,
    };
    app.put_terminal(&admin, terminal, None).unwrap();
    let operator = Identity {
        terminal: Some((name("panel/main"), Digest::from_bytes([77; 32]))),
        ..operator
    };
    let condition = Condition::Eq {
        fact: name("ready"),
        schema: name("boolean/v1"),
        unit: name("unitless"),
        expected: TypedValue::Boolean(true),
    };
    let steps: Vec<StepBinding> = (0..host_count)
        .map(|i| StepBinding {
            id: name(&format!("step/{i}")),
            host: name(&format!("host/{i}")),
            intent: Intent {
                kind: Kind::EnsureState,
                target: name(&format!("sim/device-{i}")),
                profile_digest: Digest::from_bytes([21; 32]),
                site_config_digest: Digest::from_bytes([4; 32]),
                calibration_digests: vec![],
                resource_set: vec![name(&format!("controller/{i}"))],
                execution_timeout_ms: Counter(5000),
                prepare_validity_ms: Counter(1000),
                completion_rule: name("sim/closed"),
                cancel_rule: name("sim/stop"),
                body: Body::Predicate(PredicateGoal {
                    predicate_id: name("fixture.closed"),
                    target: TypedValue::Boolean(true),
                    settle_ms: Counter(0),
                }),
            },
            predecessors: vec![],
            conditions: vec![condition.clone()],
            completion: CompletionRule::Unobservable,
            condition_ids: vec![name("sim/ready")],
            condition_revision: Counter(1),
            handover_max_age_ns: Counter(500),
        })
        .collect();
    let mut steps: Vec<StepBinding> = steps;
    if native_result {
        for step in &mut steps {
            step.intent.kind = Kind::FiniteAction;
            step.intent.body = Body::Program(ProgramGoal {
                program: artifact(10, "rx.sim.program.v1"),
                parameter_set: artifact(11, "rx.sim.parameters.v1"),
            });
            step.completion = CompletionRule::Native {
                schema: name("rx.sim.completed.v1"),
                success: vec![Integer(0)],
                failure: vec![Integer(1)],
                postconditions: vec![],
            };
        }
    }
    let configuration = CellConfiguration {
        process: None,
        id: name("cell/a"),
        environment: Environment::Simulation,
        definition: artifact(1, "rx.cell-definition.v1"),
        envelope: artifact(2, "rx.operating-envelope.v1"),
        recipe: artifact(3, "rx.resolved-recipe.v1"),
        site_config_digest: Digest::from_bytes([4; 32]),
        scopes: vec![name("zone/a")],
        hosts: hosts.iter().map(|h| h.principal.clone()).collect(),
        executor: name("executor"),
        maximum_budget: Counter(10),
        permit_ttl_ns: Counter(5000),
        start_timeout_ns: Counter(30000),
        start_conditions: vec![condition.clone()],
        steps,
        maintained_conditions: if maintained { vec![condition] } else { vec![] },
        fact_specs: vec![FactSpec {
            id: name("ready"),
            host: name("host/0"),
            schema: name("boolean/v1"),
            unit: name("unitless"),
            maximum_age_ns: Counter(20000),
            maximum_uncertainty_ns: Counter(0),
        }],
    };
    let configuration = if let Some(kind) = process {
        process_configuration(configuration, kind)
    } else {
        configuration
    };
    app.install_cell(&admin, configuration.clone()).unwrap();
    if peer_mode {
        app.negotiate_executor_cell(&executor, configuration.definition.sha256)
            .unwrap();
    }
    if qualify {
        qualify_cell(&mut app, &admin, &configuration);
    }
    let registrations = register_hosts(&mut app, &hosts, &configuration);
    report_ready(&mut app, &hosts[0], &configuration, &registrations[0]);
    Fixture {
        _directory: directory,
        app,
        clock,
        failure,
        admin,
        operator,
        executor,
        hosts,
        configuration,
        registrations,
    }
}
fn add_identity(app: &mut App, admin: &Identity, label: &str, roles: &[Role]) -> Identity {
    app.put_principal(admin, principal(label, roles), None)
        .unwrap();
    let session = app
        .authenticated_session(&name(label), id(), expiry(100000))
        .unwrap();
    Identity {
        principal: name(label),
        session: session.id,
        terminal: None,
    }
}
fn qualify_cell(app: &mut App, admin: &Identity, c: &CellConfiguration) {
    let rev = app.inspect_cell(admin, &c.id).unwrap().0;
    app.qualify(
        admin,
        &c.id,
        rev,
        vec![artifact(9, "rx.validation.simulation.v1")],
        vec![
            c.definition.sha256,
            c.envelope.sha256,
            c.recipe.sha256,
            c.site_config_digest,
        ],
    )
    .unwrap();
}
fn register_hosts(
    app: &mut App,
    hosts: &[Identity],
    c: &CellConfiguration,
) -> Vec<HostRegistration> {
    let (_, cell) = app.inspect_cell(&hosts[0], &c.id).unwrap();
    hosts
        .iter()
        .map(|h| {
            let r = HostRegistration {
                id: h.principal.clone(),
                session: h.session.clone(),
                boot_id: id(),
                delivery_journal: id(),
                cell: c.id.clone(),
                epoch: cell.epoch,
                scopes: cell.scope_epochs.clone(),
                source_sessions: c
                    .fact_specs
                    .iter()
                    .filter(|spec| spec.host == h.principal)
                    .map(|spec| (spec.id.clone(), id()))
                    .collect(),
                grant: Grant {
                    id: id(),
                    fence: Counter(1),
                    resources: c
                        .steps
                        .iter()
                        .filter(|s| s.host == h.principal)
                        .flat_map(|s| s.intent.resource_set.clone())
                        .collect(),
                    owner: name(app.installation.id.as_str()),
                    valid_until: expiry(50000),
                    ttl_ms: Counter(1),
                },
            };
            app.register_host(h, r.clone()).unwrap();
            r
        })
        .collect()
}
fn report_ready(app: &mut App, host: &Identity, c: &CellConfiguration, r: &HostRegistration) {
    app.report_fact(
        host,
        FactRecord {
            cell: c.id.clone(),
            id: name("ready"),
            source_host: host.principal.clone(),
            source_generation: r.source_sessions[&name("ready")].clone(),
            schema: name("boolean/v1"),
            unit: name("unitless"),
            acquired_at: expiry(1000),
            maximum_age_ns: Counter(20000),
            acquisition_uncertainty_ns: Counter(0),
            quality_good: true,
            origin_age_bounded: true,
            disputed: false,
            value: TypedValue::Boolean(true),
            evidence_id: id(),
        },
    )
    .unwrap();
}
fn create_command(f: &Fixture, revision: Counter) -> CreateRun {
    CreateRun {
        cell: f.configuration.id.clone(),
        recipe_digest: f.configuration.recipe.sha256,
        site_config_digest: f.configuration.site_config_digest,
        expected_cell: revision,
    }
}
fn start_command(f: &Fixture, run: &Run, cell: Counter, limit: u64) -> StartRun {
    StartRun {
        run: run.id.clone(),
        envelope_digest: f.configuration.envelope.sha256,
        purpose: Purpose::Production,
        budget_unit: rx_domain::budget::BudgetUnit::PartAttempt,
        budget_limit: Counter(limit),
        expected_cell: cell,
        expected_run: Counter(1),
    }
}
fn work_command(f: &Fixture, a: &Activation, cr: Counter, rr: Counter) -> SubmitWork {
    SubmitWork {
        run: a.run.clone(),
        activation: a.id.clone(),
        part: a.part.clone(),
        slot: name("main"),
        intent: f.configuration.steps[0].intent.clone(),
        expected_cell: cr,
        expected_run: rr,
    }
}
fn start(f: &mut Fixture, limit: u64) -> Run {
    let cell_revision = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(f, cell_revision))
        .unwrap();
    let attempt = f
        .app
        .start_run(
            &f.operator,
            id().as_str(),
            start_command(f, &run, cell_revision, limit),
        )
        .unwrap();
    for (host, r) in f.hosts.iter().zip(&f.registrations) {
        f.app
            .acknowledge_arm(
                host,
                ArmAcknowledgment {
                    attempt: attempt.id.clone(),
                    host_boot: r.boot_id.clone(),
                    delivery_journal: r.delivery_journal.clone(),
                    sequence: Counter(1),
                    epoch: r.epoch,
                    scopes: r.scopes.clone(),
                },
            )
            .unwrap();
    }
    f.app.inspect_run(&f.operator, &run.id).unwrap().1
}
fn activation(f: &mut Fixture, run: &Run) -> Activation {
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    let rev = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    f.app
        .resolve_activation(&f.executor, &run.id, &name("step/0"), part.ordinal, rev)
        .unwrap()
}
fn submit(f: &mut Fixture, a: &Activation, key: &str) -> rx_ports::Result<Work> {
    let cr = f.app.inspect_cell(&f.executor, &f.configuration.id)?.0;
    let rr = f.app.inspect_run(&f.executor, &a.run)?.0;
    f.app.submit(&f.executor, key, work_command(f, a, cr, rr))
}

#[test]
fn uncommissioned_cell_cannot_start_from_package_presence() {
    let mut f = fixture(1, false);
    let rev = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, rev))
        .unwrap();
    assert!(matches!(
        f.app
            .start_run(&f.operator, id().as_str(), start_command(&f, &run, rev, 1)),
        Err(StoreError::Rejected(Rejection::NotCommissioned))
    ));
}

#[test]
fn start_requires_all_hosts_and_cannot_be_completed_by_partial_ack() {
    let mut f = fixture(2, true);
    let rev = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, rev))
        .unwrap();
    let attempt = f
        .app
        .start_run(&f.operator, id().as_str(), start_command(&f, &run, rev, 1))
        .unwrap();
    let r = &f.registrations[0];
    let partial = f
        .app
        .acknowledge_arm(
            &f.hosts[0],
            ArmAcknowledgment {
                attempt: attempt.id,
                host_boot: r.boot_id.clone(),
                delivery_journal: r.delivery_journal.clone(),
                sequence: Counter(1),
                epoch: r.epoch,
                scopes: r.scopes.clone(),
            },
        )
        .unwrap();
    assert_eq!(partial.status, StartStatus::Arming);
    let run = f.app.inspect_run(&f.operator, &run.id).unwrap().1;
    assert_eq!(run.state, RunState::Prepared);
    assert!(run.mandate.is_none());
}

#[test]
fn unregistered_terminal_cannot_start_even_with_operator_role() {
    let mut f = fixture(1, true);
    let rev = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, rev))
        .unwrap();
    let identity = Identity {
        terminal: None,
        ..f.operator.clone()
    };
    assert!(matches!(
        f.app
            .start_run(&identity, id().as_str(), start_command(&f, &run, rev, 1)),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
}

#[test]
fn same_slot_new_key_and_lost_reply_do_not_create_another_operation() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let key_ = id().to_string();
    let cr = f
        .app
        .inspect_cell(&f.executor, &f.configuration.id)
        .unwrap()
        .0;
    let rr = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, &key_, work_command(&f, &a, cr, rr))
            .is_err()
    );
    let work = submit(&mut f, &a, &key_).unwrap();
    let another = submit(&mut f, &a, id().as_str()).unwrap();
    assert_eq!(work.operation.id(), another.operation.id());
    assert_eq!(
        f.app
            .inspect_run(&f.executor, &run.id)
            .unwrap()
            .1
            .budget
            .as_ref()
            .unwrap()
            .consumed(),
        Counter(1)
    );
}

#[test]
fn changed_intent_under_same_key_is_a_conflict() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let key_ = id().to_string();
    submit(&mut f, &a, &key_).unwrap();
    let mut intent = f.configuration.steps[0].intent.clone();
    intent.execution_timeout_ms = Counter(6000);
    let cr = f
        .app
        .inspect_cell(&f.executor, &f.configuration.id)
        .unwrap()
        .0;
    let rr = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    assert!(matches!(
        f.app.submit(
            &f.executor,
            &key_,
            SubmitWork {
                intent,
                ..work_command(&f, &a, cr, rr)
            }
        ),
        Err(StoreError::KeyConflict)
    ));
}

#[test]
fn t1_failure_rolls_back_slot_resource_permit_and_outbox_together() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let key_ = id().to_string();
    let cr = f
        .app
        .inspect_cell(&f.executor, &f.configuration.id)
        .unwrap()
        .0;
    let rr = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, &key_, work_command(&f, &a, cr, rr))
            .is_err()
    );
    assert!(submit(&mut f, &a, &key_).is_ok());
    let mut repo = f.app.into_repository();
    let rows = repo.snapshot().unwrap().1;
    for schema in [
        "rx.internal.work.v1",
        "rx.internal.permit.v1",
        "rx.internal.resource.v1",
    ] {
        assert_eq!(
            rows.iter()
                .filter(|r| r.document.schema.as_str() == schema)
                .count(),
            1
        );
    }
}

#[test]
fn permit_deadline_cannot_outlive_the_observation_that_supported_it() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    f.clock.0.store(20999, Ordering::SeqCst);
    let work = submit(&mut f, &a, id().as_str()).unwrap();
    let mut repo = f.app.into_repository();
    let row = repo
        .snapshot()
        .unwrap()
        .1
        .into_iter()
        .find(|r| r.document.schema.as_str() == "rx.internal.permit.v1")
        .unwrap();
    let permit: Permit = serde_json::from_value(row.document.value).unwrap();
    assert_eq!(permit.id, work.permit);
    assert_eq!(permit.expires_at.ticks_ns, Counter(21000));
}

#[test]
fn stale_observation_and_wrong_executor_do_not_reach_t1() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let other = add_identity(
        &mut f.app,
        &f.admin,
        "other-executor",
        &[Role::Executor, Role::Observer],
    );
    let cr = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let rr = f.app.inspect_run(&f.operator, &run.id).unwrap().0;
    assert!(matches!(
        f.app
            .submit(&other, id().as_str(), work_command(&f, &a, cr, rr)),
        Err(StoreError::Rejected(Rejection::MandateRevoked))
    ));
    f.clock.0.store(21001, Ordering::SeqCst);
    assert!(matches!(
        submit(&mut f, &a, id().as_str()),
        Err(StoreError::Rejected(Rejection::ConditionUnknown))
    ));
    let mut repo = f.app.into_repository();
    assert!(
        !repo
            .snapshot()
            .unwrap()
            .1
            .iter()
            .any(|r| r.document.schema.as_str() == "rx.internal.work.v1")
    );
}

#[test]
fn role_revocation_is_checked_before_cached_result_lookup() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let key_ = id().to_string();
    submit(&mut f, &a, &key_).unwrap();
    let mut executor = principal("executor", &[Role::Observer]);
    executor.roles = BTreeSet::from([Role::Observer]);
    f.app
        .put_principal(&f.admin, executor, Some(Counter(1)))
        .unwrap();
    let cr = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let rr = f.app.inspect_run(&f.operator, &run.id).unwrap().0;
    assert!(matches!(
        f.app
            .submit(&f.executor, &key_, work_command(&f, &a, cr, rr)),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
}

#[test]
fn restarting_runtime_preserves_consumption_and_revokes_mandate() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 2);
    let _a = activation(&mut f, &run);
    let installation = f.app.installation.id.clone();
    let store_generation = f.app.installation.store_generation.clone();
    let repository = f.app.into_repository();
    let mut app = Engine::open(
        repository,
        f.clock,
        SimulationAuthority,
        installation,
        principal("admin", &[Role::AccountAdmin]),
    )
    .unwrap();
    assert_eq!(app.installation.store_generation, store_generation);
    assert!(matches!(
        app.inspect_run(&f.operator, &run.id),
        Err(StoreError::Rejected(Rejection::Unauthenticated))
    ));
    let new = app
        .authenticated_session(&name("operator"), id(), expiry(100000))
        .unwrap();
    let operator = Identity {
        session: new.id,
        ..f.operator
    };
    let restored = app.inspect_run(&operator, &run.id).unwrap().1;
    assert_eq!(restored.budget.as_ref().unwrap().consumed(), Counter(1));
    assert_eq!(restored.state, RunState::RecoveryRequired);
    let (_, cell) = app.inspect_cell(&operator, &name("cell/a")).unwrap();
    assert_eq!(cell.epoch, Counter(2));
    assert!(!cell.blocks.is_empty());
}

fn add_cell_b(f: &mut Fixture, shared: bool) {
    let mut configuration = f.configuration.clone();
    configuration.id = name("cell/b");
    configuration.scopes = vec![name("zone/b")];
    if !shared {
        configuration.steps[0].intent.resource_set = vec![name("controller/b")];
    }
    f.app.install_cell(&f.admin, configuration.clone()).unwrap();
    qualify_cell(&mut f.app, &f.admin, &configuration);
    let (_, cell) = f.app.inspect_cell(&f.operator, &configuration.id).unwrap();
    let mut registrations = f.registrations.clone();
    for (host, r) in f.hosts.iter().zip(registrations.iter_mut()) {
        r.cell = configuration.id.clone();
        r.epoch = cell.epoch;
        r.scopes = cell.scope_epochs.clone();
        r.grant.resources = configuration
            .steps
            .iter()
            .filter(|s| s.host == host.principal)
            .flat_map(|s| s.intent.resource_set.clone())
            .collect();
        r.grant.id = id();
        f.app.register_host(host, r.clone()).unwrap();
    }
    report_ready(&mut f.app, &f.hosts[0], &configuration, &registrations[0]);
    f.configuration = configuration;
    f.registrations = registrations;
}

#[test]
fn one_physical_resource_is_reserved_across_cells_not_per_cell_alias() {
    let mut f = fixture(1, true);
    let run_a = start(&mut f, 1);
    let a = activation(&mut f, &run_a);
    submit(&mut f, &a, id().as_str()).unwrap();
    add_cell_b(&mut f, true);
    let run_b = start(&mut f, 1);
    let b = activation(&mut f, &run_b);
    assert!(matches!(
        submit(&mut f, &b, id().as_str()),
        Err(StoreError::Rejected(Rejection::Busy))
    ));
}

#[test]
fn hold_propagates_to_shared_resources_and_preserves_independent_cells() {
    for shared in [false, true] {
        let mut f = fixture(1, true);
        let run_a = start(&mut f, 1);
        add_cell_b(&mut f, shared);
        let run_b = start(&mut f, 1);
        f.app
            .hold(&f.operator, id().as_str(), &name("cell/a"))
            .unwrap();
        assert_eq!(
            f.app.inspect_run(&f.operator, &run_a.id).unwrap().1.state,
            RunState::RecoveryRequired
        );
        assert_eq!(
            f.app.inspect_run(&f.operator, &run_b.id).unwrap().1.state,
            if shared {
                RunState::RecoveryRequired
            } else {
                RunState::Executing
            }
        );
    }
}

#[test]
fn hold_proves_unsent_work_not_executed_without_releasing_resource() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let a = activation(&mut f, &run);
    let work = submit(&mut f, &a, id().as_str()).unwrap();
    let key = id().to_string();
    let cell = f.app.hold(&f.operator, &key, &name("cell/a")).unwrap();
    let again = f.app.hold(&f.operator, &key, &name("cell/a")).unwrap();
    assert_eq!(cell.epoch, again.epoch);
    let work = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        work.operation.outcome(),
        rx_domain::operation::Outcome::NotExecuted
    );
    assert_eq!(
        work.operation.disposition(),
        rx_domain::operation::Disposition::Quarantined
    );
}

#[test]
fn pending_start_has_a_deadline_and_key_covers_budget_intent() {
    let mut f = fixture(1, true);
    let cr = f.app.inspect_cell(&f.operator, &name("cell/a")).unwrap().0;
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, cr))
        .unwrap();
    assert!(run.budget.is_none());
    let key = id().to_string();
    let request = start_command(&f, &run, cr, 1);
    let attempt = f.app.start_run(&f.operator, &key, request.clone()).unwrap();
    let changed = StartRun {
        budget_limit: Counter(2),
        ..request.clone()
    };
    assert!(matches!(
        f.app.start_run(&f.operator, &key, changed),
        Err(StoreError::KeyConflict)
    ));
    f.clock.0.store(31001, Ordering::SeqCst);
    let r = &f.registrations[0];
    let result = f
        .app
        .acknowledge_arm(
            &f.hosts[0],
            ArmAcknowledgment {
                attempt: attempt.id,
                host_boot: r.boot_id.clone(),
                delivery_journal: r.delivery_journal.clone(),
                sequence: Counter(1),
                epoch: r.epoch,
                scopes: r.scopes.clone(),
            },
        )
        .unwrap();
    assert_eq!(result.status, StartStatus::Rejected);
    assert_eq!(
        f.app.start_run(&f.operator, &key, request).unwrap().status,
        StartStatus::Rejected
    );
    assert!(
        f.app
            .inspect_run(&f.operator, &run.id)
            .unwrap()
            .1
            .mandate
            .is_none()
    );
}

#[test]
fn activation_visits_are_unique_for_the_whole_run_across_parts() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 2);
    let first = activation(&mut f, &run);
    let current = f.app.inspect_run(&f.executor, &run.id).unwrap().1;
    let second = activation(&mut f, &current);
    assert_eq!(first.visit, Counter(1));
    assert_eq!(second.visit, Counter(2));
    assert_ne!(first.id, second.id);
    let rev = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    let recovered = f
        .app
        .resolve_activation(&f.executor, &run.id, &name("step/0"), Counter(1), rev)
        .unwrap();
    assert_eq!(recovered.id, first.id);
}

#[test]
fn conflicting_observation_is_committed_as_invalidation_even_though_api_rejects_it() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let mut fact = f
        .app
        .inspect_fact(&f.operator, &name("cell/a"), &name("ready"))
        .unwrap();
    fact.value = TypedValue::Boolean(false);
    assert!(matches!(
        f.app.report_fact(&f.hosts[0], fact),
        Err(StoreError::KeyConflict)
    ));
    let (_, cell) = f.app.inspect_cell(&f.operator, &name("cell/a")).unwrap();
    assert!(
        cell.blocks
            .iter()
            .any(|b| b.reason == BlockReason::IntegrityConflict)
    );
    assert_eq!(
        f.app.inspect_run(&f.operator, &run.id).unwrap().1.state,
        RunState::RecoveryRequired
    );
}

#[test]
fn device_generation_change_is_preserved_and_does_not_disappear_on_rejection() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let mut fact = f
        .app
        .inspect_fact(&f.operator, &name("cell/a"), &name("ready"))
        .unwrap();
    fact.evidence_id = id();
    fact.source_generation = id();
    assert!(matches!(
        f.app.report_fact(&f.hosts[0], fact),
        Err(StoreError::Rejected(Rejection::ContinuityUnproven))
    ));
    let (_, cell) = f.app.inspect_cell(&f.operator, &name("cell/a")).unwrap();
    assert!(
        cell.blocks
            .iter()
            .any(|b| b.reason == BlockReason::DeviceRestart)
    );
    assert_eq!(
        f.app.inspect_run(&f.operator, &run.id).unwrap().1.state,
        RunState::RecoveryRequired
    );
}

#[test]
fn maintained_condition_recovery_does_not_revive_an_old_mandate() {
    let mut f = fixture_mode(1, true, true);
    let run = start(&mut f, 1);
    let mut fact = f
        .app
        .inspect_fact(&f.operator, &name("cell/a"), &name("ready"))
        .unwrap();
    fact.evidence_id = id();
    fact.value = TypedValue::Boolean(false);
    f.app.report_fact(&f.hosts[0], fact.clone()).unwrap();
    fact.evidence_id = id();
    fact.value = TypedValue::Boolean(true);
    f.app.report_fact(&f.hosts[0], fact).unwrap();
    assert_eq!(
        f.app.inspect_run(&f.operator, &run.id).unwrap().1.state,
        RunState::RecoveryRequired
    );
    let (_, cell) = f.app.inspect_cell(&f.operator, &name("cell/a")).unwrap();
    assert!(
        cell.blocks
            .iter()
            .any(|b| b.reason == BlockReason::ConditionLost)
    );
}

fn native_started(f: &mut Fixture) -> (Work, NativeEvidence) {
    let run = start(f, 1);
    let a = activation(f, &run);
    let work = submit(f, &a, id().as_str()).unwrap();
    let op = work.operation.id().clone();
    assert!(f.app.begin_delivery(&op).unwrap());
    let invocation = id();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &op,
            HostReceipt {
                operation: op.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation.clone()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(10),
                state: ReceiptState::Prepared,
            },
        )
        .unwrap();
    let next = f
        .app
        .pending_deliveries(128)
        .unwrap()
        .into_iter()
        .find(|d| matches!(d.payload, Delivery::Authorize { .. }))
        .unwrap();
    assert!(f.app.begin_delivery(&next.id).unwrap());
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &next.id,
            HostReceipt {
                operation: op.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation.clone()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(11),
                state: ReceiptState::ResultCaptured,
            },
        )
        .unwrap();
    let evidence = NativeEvidence {
        native_details: None,
        id: id(),
        operation: op,
        invocation,
        profile_digest: work.intent.profile_digest,
        device_session: id(),
        status_schema: name("rx.sim.completed.v1"),
        status: Integer(0),
        captured_at: expiry(1000),
    };
    (work, evidence)
}

#[test]
fn t2_commits_native_evidence_outcome_and_contiguous_cursor_atomically() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = native_started(&mut f);
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .outcome(),
        rx_domain::operation::Outcome::None
    );
    let batch = EvidenceBatch {
        journal: id(),
        first: Counter(1),
        records: vec![evidence],
    };
    let ack = f.app.ingest_evidence(&f.hosts[0], batch.clone()).unwrap();
    assert_eq!(ack.through, Counter(1));
    let done = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        done.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
    assert_eq!(
        done.operation.disposition(),
        rx_domain::operation::Disposition::Held
    );
    let revision = done.operation.revision();
    f.app.ingest_evidence(&f.hosts[0], batch).unwrap();
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .revision(),
        revision
    );
}

#[test]
fn t2_rollback_and_lost_ack_preserve_exactly_one_recorded_result() {
    for failure in [1, 2] {
        let mut f = fixture_complete(1, true, false, true);
        let (work, evidence) = native_started(&mut f);
        let batch = EvidenceBatch {
            journal: id(),
            first: Counter(1),
            records: vec![evidence],
        };
        f.failure.store(failure, Ordering::SeqCst);
        assert!(f.app.ingest_evidence(&f.hosts[0], batch.clone()).is_err());
        assert_eq!(
            f.app.ingest_evidence(&f.hosts[0], batch).unwrap().through,
            Counter(1)
        );
        assert_eq!(
            f.app
                .inspect_work(&f.operator, work.operation.id())
                .unwrap()
                .operation
                .outcome(),
            rx_domain::operation::Outcome::Succeeded
        );
        let mut repo = f.app.into_repository();
        assert_eq!(
            repo.snapshot()
                .unwrap()
                .1
                .iter()
                .filter(|r| r.key.as_str().starts_with("evidence/"))
                .count(),
            1
        );
    }
}

#[test]
fn evidence_gap_is_not_skipped_and_conflicting_sequence_is_quarantined() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = native_started(&mut f);
    let journal = id();
    assert!(
        f.app
            .ingest_evidence(
                &f.hosts[0],
                EvidenceBatch {
                    journal: journal.clone(),
                    first: Counter(2),
                    records: vec![evidence.clone()]
                }
            )
            .is_err()
    );
    let batch = EvidenceBatch {
        journal,
        first: Counter(1),
        records: vec![evidence],
    };
    f.app.ingest_evidence(&f.hosts[0], batch.clone()).unwrap();
    let mut changed = batch;
    changed.records[0].status = Integer(1);
    assert!(f.app.ingest_evidence(&f.hosts[0], changed).is_err());
    let result = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        result.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
    assert_eq!(
        result.operation.integrity(),
        rx_domain::operation::Integrity::Disputed
    );
    assert_eq!(
        result.operation.disposition(),
        rx_domain::operation::Disposition::Quarantined
    );
}

#[test]
fn a_new_contradictory_native_result_preserves_historical_outcome() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = native_started(&mut f);
    let journal = id();
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: journal.clone(),
                first: Counter(1),
                records: vec![evidence.clone()],
            },
        )
        .unwrap();
    let mut late = evidence;
    late.id = id();
    late.status = Integer(1);
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal,
                first: Counter(2),
                records: vec![late],
            },
        )
        .unwrap();
    let result = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        result.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
    assert_eq!(
        result.operation.integrity(),
        rx_domain::operation::Integrity::Disputed
    );
}

#[test]
fn native_receipt_capture_does_not_stand_in_for_completion_policy() {
    let mut f = fixture(1, true);
    let (work, evidence) = native_started(&mut f);
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence],
            },
        )
        .unwrap();
    let result = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        result.operation.outcome(),
        rx_domain::operation::Outcome::None
    );
    assert_eq!(
        result.operation.phase(),
        rx_domain::operation::Phase::Reconciling
    );
}

#[test]
fn changing_evidence_journal_does_not_silently_reset_sequence_history() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = native_started(&mut f);
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence.clone()],
            },
        )
        .unwrap();
    let replacement = EvidenceBatch {
        journal: id(),
        first: Counter(1),
        records: vec![evidence],
    };
    assert!(
        f.app
            .ingest_evidence(&f.hosts[0], replacement.clone())
            .is_err()
    );
    let (_, cell) = f.app.inspect_cell(&f.operator, &name("cell/a")).unwrap();
    assert!(!cell.blocks.is_empty());
    let epoch = cell.epoch;
    assert!(f.app.ingest_evidence(&f.hosts[0], replacement).is_err());
    assert_eq!(
        f.app
            .inspect_cell(&f.operator, &name("cell/a"))
            .unwrap()
            .1
            .epoch,
        epoch
    );
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
}

fn completed_work(f: &mut Fixture) -> (Work, NativeEvidence) {
    let (work, evidence) = native_started(f);
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence.clone()],
            },
        )
        .unwrap();
    (
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap(),
        evidence,
    )
}
fn handover_proof(f: &Fixture, work: &Work, evidence: &NativeEvidence) -> ReleaseResources {
    ReleaseResources {
        operation: work.operation.id().clone(),
        expected_operation: work.operation.revision(),
        expected_cell: Counter(2),
        observations: ["no-pending", "control", "support"]
            .into_iter()
            .map(|predicate| HandoverObservation {
                id: id(),
                operation: work.operation.id().clone(),
                invocation: evidence.invocation.clone(),
                profile_digest: work.intent.profile_digest,
                device_session: evidence.device_session.clone(),
                host_boot: f.registrations[0].boot_id.clone(),
                source: name(&format!("handover/{}/{predicate}", work.operation.id())),
                schema: name("rx.handover.v1"),
                value: true,
                observed_at: expiry(1000),
                uncertainty_ns: Counter(0),
                quality_good: true,
                origin_age_bounded: true,
            })
            .collect(),
    }
}
#[test]
fn resource_release_requires_all_current_handover_facts() {
    for kind in 0..5 {
        let mut f = fixture_complete(1, true, false, true);
        let (work, evidence) = completed_work(&mut f);
        let mut proof = handover_proof(&f, &work, &evidence);
        match kind {
            0 => proof.observations[2].value = false,
            1 => proof.observations[0].host_boot = id(),
            2 => proof.observations[1].device_session = id(),
            3 => {
                proof.observations.pop();
            }
            _ => {
                f.clock.0.store(2000, Ordering::SeqCst);
            }
        }
        assert!(
            f.app
                .release_resources(&f.hosts[0], id().as_str(), proof)
                .is_err()
        );
        assert_eq!(
            f.app
                .inspect_work(&f.operator, work.operation.id())
                .unwrap()
                .operation
                .disposition(),
            rx_domain::operation::Disposition::Held
        );
    }
}
#[test]
fn handover_release_is_atomic_and_duplicate_proof_does_not_release_another_owner() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = completed_work(&mut f);
    let proof = handover_proof(&f, &work, &evidence);
    let key = id().to_string();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .release_resources(&f.hosts[0], &key, proof.clone())
            .is_err()
    );
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .disposition(),
        rx_domain::operation::Disposition::Held
    );
    let released = f
        .app
        .release_resources(&f.hosts[0], &key, proof.clone())
        .unwrap();
    assert_eq!(
        released.operation.disposition(),
        rx_domain::operation::Disposition::Released
    );
    let again = f.app.release_resources(&f.hosts[0], &key, proof).unwrap();
    assert_eq!(released.operation.revision(), again.operation.revision());
}
#[test]
fn part_completion_waits_for_release_and_closes_exhausted_run() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = completed_work(&mut f);
    let revision = f.app.inspect_run(&f.executor, &work.run).unwrap().0;
    assert!(
        f.app
            .complete_part(
                &f.executor,
                id().as_str(),
                work.part.as_ref().unwrap(),
                revision
            )
            .is_err()
    );
    let proof = handover_proof(&f, &work, &evidence);
    f.app
        .release_resources(&f.hosts[0], id().as_str(), proof)
        .unwrap();
    let part = f
        .app
        .complete_part(
            &f.executor,
            id().as_str(),
            work.part.as_ref().unwrap(),
            revision,
        )
        .unwrap();
    assert_eq!(part.disposition, PartDisposition::ConfirmedCompleted);
    assert_eq!(
        f.app.inspect_run(&f.operator, &work.run).unwrap().1.state,
        RunState::Completed
    );
}

#[test]
fn native_metadata_changes_conflict_and_ack_cursor_is_part_of_t2_commit() {
    let mut f = fixture_complete(1, true, false, true);
    let (work, mut evidence) = native_started(&mut f);
    evidence.native_details = Some(NativeEvidenceDetails {
        native_id: Some("vendor-result-1".into()),
        native_data: Some(artifact(66, "vendor/report.v1")),
    });
    let mut batch = EvidenceBatch {
        journal: id(),
        first: Counter(1),
        records: vec![evidence.clone()],
    };
    let commit = f
        .app
        .ingest_evidence_commit(&f.hosts[0], batch.clone())
        .unwrap();
    assert_eq!(commit.installation, f.app.installation.id);
    assert_eq!(commit.store_generation, f.app.installation.store_generation);
    assert!(commit.platform_sequence.0 > 0);
    let recorded = f
        .app
        .inspect_native_evidence(&f.hosts[0], &evidence.id)
        .unwrap();
    assert_eq!(
        recorded
            .native_details
            .as_ref()
            .unwrap()
            .native_id
            .as_deref(),
        Some("vendor-result-1")
    );
    batch.records[0]
        .native_details
        .as_mut()
        .unwrap()
        .native_data = Some(artifact(67, "vendor/report.v1"));
    assert!(f.app.ingest_evidence(&f.hosts[0], batch).is_err());
    let work = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        work.operation.integrity(),
        rx_domain::operation::Integrity::Disputed
    );
    assert_eq!(
        work.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
}

#[test]
fn producer_reconnect_requires_current_identity_and_cell_negotiation() {
    let mut f = fixture(1, true);
    let peer = name("host/0");
    let boot = id();
    let journal = id();
    let binding = Digest::from_bytes([31; 32]);
    let first = f
        .app
        .open_evidence_producer(&peer, boot.clone(), journal.clone(), binding)
        .unwrap();
    let identity = Identity {
        principal: peer.clone(),
        session: first.id.clone(),
        terminal: None,
    };
    let epoch = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1
        .epoch;
    let repeated = f
        .app
        .open_evidence_producer(&peer, boot.clone(), journal.clone(), binding)
        .unwrap();
    assert_eq!(first.id, repeated.id);
    assert_eq!(
        f.app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch,
        epoch
    );
    let probe = EvidenceBatch {
        journal: journal.clone(),
        first: Counter(1),
        records: vec![],
    };
    assert!(matches!(
        f.app.publish_evidence(&identity, probe.clone()),
        Err(StoreError::Rejected(Rejection::CapabilityMissing))
    ));
    f.app
        .negotiate_evidence_cell(&identity, f.configuration.definition.sha256)
        .unwrap();
    let committed = f.app.publish_evidence(&identity, probe.clone()).unwrap();
    assert_eq!(committed.producer.through, Counter(0));
    assert!(committed.platform_sequence.0 > 0);
    let renewed = f
        .app
        .open_evidence_producer(&peer, id(), journal, binding)
        .unwrap();
    assert_ne!(renewed.id, first.id);
    assert!(matches!(
        f.app.publish_evidence(&identity, probe),
        Err(StoreError::Rejected(Rejection::Unauthenticated))
    ));
    assert!(
        f.app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch
            > epoch
    );
}

#[test]
fn control_journal_is_atomic_and_audit_sessions_do_not_advance_its_cursor() {
    use rx_application::control_journal::{CHANGE_SCHEMA, ControlChange, EntityKind};
    let mut f = fixture_complete(1, true, false, true);
    let (work, evidence) = native_started(&mut f);
    let batch = EvidenceBatch {
        journal: id(),
        first: Counter(1),
        records: vec![evidence.clone()],
    };
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .ingest_evidence_commit(&f.hosts[0], batch.clone())
            .is_err()
    );
    let commit = f
        .app
        .ingest_evidence_commit(&f.hosts[0], batch.clone())
        .unwrap();
    let same = f.app.ingest_evidence_commit(&f.hosts[0], batch).unwrap();
    assert_eq!(
        same.platform_sequence, commit.platform_sequence,
        "a duplicate inbox batch cannot invent another control change"
    );
    f.app
        .authenticated_user_session(&name("operator"), id(), Counter(1000))
        .unwrap();
    let mut repository = f.app.into_repository();
    let (through, entities) = repository.control_snapshot().unwrap();
    assert_eq!(through, commit.platform_sequence);
    assert!(repository.journal_head().unwrap() > through);
    let events = repository.control_events_after(Counter(0), 128).unwrap();
    assert_eq!(events.len() as u64, through.0);
    for (index, event) in events.iter().enumerate() {
        assert_eq!(event.seq, Counter(index as u64 + 1));
    }
    let mut observed = 0;
    for event in events {
        let change: ControlChange = rx_application::persistence::decode(
            &Record {
                key: name("event"),
                revision: Counter(1),
                document: event.document,
            },
            CHANGE_SCHEMA,
        )
        .unwrap();
        if change.entity_kind == EntityKind::Work && change.evidence_ids.contains(&evidence.id) {
            observed += 1;
            let result: Work =
                rx_application::persistence::decode(&change.entity, "rx.internal.work.v1").unwrap();
            assert_eq!(result.operation.id(), work.operation.id());
            assert_eq!(
                result.operation.outcome(),
                rx_domain::operation::Outcome::Succeeded
            );
        }
        assert!(!change.entity.document.schema.as_str().contains("session"));
    }
    assert_eq!(observed, 1);
    assert!(
        entities
            .iter()
            .any(|entity| entity.document.schema.as_str() == "rx.internal.work.v1")
    );
}

#[test]
fn direct_state_puts_during_hold_are_captured_at_one_final_transaction_cut() {
    use rx_application::control_journal::{CHANGE_SCHEMA, ControlChange, EntityKind};
    let mut f = fixture_complete(1, true, false, true);
    let (work, _) = native_started(&mut f);
    f.app
        .hold(&f.operator, &id().to_string(), &f.configuration.id)
        .unwrap();
    let mut repository = f.app.into_repository();
    let (head, entities) = repository.control_snapshot().unwrap();
    let events = repository.control_events_after(Counter(0), 128).unwrap();
    let cell = entities
        .iter()
        .find(|row| row.document.schema.as_str() == "rx.internal.cell.v1")
        .unwrap();
    let state: Cell = rx_application::persistence::decode(cell, "rx.internal.cell.v1").unwrap();
    assert!(!state.blocks.is_empty());
    let latest = events
        .iter()
        .rev()
        .find_map(|event| {
            let change: ControlChange = rx_application::persistence::decode(
                &Record {
                    key: name("event"),
                    revision: Counter(1),
                    document: event.document.clone(),
                },
                CHANGE_SCHEMA,
            )
            .unwrap();
            if change.entity_kind == EntityKind::Work {
                Some(change)
            } else {
                None
            }
        })
        .unwrap();
    let stored: Work =
        rx_application::persistence::decode(&latest.entity, "rx.internal.work.v1").unwrap();
    assert_eq!(stored.operation.id(), work.operation.id());
    assert_eq!(
        stored.operation.disposition(),
        rx_domain::operation::Disposition::Quarantined
    );
    assert_eq!(events.last().unwrap().seq, head);
}

#[test]
fn prepared_is_not_an_authorization_ack_and_duplicate_receipts_complete_the_right_message() {
    let mut f = fixture_complete(1, true, false, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let op = work.operation.id().clone();
    let invocation = id();
    let receipt = |seq, state| HostReceipt {
        operation: op.clone(),
        digest: work.intent.digest().unwrap(),
        invocation: Some(invocation.clone()),
        journal: f.registrations[0].delivery_journal.clone(),
        sequence: Counter(seq),
        state,
    };
    f.app.begin_delivery(&op).unwrap();
    f.app
        .record_host_receipt(&f.hosts[0], &op, receipt(10, ReceiptState::Prepared))
        .unwrap();
    let authorization = rx_application::engine::authorization_delivery_id(&op);
    f.app.begin_delivery(&authorization).unwrap();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &authorization,
            receipt(11, ReceiptState::Prepared),
        )
        .unwrap();
    assert!(
        f.app
            .pending_deliveries(128)
            .unwrap()
            .iter()
            .any(|d| d.id == authorization)
    );
    let sent = receipt(12, ReceiptState::SendEntered);
    f.app
        .record_host_receipt(&f.hosts[0], &op, sent.clone())
        .unwrap();
    f.app
        .record_host_receipt(&f.hosts[0], &authorization, sent.clone())
        .unwrap();
    assert!(
        !f.app
            .pending_deliveries(128)
            .unwrap()
            .iter()
            .any(|d| d.id == authorization)
    );
    assert!(f.app.record_host_receipt(&f.hosts[0], &id(), sent).is_err());
    assert_eq!(
        f.app
            .inspect_work(&f.operator, &op)
            .unwrap()
            .operation
            .outcome(),
        rx_domain::operation::Outcome::None
    );
}

#[test]
fn an_entered_send_with_no_remote_receipt_remains_unknown_and_is_not_reissued() {
    let mut f = fixture_complete(1, true, false, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let first = f
        .app
        .plan_delivery(&f.hosts[0], work.operation.id())
        .unwrap();
    assert!(first.first_emission);
    f.app
        .note_delivery_attention(work.operation.id(), DeliveryIssue::RemoteNotFound)
        .unwrap();
    let repeated = f
        .app
        .plan_delivery(&f.hosts[0], work.operation.id())
        .unwrap();
    assert!(!repeated.first_emission);
    let current = f
        .app
        .inspect_work(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        current.operation.knowledge(),
        rx_domain::operation::Knowledge::Unknown
    );
    assert_eq!(
        current.operation.outcome(),
        rx_domain::operation::Outcome::None
    );
    assert_eq!(
        current.operation.disposition(),
        rx_domain::operation::Disposition::Quarantined
    );
}

#[test]
fn early_native_evidence_is_reapplied_when_the_receipt_establishes_correlation() {
    let mut f = fixture_complete(1, true, false, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    f.app.begin_delivery(work.operation.id()).unwrap();
    let invocation = id();
    let evidence = NativeEvidence {
        native_details: None,
        id: id(),
        operation: work.operation.id().clone(),
        invocation: invocation.clone(),
        profile_digest: work.intent.profile_digest,
        device_session: id(),
        status_schema: name("rx.sim.completed.v1"),
        status: Integer(0),
        captured_at: expiry(1000),
    };
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence.clone()],
            },
        )
        .unwrap();
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .outcome(),
        rx_domain::operation::Outcome::None
    );
    let result = f
        .app
        .record_host_receipt(
            &f.hosts[0],
            work.operation.id(),
            HostReceipt {
                operation: work.operation.id().clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(10),
                state: ReceiptState::Prepared,
            },
        )
        .unwrap();
    assert_eq!(
        result.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
    assert!(result.operation.evidence_ids().contains(&evidence.id));
    assert_eq!(
        f.app
            .inspect_permit(&f.operator, &work.permit)
            .unwrap()
            .state,
        PermitState::Consumed
    );
    assert!(
        !f.app
            .pending_deliveries(128)
            .unwrap()
            .iter()
            .any(|row| matches!(row.payload, Delivery::Authorize { .. }))
    );
}

fn process_configuration(
    mut configuration: CellConfiguration,
    kind: TestProcess,
) -> CellConfiguration {
    use rx_process_contract::*;
    let process = name("test/process");
    let make = |label: &str, body: CompiledBody| {
        let source = SourceLocation {
            flow: name("main"),
            node: name(label),
            instantiation: vec![],
        };
        let digest =
            rx_domain::canonical::digest("RX-PROCESS-NODE-v1", &(&process, &source)).unwrap();
        CompiledNode {
            id: name(&format!("node/{digest}")),
            source,
            body,
        }
    };
    let left = make(
        "left",
        CompiledBody::Operation {
            binding: name("left"),
        },
    );
    let right = make(
        "right",
        CompiledBody::Operation {
            binding: name("right"),
        },
    );
    let original = configuration.steps[0].clone();
    let mut alternative = original.clone();
    alternative.intent.target = name("sim/device-alternative");
    alternative.intent.resource_set = vec![name("controller/alternative")];
    let mut bindings = BTreeMap::from([(
        name("left"),
        ActionBinding {
            host: original.host.clone(),
            intent: original.intent.clone(),
        },
    )]);
    let root = match kind {
        TestProcess::Branch => {
            bindings.insert(
                name("right"),
                ActionBinding {
                    host: alternative.host.clone(),
                    intent: alternative.intent.clone(),
                },
            );
            configuration.steps = vec![
                StepBinding {
                    id: left.id.clone(),
                    ..original
                },
                StepBinding {
                    id: right.id.clone(),
                    ..alternative
                },
            ];
            make(
                "branch",
                CompiledBody::Branch {
                    condition: name("select"),
                    when_true: Box::new(left),
                    when_false: Box::new(right),
                },
            )
        }
        TestProcess::Wait => {
            configuration.steps = vec![StepBinding {
                id: left.id.clone(),
                ..original
            }];
            let wait = make(
                "wait",
                CompiledBody::Wait {
                    condition: name("select"),
                    timeout_ns: Counter(500),
                },
            );
            make(
                "sequence",
                CompiledBody::Sequence {
                    children: vec![wait, left],
                },
            )
        }
    };
    configuration.fact_specs.push(FactSpec {
        id: name("select"),
        host: configuration.hosts[0].clone(),
        schema: name("boolean/v1"),
        unit: name("unitless"),
        maximum_age_ns: Counter(20000),
        maximum_uncertainty_ns: Counter(0),
    });
    let resolved = ResolvedProcess {
        schema: name("rx.resolved-process.v1"),
        package_digest: None,
        source_digest: Digest::from_bytes([81; 32]),
        process,
        root,
        bindings,
        conditions: BTreeMap::from([(
            name("select"),
            Condition::Eq {
                fact: name("select"),
                schema: name("boolean/v1"),
                unit: name("unitless"),
                expected: TypedValue::Boolean(true),
            },
        )]),
    };
    configuration.recipe = ArtifactRef {
        sha256: rx_process_contract::frontier::resolved_digest(&resolved).unwrap(),
        schema_id: resolved.schema.clone(),
        size_bytes: Counter(rx_domain::canonical::bytes(&resolved).unwrap().len() as u64),
    };
    configuration.process = Some(Box::new(resolved));
    configuration
}
fn report_select(f: &mut Fixture, value: bool) {
    let mut fact = f
        .app
        .inspect_fact(&f.operator, &f.configuration.id, &name("ready"))
        .unwrap();
    fact.id = name("select");
    fact.source_generation = f.registrations[0].source_sessions[&name("select")].clone();
    fact.evidence_id = id();
    fact.value = TypedValue::Boolean(value);
    f.app.report_fact(&f.hosts[0], fact).unwrap();
}

#[test]
fn p_commits_branch_choice_and_rejects_the_untaken_activation() {
    let mut f = fixture_with_process(1, true, false, true, Some(TestProcess::Branch));
    let run = start(&mut f, 1);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    let root = f.configuration.process.as_ref().unwrap().root.id.clone();
    let left = f.configuration.steps[0].id.clone();
    let right = f.configuration.steps[1].id.clone();
    let rev = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    assert!(
        f.app
            .resolve_activation(&f.executor, &run.id, &left, part.ordinal, rev)
            .is_err()
    );
    assert!(
        f.app
            .choose_process_branch(
                &f.executor,
                id().as_str(),
                &run.id,
                &root,
                part.ordinal,
                rev
            )
            .is_err()
    );
    report_select(&mut f, true);
    let key_ = id();
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .choose_process_branch(
                &f.executor,
                key_.as_str(),
                &run.id,
                &root,
                part.ordinal,
                rev
            )
            .is_err()
    );
    let choice = f
        .app
        .choose_process_branch(
            &f.executor,
            key_.as_str(),
            &run.id,
            &root,
            part.ordinal,
            rev,
        )
        .unwrap();
    assert!(choice.chosen);
    report_select(&mut f, false);
    let repeated = f
        .app
        .choose_process_branch(
            &f.executor,
            id().as_str(),
            &run.id,
            &root,
            part.ordinal,
            rev,
        )
        .unwrap();
    assert_eq!(choice.decision, repeated.decision);
    let progress = f
        .app
        .process_progress(&f.executor, &run.id, part.ordinal)
        .unwrap();
    assert_eq!(progress.frontier.operations, vec![left.clone()]);
    assert!(
        f.app
            .resolve_activation(
                &f.executor,
                &run.id,
                &right,
                part.ordinal,
                progress.run_revision
            )
            .is_err()
    );
    let activation = f
        .app
        .resolve_activation(
            &f.executor,
            &run.id,
            &left,
            part.ordinal,
            progress.run_revision,
        )
        .unwrap();
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    assert_eq!(
        work.intent.digest().unwrap(),
        f.configuration.steps[0].intent.digest().unwrap()
    );
    let current = f
        .app
        .process_progress(&f.executor, &run.id, part.ordinal)
        .unwrap();
    assert!(current.frontier.operations.is_empty());
}

#[test]
fn wait_deadline_and_success_are_decided_by_p_and_cannot_be_reset_by_retries() {
    for satisfied in [true, false] {
        let mut f = fixture_with_process(1, true, false, true, Some(TestProcess::Wait));
        let run = start(&mut f, 1);
        let part = f
            .app
            .begin_part(
                &f.executor,
                id().as_str(),
                &run.id,
                run.budget.as_ref().unwrap().revision(),
            )
            .unwrap();
        let wait =
            rx_process_contract::validation::nodes(f.configuration.process.as_ref().unwrap())
                .into_iter()
                .find(|node| matches!(node.body, rx_process_contract::CompiledBody::Wait { .. }))
                .unwrap()
                .id
                .clone();
        let rev = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
        let window = f
            .app
            .start_process_wait(
                &f.executor,
                id().as_str(),
                &run.id,
                &wait,
                part.ordinal,
                rev,
            )
            .unwrap();
        f.clock.0.store(1200, Ordering::SeqCst);
        let same = f
            .app
            .start_process_wait(
                &f.executor,
                id().as_str(),
                &run.id,
                &wait,
                part.ordinal,
                rev,
            )
            .unwrap();
        assert_eq!(window.id, same.id);
        assert_eq!(window.expires_at, same.expires_at);
        let progress = f
            .app
            .process_progress(&f.executor, &run.id, part.ordinal)
            .unwrap();
        assert!(
            f.app
                .check_process_wait(
                    &f.executor,
                    &run.id,
                    &wait,
                    part.ordinal,
                    progress.run_revision
                )
                .unwrap()
                .is_none()
        );
        if satisfied {
            report_select(&mut f, true);
        } else {
            f.clock.0.store(1500, Ordering::SeqCst);
        }
        let result = f
            .app
            .check_process_wait(
                &f.executor,
                &run.id,
                &wait,
                part.ordinal,
                progress.run_revision,
            )
            .unwrap()
            .unwrap();
        assert_eq!(
            matches!(
                result,
                rx_process_contract::frontier::WaitProgress::Satisfied { .. }
            ),
            satisfied
        );
        let progress = f
            .app
            .process_progress(&f.executor, &run.id, part.ordinal)
            .unwrap();
        if satisfied {
            assert_eq!(
                progress.frontier.operations,
                vec![f.configuration.steps[0].id.clone()]
            );
        } else {
            assert_eq!(
                progress.frontier.state,
                rx_process_contract::frontier::State::Failed
            );
            assert!(progress.frontier.operations.is_empty());
        }
    }
}

#[test]
fn resolved_plan_binding_and_digest_cannot_be_substituted_in_cell_configuration() {
    let mut f = fixture(1, false);
    let mut configuration = process_configuration(f.configuration.clone(), TestProcess::Branch);
    configuration.id = name("cell/b");
    configuration.steps[0].intent.target = name("unapproved/target");
    assert!(f.app.install_cell(&f.admin, configuration).is_err());
}

#[test]
fn process_checkpoint_survives_runtime_restart_without_restoring_execution_authority() {
    let mut f = fixture_with_process(1, true, false, true, Some(TestProcess::Branch));
    let run = start(&mut f, 1);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    report_select(&mut f, true);
    let branch = f.configuration.process.as_ref().unwrap().root.id.clone();
    let revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    let choice = f
        .app
        .choose_process_branch(
            &f.executor,
            id().as_str(),
            &run.id,
            &branch,
            part.ordinal,
            revision,
        )
        .unwrap();
    let saved = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
    let saved_bytes = f
        .app
        .checkpoint_artifact(&f.executor, &run.id, &saved.checkpoint.payload)
        .unwrap();
    let state: checkpoint_artifact::ExecutorState =
        rx_domain::canonical::decode_json(&saved_bytes).unwrap();
    assert_eq!(state.process_checkpoints.len(), 1);
    assert_eq!(
        state.process_checkpoints[0].branches[&branch].decision,
        choice.decision
    );
    assert_eq!(state.revision, saved.revision);
    let installation = f.app.installation.id.clone();
    let repository = f.app.into_repository();
    let mut reopened = Engine::open(
        repository,
        f.clock.clone(),
        SimulationAuthority,
        installation,
        principal("unused", &[Role::AccountAdmin]),
    )
    .unwrap();
    let login = reopened
        .authenticated_session(&name("executor"), id(), expiry(100000))
        .unwrap();
    let executor = Identity {
        principal: name("executor"),
        session: login.id,
        terminal: None,
    };
    let progress = reopened
        .process_progress(&executor, &run.id, part.ordinal)
        .unwrap();
    assert_eq!(
        progress.checkpoint.branches[&branch].decision,
        choice.decision
    );
    assert!(
        progress
            .checkpoint
            .decision_times
            .contains_key(&choice.decision)
    );
    assert!(!progress.admission_allowed);
    assert_eq!(
        reopened
            .checkpoint_artifact(&executor, &run.id, &saved.checkpoint.payload)
            .unwrap(),
        saved_bytes
    );
    let current = reopened.run_checkpoint(&executor, &run.id).unwrap();
    assert_ne!(
        current.checkpoint.payload.sha256,
        saved.checkpoint.payload.sha256
    );
    assert_eq!(current.run.state, RunState::RecoveryRequired);
    let current_bytes = reopened
        .checkpoint_artifact(&executor, &run.id, &current.checkpoint.payload)
        .unwrap();
    let current_state: checkpoint_artifact::ExecutorState =
        rx_domain::canonical::decode_json(&current_bytes).unwrap();
    assert_eq!(
        current_state.process_checkpoints[0].branches[&branch].decision,
        choice.decision
    );
    assert_eq!(
        reopened.inspect_run(&executor, &run.id).unwrap().1.state,
        RunState::RecoveryRequired
    );
    assert!(
        reopened
            .resolve_activation(
                &executor,
                &run.id,
                &f.configuration.steps[0].id,
                part.ordinal,
                progress.run_revision
            )
            .is_err()
    );
}

#[test]
fn part_completion_requires_only_the_committed_branch_and_its_real_release_proof() {
    let mut f = fixture_with_process(1, true, false, true, Some(TestProcess::Branch));
    let run = start(&mut f, 1);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    report_select(&mut f, true);
    let branch = f.configuration.process.as_ref().unwrap().root.id.clone();
    let rev = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    f.app
        .choose_process_branch(
            &f.executor,
            id().as_str(),
            &run.id,
            &branch,
            part.ordinal,
            rev,
        )
        .unwrap();
    let progress = f
        .app
        .process_progress(&f.executor, &run.id, part.ordinal)
        .unwrap();
    let selected = progress.frontier.operations[0].clone();
    let activation = f
        .app
        .resolve_activation(
            &f.executor,
            &run.id,
            &selected,
            part.ordinal,
            progress.run_revision,
        )
        .unwrap();
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let op = work.operation.id().clone();
    let invocation = id();
    f.app.begin_delivery(&op).unwrap();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &op,
            HostReceipt {
                operation: op.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation.clone()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(10),
                state: ReceiptState::Prepared,
            },
        )
        .unwrap();
    let authorization = rx_application::engine::authorization_delivery_id(&op);
    f.app.begin_delivery(&authorization).unwrap();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &authorization,
            HostReceipt {
                operation: op.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation.clone()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(11),
                state: ReceiptState::ResultCaptured,
            },
        )
        .unwrap();
    let evidence = NativeEvidence {
        native_details: None,
        id: id(),
        operation: op.clone(),
        invocation,
        profile_digest: work.intent.profile_digest,
        device_session: id(),
        status_schema: name("rx.sim.completed.v1"),
        status: Integer(0),
        captured_at: expiry(1000),
    };
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence.clone()],
            },
        )
        .unwrap();
    let revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    assert!(
        f.app
            .complete_part(&f.executor, id().as_str(), &part.id, revision)
            .is_err()
    );
    let completed = f.app.inspect_work(&f.operator, &op).unwrap();
    let proof = handover_proof(&f, &completed, &evidence);
    f.app
        .release_resources(&f.hosts[0], id().as_str(), proof)
        .unwrap();
    let done = f
        .app
        .complete_part(&f.executor, id().as_str(), &part.id, revision)
        .unwrap();
    assert_eq!(done.disposition, PartDisposition::ConfirmedCompleted);
    assert_eq!(
        f.app.inspect_run(&f.operator, &run.id).unwrap().1.state,
        RunState::Completed
    );
}

#[test]
fn checkpoint_artifact_and_run_projection_commit_with_slot_or_roll_back_together() {
    use rx_application::checkpoint_artifact::{ExecutorState, RUN_SNAPSHOT, RunSnapshot, SCHEMA};
    use rx_domain::canonical;
    use sha2::{Digest as _, Sha256};
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let before = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
    let original = f
        .app
        .checkpoint_artifact(&f.executor, &run.id, &before.checkpoint.payload)
        .unwrap();
    assert_eq!(before.checkpoint.activations.len(), 1);
    assert!(before.checkpoint.activations[0].slots.is_empty());
    assert_eq!(before.revision, before.checkpoint.revision);
    assert_eq!(before.checkpoint.payload.schema_id.as_str(), SCHEMA);
    assert_eq!(
        before.checkpoint.payload.sha256,
        Digest::from_bytes(Sha256::digest(&original).into())
    );
    assert_eq!(
        before.checkpoint.payload.size_bytes.0,
        original.len() as u64
    );
    let cr = f
        .app
        .inspect_cell(&f.executor, &f.configuration.id)
        .unwrap()
        .0;
    let command = work_command(&f, &activation, cr, before.revision);
    let request_key = id();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, request_key.as_str(), command.clone())
            .is_err()
    );
    let rolled_back = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
    assert_eq!(
        canonical::bytes(&rolled_back).unwrap(),
        canonical::bytes(&before).unwrap()
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, request_key.as_str(), command.clone())
            .is_err()
    );
    let work = f
        .app
        .submit(&f.executor, request_key.as_str(), command)
        .unwrap();
    let after = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
    let bytes = f
        .app
        .checkpoint_artifact(&f.executor, &run.id, &after.checkpoint.payload)
        .unwrap();
    let state: ExecutorState = canonical::decode_json(&bytes).unwrap();
    assert_eq!(after.revision, before.revision.increment().unwrap());
    assert_eq!(state.revision, after.revision);
    assert_eq!(state.run.id, run.id);
    assert_eq!(state.activations[0].id, activation.id);
    let slot = &state.activations[0].slots[0];
    assert_eq!(&slot.operation, work.operation.id());
    assert_eq!(slot.intent_digest, work.intent.digest().unwrap());
    assert_eq!(slot.slot, name("main"));
    assert_eq!(
        canonical::bytes(&state.activations).unwrap(),
        canonical::bytes(&after.checkpoint.activations).unwrap()
    );
    assert_ne!(
        after.checkpoint.payload.sha256,
        before.checkpoint.payload.sha256
    );
    assert_eq!(
        f.app
            .checkpoint_artifact(&f.executor, &run.id, &before.checkpoint.payload)
            .unwrap(),
        original
    );
    let mut repo = f.app.into_repository();
    let (_, projections) = repo.control_snapshot().unwrap();
    let stored: RunSnapshot = projections
        .into_iter()
        .filter(|r| r.document.schema.as_str() == RUN_SNAPSHOT)
        .map(|r| serde_json::from_value::<RunSnapshot>(r.document.value).unwrap())
        .find(|r| r.run.id == run.id)
        .unwrap();
    assert_eq!(
        canonical::bytes(&stored).unwrap(),
        canonical::bytes(&after).unwrap()
    );
    let (_, rows) = repo.snapshot().unwrap();
    let artifacts: Vec<ExecutorState> = rows
        .into_iter()
        .filter(|r| r.document.schema.as_str() == SCHEMA)
        .map(|r| serde_json::from_value(r.document.value).unwrap())
        .collect();
    assert_eq!(
        artifacts
            .iter()
            .filter(|r| r.run.id == run.id && r.revision == after.revision)
            .count(),
        1
    );
}

#[test]
fn checkpoint_artifact_requires_current_run_scope_and_exact_owned_reference() {
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let snapshot = f.app.run_checkpoint(&f.operator, &run.id).unwrap();
    let mut wrong = snapshot.checkpoint.payload.clone();
    wrong.size_bytes = wrong.size_bytes.increment().unwrap();
    assert!(matches!(
        f.app.checkpoint_artifact(&f.operator, &run.id, &wrong),
        Err(StoreError::Invalid(_))
    ));
    let revision = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .0;
    let another = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, revision))
        .unwrap();
    assert!(matches!(
        f.app
            .checkpoint_artifact(&f.operator, &another.id, &snapshot.checkpoint.payload),
        Err(StoreError::Rejected(Rejection::NotFound))
    ));
    let reader = add_identity(&mut f.app, &f.admin, "reader", &[Role::Observer]);
    let mut restricted = principal("reader", &[Role::Observer]);
    restricted.cells = [name("cell/b")].into_iter().collect();
    f.app
        .put_principal(&f.admin, restricted, Some(Counter(1)))
        .unwrap();
    assert!(matches!(
        f.app.run_checkpoint(&reader, &run.id),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
    assert!(matches!(
        f.app
            .checkpoint_artifact(&reader, &run.id, &snapshot.checkpoint.payload),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
}

#[test]
fn executor_reconnect_is_idempotent_but_changed_incarnation_revokes_authority() {
    for failure_mode in [1, 2] {
        let mut f = fixture(1, true);
        let run = start(&mut f, 1);
        let legacy = f.executor.clone();
        let peer_boot = id();
        let binding = Digest::from_bytes([41; 32]);
        let before_epoch = f
            .app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch;
        f.failure.store(failure_mode, Ordering::SeqCst);
        assert!(
            f.app
                .open_executor_peer(&name("executor"), peer_boot.clone(), binding)
                .is_err()
        );
        if failure_mode == 1 {
            assert_eq!(
                f.app.inspect_run(&legacy, &run.id).unwrap().1.state,
                RunState::Executing
            );
        } else {
            assert!(f.app.inspect_run(&legacy, &run.id).is_err());
        }
        let session = f
            .app
            .open_executor_peer(&name("executor"), peer_boot.clone(), binding)
            .unwrap();
        let epoch = f
            .app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch;
        assert_eq!(epoch, before_epoch.increment().unwrap());
        let repeated = f
            .app
            .open_executor_peer(&name("executor"), peer_boot.clone(), binding)
            .unwrap();
        assert_eq!(session.id, repeated.id);
        assert_eq!(
            f.app
                .inspect_cell(&f.operator, &f.configuration.id)
                .unwrap()
                .1
                .epoch,
            epoch
        );
        let current = Identity {
            principal: name("executor"),
            session: session.id.clone(),
            terminal: None,
        };
        assert!(matches!(
            f.app.executor_run_checkpoint(&current, &run.id),
            Err(StoreError::Rejected(Rejection::CapabilityMissing))
        ));
        f.app
            .negotiate_executor_cell(&current, f.configuration.definition.sha256)
            .unwrap();
        assert_eq!(
            f.app
                .executor_run_checkpoint(&current, &run.id)
                .unwrap()
                .run
                .state,
            RunState::RecoveryRequired
        );
        assert!(f.app.inspect_service_peer(&legacy).is_err());
        let second_boot = id();
        let second = f
            .app
            .open_executor_peer(&name("executor"), second_boot.clone(), binding)
            .unwrap();
        assert_ne!(session.id, second.id);
        assert!(f.app.inspect_service_peer(&current).is_err());
        let second_epoch = f
            .app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch;
        assert!(matches!(
            f.app
                .open_executor_peer(&name("executor"), peer_boot.clone(), binding),
            Err(StoreError::Rejected(Rejection::Unauthenticated))
        ));
        assert_eq!(
            f.app
                .open_executor_peer(&name("executor"), second_boot.clone(), binding)
                .unwrap()
                .id,
            second.id
        );
        assert_eq!(
            f.app
                .inspect_cell(&f.operator, &f.configuration.id)
                .unwrap()
                .1
                .epoch,
            second_epoch
        );
        let newer = Identity {
            principal: name("executor"),
            session: second.id,
            terminal: None,
        };
        assert!(f.app.executor_run_checkpoint(&newer, &run.id).is_err());
        let installation = f.app.installation.id.clone();
        let repository = f.app.into_repository();
        let mut reopened = Engine::open(
            repository,
            f.clock,
            SimulationAuthority,
            installation,
            principal("unused", &[Role::AccountAdmin]),
        )
        .unwrap();
        assert!(reopened.inspect_service_peer(&newer).is_err());
        assert!(matches!(
            reopened.open_executor_peer(&name("executor"), peer_boot, binding),
            Err(StoreError::Rejected(Rejection::Unauthenticated))
        ));
        let recovered = reopened
            .open_executor_peer(&name("executor"), second_boot, binding)
            .unwrap();
        assert_ne!(recovered.id, newer.session);
        let after_restart = Identity {
            principal: name("executor"),
            session: recovered.id,
            terminal: None,
        };
        assert!(
            reopened
                .executor_run_checkpoint(&after_restart, &run.id)
                .is_err()
        );
        reopened
            .negotiate_executor_cell(&after_restart, f.configuration.definition.sha256)
            .unwrap();
        assert_eq!(
            reopened
                .executor_run_checkpoint(&after_restart, &run.id)
                .unwrap()
                .run
                .state,
            RunState::RecoveryRequired
        );
    }
}

#[test]
fn executor_part_and_activation_mutations_preserve_full_request_identity_and_atomic_results() {
    for failure_mode in [1, 2] {
        let mut f = fixture_with_peer(1, true, false, false, None, true);
        let run = start(&mut f, 1);
        let cell_revision = f
            .app
            .inspect_cell(&f.executor, &f.configuration.id)
            .unwrap()
            .0;
        let command = BeginPartRequest {
            cell: f.configuration.id.clone(),
            run: run.id.clone(),
            mandate: run.mandate.clone().unwrap(),
            expected_budget: run.budget.as_ref().unwrap().revision(),
            expected_cell: Some(cell_revision),
        };
        let key = id();
        f.failure.store(failure_mode, Ordering::SeqCst);
        assert!(
            f.app
                .executor_begin_part(&f.executor, key.as_str(), command.clone())
                .is_err()
        );
        let observed = f.app.inspect_run(&f.executor, &run.id).unwrap().1;
        assert_eq!(
            observed.part_ids.len(),
            if failure_mode == 1 { 0 } else { 1 }
        );
        let part = f
            .app
            .executor_begin_part(&f.executor, key.as_str(), command.clone())
            .unwrap();
        assert_eq!(part.revision, Counter(1));
        assert_eq!(part.part.ordinal, Counter(1));
        assert_eq!(
            f.app
                .executor_begin_part(&f.executor, key.as_str(), command.clone())
                .unwrap()
                .part
                .id,
            part.part.id
        );
        let mut changed = command.clone();
        changed.expected_budget = Counter(2);
        assert!(matches!(
            f.app
                .executor_begin_part(&f.executor, key.as_str(), changed),
            Err(StoreError::KeyConflict)
        ));
        let mut wrong_mandate = command.clone();
        wrong_mandate.mandate = id();
        assert!(matches!(
            f.app
                .executor_begin_part(&f.executor, id().as_str(), wrong_mandate),
            Err(StoreError::Rejected(Rejection::MandateRevoked))
        ));
        let revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
        let resolve = ResolveActivationRequest {
            run: run.id.clone(),
            node: name("step/0"),
            visit: part.part.ordinal,
            expected_run: revision,
        };
        let activation_key = id();
        f.failure.store(failure_mode, Ordering::SeqCst);
        assert!(
            f.app
                .executor_resolve_activation(&f.executor, activation_key.as_str(), resolve.clone())
                .is_err()
        );
        let activation = f
            .app
            .executor_resolve_activation(&f.executor, activation_key.as_str(), resolve.clone())
            .unwrap();
        let checkpoint = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
        assert_eq!(checkpoint.revision, revision.increment().unwrap());
        assert_eq!(checkpoint.checkpoint.activations.len(), 1);
        assert_eq!(checkpoint.checkpoint.activations[0].id, activation.id);
        assert_eq!(
            f.app
                .executor_resolve_activation(&f.executor, id().as_str(), resolve.clone())
                .unwrap()
                .id,
            activation.id
        );
        assert_eq!(
            f.app.inspect_run(&f.executor, &run.id).unwrap().0,
            checkpoint.revision
        );
        let mut changed = resolve.clone();
        changed.visit = Counter(2);
        assert!(matches!(
            f.app.executor_resolve_activation(
                &f.executor,
                activation_key.as_str(),
                changed.clone()
            ),
            Err(StoreError::KeyConflict)
        ));
        assert!(
            f.app
                .executor_resolve_activation(&f.executor, id().as_str(), changed)
                .is_err()
        );
        let mut revoked = principal("executor", &[Role::Executor, Role::Observer]);
        revoked.active = false;
        f.app
            .put_principal(&f.admin, revoked, Some(Counter(1)))
            .unwrap();
        assert!(matches!(
            f.app
                .executor_begin_part(&f.executor, key.as_str(), command),
            Err(StoreError::Rejected(Rejection::Forbidden))
        ));
        assert!(matches!(
            f.app
                .executor_resolve_activation(&f.executor, activation_key.as_str(), resolve),
            Err(StoreError::Rejected(Rejection::Forbidden))
        ));
    }
}

#[test]
fn admission_receipt_is_anchored_to_the_original_control_record_and_survives_later_changes() {
    use rx_application::control_journal::{
        ADMISSION_SCHEMA, CHANGE_SCHEMA, ControlChange, EntityKind,
    };
    use rx_domain::canonical;
    let mut f = fixture(1, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let cell_revision = f
        .app
        .inspect_cell(&f.executor, &f.configuration.id)
        .unwrap()
        .0;
    let run_revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
    let command = work_command(&f, &activation, cell_revision, run_revision);
    let key = id();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .submit(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    let work = f.app.submit(&f.executor, key.as_str(), command).unwrap();
    let receipt = f
        .app
        .admission_receipt(&f.executor, work.operation.id())
        .unwrap();
    assert_eq!(receipt.operation, work.operation.id().clone());
    assert_eq!(receipt.operation_revision, Counter(1));
    assert_eq!(receipt.intent_digest, work.intent.digest().unwrap());
    assert_eq!(
        receipt.journal,
        control_journal::journal_id(&f.app.installation).unwrap()
    );
    let mut restarted = f.app.installation.clone();
    restarted.runtime_boot = id();
    assert_eq!(
        receipt.journal,
        control_journal::journal_id(&restarted).unwrap()
    );
    restarted.store_generation = id();
    assert_ne!(
        receipt.journal,
        control_journal::journal_id(&restarted).unwrap()
    );
    f.app
        .hold(&f.operator, id().as_str(), &f.configuration.id)
        .unwrap();
    let repeated = f
        .app
        .admission_receipt(&f.operator, work.operation.id())
        .unwrap();
    assert_eq!(
        canonical::bytes(&receipt).unwrap(),
        canonical::bytes(&repeated).unwrap()
    );
    let mut repository = f.app.into_repository();
    let (_, rows) = repository.snapshot().unwrap();
    assert_eq!(
        rows.iter()
            .filter(|r| r.document.schema.as_str() == ADMISSION_SCHEMA)
            .count(),
        1
    );
    let records = repository
        .control_events_after(Counter(receipt.sequence.0 - 1), 1)
        .unwrap();
    let event = records
        .into_iter()
        .find(|e| e.seq == receipt.sequence)
        .unwrap();
    assert_eq!(event.document.schema.as_str(), CHANGE_SCHEMA);
    let change: ControlChange = serde_json::from_value(event.document.value).unwrap();
    assert_eq!(change.entity_kind, EntityKind::Work);
    let original: Work = serde_json::from_value(change.entity.document.value).unwrap();
    assert_eq!(original.operation.id(), &receipt.operation);
    assert_eq!(original.operation.revision(), receipt.operation_revision);
    assert_eq!(
        original.operation.phase(),
        rx_domain::operation::Phase::Admitted
    );
    assert!(original.invocation.is_none());
}

#[test]
fn executor_submit_checks_the_whole_envelope_and_recovers_an_immutable_receipt_after_t1_loss() {
    use rx_domain::canonical;
    for failure_mode in [1, 2] {
        let mut f = fixture_with_peer(1, true, false, false, None, true);
        let run = start(&mut f, 1);
        let part = f
            .app
            .begin_part(
                &f.executor,
                id().as_str(),
                &run.id,
                run.budget.as_ref().unwrap().revision(),
            )
            .unwrap();
        let revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
        let activation = f
            .app
            .resolve_activation(
                &f.executor,
                &run.id,
                &name("step/0"),
                part.ordinal,
                revision,
            )
            .unwrap();
        let revision = f.app.inspect_run(&f.executor, &run.id).unwrap().0;
        let cell_revision = f
            .app
            .inspect_cell(&f.executor, &f.configuration.id)
            .unwrap()
            .0;
        let command = ExecutorSubmitRequest {
            cell: f.configuration.id.clone(),
            mandate: run.mandate.unwrap(),
            work: SubmitWork {
                run: run.id.clone(),
                activation: activation.id,
                part: Some(part.id),
                slot: name("main"),
                intent: f.configuration.steps[0].intent.clone(),
                expected_cell: cell_revision,
                expected_run: revision,
            },
        };
        let mut invalid = command.clone();
        invalid.mandate = id();
        assert!(matches!(
            f.app.executor_submit(&f.executor, id().as_str(), invalid),
            Err(StoreError::Rejected(Rejection::MandateRevoked))
        ));
        let mut invalid = command.clone();
        invalid.work.part = Some(id());
        assert!(matches!(
            f.app.executor_submit(&f.executor, id().as_str(), invalid),
            Err(StoreError::Rejected(Rejection::InvalidInput))
        ));
        let mut stale = command.clone();
        stale.work.expected_cell = Counter(1);
        assert!(
            f.app
                .executor_submit(&f.executor, id().as_str(), stale)
                .is_err()
        );
        let key = id();
        f.failure.store(failure_mode, Ordering::SeqCst);
        assert!(
            f.app
                .executor_submit(&f.executor, key.as_str(), command.clone())
                .is_err()
        );
        assert_eq!(
            f.app.overview(&f.operator).unwrap().cells[0].work.len(),
            if failure_mode == 1 { 0 } else { 1 }
        );
        let receipt = f
            .app
            .executor_submit(&f.executor, key.as_str(), command.clone())
            .unwrap();
        assert_eq!(receipt.operation_revision, Counter(1));
        assert_eq!(receipt.intent_digest, command.work.intent.digest().unwrap());
        assert!(receipt.sequence.0 > 0);
        let mut changed = command.clone();
        changed.work.expected_run = revision.increment().unwrap();
        assert!(matches!(
            f.app.executor_submit(&f.executor, key.as_str(), changed),
            Err(StoreError::KeyConflict)
        ));
        let mut changed = command.clone();
        changed.mandate = id();
        assert!(matches!(
            f.app
                .executor_submit(&f.executor, key.as_str(), changed.clone()),
            Err(StoreError::KeyConflict)
        ));
        assert!(matches!(
            f.app.executor_submit(&f.executor, id().as_str(), changed),
            Err(StoreError::Rejected(Rejection::MandateRevoked))
        ));
        let second = f
            .app
            .executor_submit(&f.executor, id().as_str(), command.clone())
            .unwrap();
        assert_eq!(
            canonical::bytes(&second).unwrap(),
            canonical::bytes(&receipt).unwrap()
        );
        f.app
            .hold(&f.operator, id().as_str(), &f.configuration.id)
            .unwrap();
        let after = f
            .app
            .executor_submit(&f.executor, key.as_str(), command.clone())
            .unwrap();
        assert_eq!(
            canonical::bytes(&after).unwrap(),
            canonical::bytes(&receipt).unwrap()
        );
        assert_eq!(f.app.overview(&f.operator).unwrap().cells[0].work.len(), 1);
        let mut revoked = principal("executor", &[Role::Executor, Role::Observer]);
        revoked.active = false;
        f.app
            .put_principal(&f.admin, revoked, Some(Counter(1)))
            .unwrap();
        assert!(matches!(
            f.app.executor_submit(&f.executor, key.as_str(), command),
            Err(StoreError::Rejected(Rejection::Forbidden))
        ));
        assert!(
            f.app
                .executor_work(&f.executor, &receipt.operation)
                .is_err()
        );
    }
}

#[test]
fn live_execution_snapshot_preserves_the_cut_and_does_not_reuse_aged_maintained_conditions() {
    use rx_process_contract::execution_validation;
    let mut f = fixture_with_peer(1, true, true, true, Some(TestProcess::Branch), true);
    let run = start(&mut f, 1);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    let initial = f
        .app
        .execution_snapshot(&f.executor, &run.id, part.ordinal)
        .unwrap();
    let plan = f.configuration.process.as_ref().unwrap();
    let frontier = execution_validation::validate(&initial, plan).unwrap();
    assert!(initial.request_admission_allowed && initial.admission_reason.is_none());
    assert_eq!(frontier.decisions, vec![plan.root.id.clone()]);
    let restored = f
        .app
        .executor_artifact(&f.executor, &run.id, &initial.run.checkpoint.payload)
        .unwrap();
    let restored: rx_process_contract::execution::ExecutorState =
        rx_domain::canonical::decode_json(&restored).unwrap();
    assert_eq!(restored.run.id, run.id);
    assert_eq!(restored.revision, initial.run.revision);
    let process = f
        .app
        .executor_artifact(&f.executor, &run.id, &initial.resolved)
        .unwrap();
    assert_eq!(process, rx_domain::canonical::bytes(plan).unwrap());
    report_select(&mut f, true);
    let node = f.configuration.process.as_ref().unwrap().root.id.clone();
    let choice = f
        .app
        .choose_process_branch(
            &f.executor,
            id().as_str(),
            &run.id,
            &node,
            part.ordinal,
            initial.run.revision,
        )
        .unwrap();
    let decided = f
        .app
        .execution_snapshot(&f.executor, &run.id, part.ordinal)
        .unwrap();
    assert!(decided.sequence > initial.sequence);
    assert_eq!(
        decided.process_checkpoint.branches[&node].decision,
        choice.decision
    );
    execution_validation::validate(&decided, f.configuration.process.as_ref().unwrap()).unwrap();
    let mut malformed = decided.clone();
    malformed.progress.branches.clear();
    assert!(
        execution_validation::validate(&malformed, f.configuration.process.as_ref().unwrap())
            .is_err()
    );
    f.clock.0.store(21001, Ordering::SeqCst);
    let aged = f
        .app
        .execution_snapshot(&f.executor, &run.id, part.ordinal)
        .unwrap();
    assert_eq!(aged.run.run.state, RunState::Executing);
    assert!(!aged.request_admission_allowed);
    assert_eq!(aged.admission_reason, Some(Rejection::ConditionUnknown));
    let step = f.configuration.steps[0].id.clone();
    assert!(matches!(
        f.app
            .resolve_activation(&f.executor, &run.id, &step, part.ordinal, aged.run.revision),
        Err(StoreError::Rejected(Rejection::ConditionUnknown))
    ));
}

#[test]
fn pause_commits_reply_fence_and_unsent_sealing_atomically_without_refunding_budget() {
    use rx_domain::{
        canonical,
        operation::{Disposition, Outcome},
    };
    for failure_mode in [1, 2] {
        let mut f = fixture_with_peer(1, true, false, false, None, true);
        let mut shared = f.configuration.clone();
        shared.id = name("cell/b");
        f.app.install_cell(&f.admin, shared).unwrap();
        let run = start(&mut f, 1);
        let activation = activation(&mut f, &run);
        let work = submit(&mut f, &activation, id().as_str()).unwrap();
        let before = f.app.run_checkpoint(&f.executor, &run.id).unwrap();
        let command = PauseRunRequest {
            run: run.id.clone(),
            expected_run: before.revision,
        };
        let key = id();
        f.failure.store(failure_mode, Ordering::SeqCst);
        assert!(
            f.app
                .pause_executor_run(&f.executor, key.as_str(), command.clone())
                .is_err()
        );
        let state = f.app.inspect_run(&f.operator, &run.id).unwrap().1.state;
        assert_eq!(
            state,
            if failure_mode == 1 {
                RunState::Executing
            } else {
                RunState::Paused
            }
        );
        let paused = f
            .app
            .pause_executor_run(&f.executor, key.as_str(), command.clone())
            .unwrap();
        assert_eq!(paused.run.state, RunState::Paused);
        assert_eq!(paused.revision, before.revision.increment().unwrap());
        assert_eq!(paused.run.part_ids, before.run.part_ids);
        assert_eq!(paused.run.budget, before.run.budget);
        assert!(paused.run.executor_session.is_none());
        assert_eq!(
            f.app
                .inspect_cell(&f.operator, &f.configuration.id)
                .unwrap()
                .1
                .epoch,
            Counter(2)
        );
        assert_eq!(
            f.app
                .inspect_cell(&f.operator, &name("cell/b"))
                .unwrap()
                .1
                .epoch,
            Counter(2)
        );
        let repeated = f
            .app
            .pause_executor_run(&f.executor, key.as_str(), command)
            .unwrap();
        assert_eq!(
            canonical::bytes(&repeated).unwrap(),
            canonical::bytes(&paused).unwrap()
        );
        assert_eq!(
            f.app
                .inspect_cell(&f.operator, &f.configuration.id)
                .unwrap()
                .1
                .epoch,
            Counter(2)
        );
        let current = f
            .app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap();
        assert_eq!(current.operation.outcome(), Outcome::NotExecuted);
        assert_eq!(current.operation.disposition(), Disposition::Quarantined);
        assert!(f.app.begin_delivery(work.operation.id()).is_err());
        assert!(
            f.app
                .begin_part(
                    &f.executor,
                    id().as_str(),
                    &run.id,
                    paused.run.budget.as_ref().unwrap().revision()
                )
                .is_err()
        );
        let mut changed = PauseRunRequest {
            run: run.id.clone(),
            expected_run: paused.revision,
        };
        assert!(matches!(
            f.app
                .pause_executor_run(&f.executor, key.as_str(), changed.clone()),
            Err(StoreError::KeyConflict)
        ));
        f.app
            .hold(&f.operator, id().as_str(), &f.configuration.id)
            .unwrap();
        let (revision, _) = f.app.inspect_run(&f.operator, &run.id).unwrap();
        changed.expected_run = revision;
        assert_eq!(
            f.app
                .pause_executor_run(&f.executor, id().as_str(), changed)
                .unwrap()
                .run
                .state,
            RunState::RecoveryRequired
        );
    }
}

#[test]
fn late_prepared_receipt_after_pause_does_not_create_an_authorization() {
    let mut f = fixture_with_peer(1, true, false, false, None, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let operation = work.operation.id().clone();
    f.app.begin_delivery(&operation).unwrap();
    let (revision, _) = f.app.inspect_run(&f.executor, &run.id).unwrap();
    f.app
        .pause_executor_run(
            &f.executor,
            id().as_str(),
            PauseRunRequest {
                run: run.id,
                expected_run: revision,
            },
        )
        .unwrap();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &operation,
            HostReceipt {
                operation: operation.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(id()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(10),
                state: ReceiptState::Prepared,
            },
        )
        .unwrap();
    assert_eq!(
        f.app
            .inspect_permit(&f.operator, &work.permit)
            .unwrap()
            .state,
        PermitState::Voided
    );
    let mut repository = f.app.into_repository();
    assert!(
        repository
            .transact(
                |tx| tx.outbox(&rx_application::engine::authorization_delivery_id(
                    &operation
                ))
            )
            .unwrap()
            .is_none()
    );
}

#[test]
fn pause_after_emit_is_not_cancellation_and_late_correlated_result_is_still_recorded() {
    use rx_domain::operation::{Knowledge, Outcome};
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    let run = start(&mut f, 1);
    let activation = activation(&mut f, &run);
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let operation = work.operation.id().clone();
    let invocation = id();
    f.app.begin_delivery(&operation).unwrap();
    f.app
        .record_host_receipt(
            &f.hosts[0],
            &operation,
            HostReceipt {
                operation: operation.clone(),
                digest: work.intent.digest().unwrap(),
                invocation: Some(invocation.clone()),
                journal: f.registrations[0].delivery_journal.clone(),
                sequence: Counter(10),
                state: ReceiptState::Prepared,
            },
        )
        .unwrap();
    let authorize = rx_application::engine::authorization_delivery_id(&operation);
    f.app.begin_delivery(&authorize).unwrap();
    let (revision, _) = f.app.inspect_run(&f.executor, &run.id).unwrap();
    f.app
        .pause_executor_run(
            &f.executor,
            id().as_str(),
            PauseRunRequest {
                run: run.id,
                expected_run: revision,
            },
        )
        .unwrap();
    let unknown = f.app.inspect_work(&f.operator, &operation).unwrap();
    assert_eq!(unknown.operation.outcome(), Outcome::None);
    assert_eq!(unknown.operation.knowledge(), Knowledge::Unknown);
    let evidence = NativeEvidence {
        id: id(),
        operation: operation.clone(),
        invocation,
        profile_digest: work.intent.profile_digest,
        device_session: id(),
        status_schema: name("rx.sim.completed.v1"),
        status: Integer(0),
        captured_at: expiry(1000),
        native_details: None,
    };
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence],
            },
        )
        .unwrap();
    assert_eq!(
        f.app
            .inspect_work(&f.operator, &operation)
            .unwrap()
            .operation
            .outcome(),
        Outcome::Succeeded
    );
}

#[test]
fn pausing_a_prepared_run_without_arm_does_not_fence_other_cell_work() {
    let mut f = fixture_with_peer(1, true, false, false, None, true);
    let (revision, _) = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap();
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, revision))
        .unwrap();
    let paused = f
        .app
        .pause_executor_run(
            &f.executor,
            id().as_str(),
            PauseRunRequest {
                run: run.id,
                expected_run: Counter(1),
            },
        )
        .unwrap();
    assert_eq!(paused.run.state, RunState::Paused);
    assert_eq!(
        f.app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch,
        Counter(1)
    );
}

#[test]
fn pause_rejects_a_late_arm_acknowledgment_from_start_preparation() {
    let mut f = fixture_with_peer(1, true, false, false, None, true);
    let (revision, _) = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap();
    let run = f
        .app
        .create_run(&f.operator, id().as_str(), create_command(&f, revision))
        .unwrap();
    let attempt = f
        .app
        .start_run(
            &f.operator,
            id().as_str(),
            start_command(&f, &run, revision, 1),
        )
        .unwrap();
    let (revision, _) = f.app.inspect_run(&f.executor, &run.id).unwrap();
    let paused = f
        .app
        .pause_executor_run(
            &f.executor,
            id().as_str(),
            PauseRunRequest {
                run: run.id.clone(),
                expected_run: revision,
            },
        )
        .unwrap();
    assert_eq!(paused.run.state, RunState::Paused);
    assert!(paused.run.pending_attempt.is_none());
    let h = &f.registrations[0];
    assert!(
        f.app
            .acknowledge_arm(
                &f.hosts[0],
                ArmAcknowledgment {
                    attempt: attempt.id,
                    host_boot: h.boot_id.clone(),
                    delivery_journal: h.delivery_journal.clone(),
                    sequence: Counter(1),
                    epoch: h.epoch,
                    scopes: h.scopes.clone()
                }
            )
            .is_err()
    );
    assert!(
        f.app
            .inspect_run(&f.operator, &run.id)
            .unwrap()
            .1
            .mandate
            .is_none()
    );
}

#[test]
fn reconciliation_requests_are_durable_coalesced_and_cannot_claim_release() {
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    let (work, evidence) = native_started(&mut f);
    f.app
        .request_reconciliation(&f.executor, work.operation.id())
        .unwrap();
    let first = f.app.pending_reconciliations(&f.hosts[0], None, 8).unwrap();
    assert_eq!(first.len(), 1);
    f.app
        .request_reconciliation(&f.executor, work.operation.id())
        .unwrap();
    let repeated = f.app.pending_reconciliations(&f.hosts[0], None, 8).unwrap();
    assert_eq!(repeated[0].id, first[0].id);
    assert_eq!(repeated[0].generation, Counter(1));
    assert!(
        f.app
            .update_reconciliation(
                &f.hosts[0],
                work.operation.id(),
                &first[0].id,
                ReconciliationState::Complete,
                None
            )
            .is_err()
    );
    f.app
        .ingest_evidence(
            &f.hosts[0],
            EvidenceBatch {
                journal: id(),
                first: Counter(1),
                records: vec![evidence],
            },
        )
        .unwrap();
    let plan = f
        .app
        .plan_reconciliation(&f.hosts[0], work.operation.id(), &first[0].id)
        .unwrap();
    assert_eq!(
        plan.work.operation.outcome(),
        rx_domain::operation::Outcome::Succeeded
    );
    assert_ne!(
        plan.work.operation.disposition(),
        rx_domain::operation::Disposition::Released
    );
    f.app
        .update_reconciliation(
            &f.hosts[0],
            work.operation.id(),
            &first[0].id,
            ReconciliationState::Attention,
            Some(ReconciliationIssue::ContinuityUnproven),
        )
        .unwrap();
    f.app
        .request_reconciliation(&f.executor, work.operation.id())
        .unwrap();
    let next = f.app.pending_reconciliations(&f.hosts[0], None, 8).unwrap();
    assert_ne!(next[0].id, first[0].id);
    assert_eq!(next[0].generation, Counter(2));
    assert!(
        f.app
            .update_reconciliation(
                &f.hosts[0],
                work.operation.id(),
                &first[0].id,
                ReconciliationState::Attention,
                None
            )
            .is_err()
    );
    let mut repo = f.app.into_repository();
    let rows = repo.snapshot().unwrap().1;
    let saved = rows
        .iter()
        .filter(|r| r.document.schema.as_str() == "rx.internal.reconciliation-request.v1")
        .collect::<Vec<_>>();
    assert_eq!(saved.len(), 1);
    let plan: ReconciliationRequest =
        serde_json::from_value(saved[0].document.value.clone()).unwrap();
    assert_eq!(plan.id, next[0].id);
    assert_eq!(plan.state, ReconciliationState::Pending);
}

#[test]
fn false_handover_facts_are_retained_and_identity_conflicts_block_release() {
    use rx_domain::operation::Disposition;
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    let (work, evidence) = completed_work(&mut f);
    f.app
        .request_reconciliation(&f.executor, work.operation.id())
        .unwrap();
    let plan = f
        .app
        .pending_reconciliations(&f.hosts[0], None, 8)
        .unwrap()
        .remove(0);
    let mut proof = handover_proof(&f, &work, &evidence);
    proof
        .observations
        .iter_mut()
        .find(|o| o.source.as_str().ends_with("/support"))
        .unwrap()
        .value = false;
    f.app
        .record_reconciliation_observations(
            &f.hosts[0],
            work.operation.id(),
            &plan.id,
            &proof.observations,
        )
        .unwrap();
    assert!(
        f.app
            .release_resources(&f.hosts[0], id().as_str(), proof.clone())
            .is_err()
    );
    assert_ne!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .disposition(),
        Disposition::Released
    );
    proof
        .observations
        .iter_mut()
        .find(|o| o.source.as_str().ends_with("/support"))
        .unwrap()
        .value = true;
    assert!(matches!(
        f.app.record_reconciliation_observations(
            &f.hosts[0],
            work.operation.id(),
            &plan.id,
            &proof.observations
        ),
        Err(StoreError::Integrity(_))
    ));
    let cell = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    assert!(
        cell.blocks
            .iter()
            .any(|b| b.reason == BlockReason::IntegrityConflict)
    );
    let mut repo = f.app.into_repository();
    let rows = repo.snapshot().unwrap().1;
    let observations = rows
        .iter()
        .filter(|r| r.document.schema.as_str() == "rx.internal.handover-observation.v1")
        .map(|r| serde_json::from_value::<HandoverObservation>(r.document.value.clone()).unwrap())
        .collect::<Vec<_>>();
    assert_eq!(observations.len(), 3);
    assert!(
        !observations
            .iter()
            .find(|o| o.source.as_str().ends_with("/support"))
            .unwrap()
            .value
    );
}

fn checkpoint_fixture(kind: TestProcess) -> (Fixture, CheckpointTarget) {
    let mut f = fixture_with_peer(1, true, false, true, Some(kind), true);
    let run = start(&mut f, 1);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    let node = rx_process_contract::validation::nodes(f.configuration.process.as_ref().unwrap())
        .into_iter()
        .find(|n| {
            matches!(
                n.body,
                rx_process_contract::CompiledBody::Branch { .. }
                    | rx_process_contract::CompiledBody::Wait { .. }
            )
        })
        .unwrap()
        .id
        .clone();
    let action = if matches!(kind, TestProcess::Branch) {
        CheckpointAction::ChooseBranch
    } else {
        CheckpointAction::StartWait
    };
    (
        f,
        CheckpointTarget {
            run: run.id,
            node,
            visit: part.ordinal,
            action,
        },
    )
}
fn prepared(f: &mut Fixture, target: &CheckpointTarget) -> PreparedCheckpoint {
    let CheckpointPreparation::Ready { proposal } = f
        .app
        .prepare_process_checkpoint(&f.executor, target.clone())
        .unwrap()
    else {
        panic!("ready proposal expected")
    };
    *proposal
}
fn checkpoint_command(
    target: &CheckpointTarget,
    prepared: &PreparedCheckpoint,
) -> CommitCheckpoint {
    CommitCheckpoint {
        run: target.run.clone(),
        expected_revision: prepared.expected_revision,
        new_checkpoint: prepared.checkpoint.clone(),
    }
}
#[test]
fn checkpoint_proposal_is_not_an_applied_decision_and_commit_response_survives_loss() {
    use rx_domain::canonical::bytes;
    let (mut f, target) = checkpoint_fixture(TestProcess::Branch);
    let revision = f.app.inspect_run(&f.executor, &target.run).unwrap().0;
    assert!(matches!(
        f.app
            .prepare_process_checkpoint(&f.executor, target.clone())
            .unwrap(),
        CheckpointPreparation::Waiting { .. }
    ));
    report_select(&mut f, true);
    let proposal = prepared(&mut f, &target);
    assert_eq!(
        bytes(&proposal).unwrap(),
        bytes(&prepared(&mut f, &target)).unwrap()
    );
    assert_eq!(
        f.app.inspect_run(&f.executor, &target.run).unwrap().0,
        revision
    );
    assert!(
        f.app
            .process_progress(&f.executor, &target.run, target.visit)
            .unwrap()
            .checkpoint
            .branches
            .is_empty()
    );
    let command = checkpoint_command(&target, &proposal);
    let key = id();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .commit_process_checkpoint(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    assert!(
        f.app
            .process_progress(&f.executor, &target.run, target.visit)
            .unwrap()
            .checkpoint
            .branches
            .is_empty()
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .commit_process_checkpoint(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    let applied = f
        .app
        .commit_process_checkpoint(&f.executor, key.as_str(), command.clone())
        .unwrap();
    assert_eq!(applied.revision, revision.increment().unwrap());
    assert_eq!(applied.checkpoint.payload, proposal.checkpoint.payload);
    assert!(
        f.app
            .process_progress(&f.executor, &target.run, target.visit)
            .unwrap()
            .checkpoint
            .branches[&target.node]
            .chosen
    );
    let mut changed = command.clone();
    changed.expected_revision = changed.expected_revision.increment().unwrap();
    assert!(matches!(
        f.app
            .commit_process_checkpoint(&f.executor, key.as_str(), changed),
        Err(StoreError::KeyConflict)
    ));
    f.app
        .hold(&f.operator, id().as_str(), &f.configuration.id)
        .unwrap();
    assert_eq!(
        bytes(&applied).unwrap(),
        bytes(
            &f.app
                .commit_process_checkpoint(&f.executor, key.as_str(), command.clone())
                .unwrap()
        )
        .unwrap()
    );
    let mut revoked = principal("executor", &[Role::Executor, Role::Observer]);
    revoked.active = false;
    f.app
        .put_principal(&f.admin, revoked, Some(Counter(1)))
        .unwrap();
    assert!(matches!(
        f.app
            .commit_process_checkpoint(&f.executor, key.as_str(), command),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
}
#[test]
fn checkpoint_commit_rejects_changed_mapping_artifact_and_stale_condition() {
    let (mut f, target) = checkpoint_fixture(TestProcess::Branch);
    report_select(&mut f, true);
    let proposal = prepared(&mut f, &target);
    let original = checkpoint_command(&target, &proposal);
    let mut wrong = vec![];
    let mut value = original.clone();
    value.new_checkpoint.run = id();
    wrong.push(value);
    let mut value = original.clone();
    value.new_checkpoint.revision = value.new_checkpoint.revision.increment().unwrap();
    wrong.push(value);
    let mut value = original.clone();
    value.new_checkpoint.payload.size_bytes = Counter(1);
    wrong.push(value);
    let mut value = original.clone();
    value.new_checkpoint.executor_schema = name("rx.unknown.v1");
    wrong.push(value);
    let mut value = original.clone();
    value.new_checkpoint.activations.push(
        rx_application::checkpoint_artifact::ActivationSnapshot {
            id: id(),
            node: target.node.clone(),
            visit: target.visit,
            slots: vec![],
        },
    );
    wrong.push(value);
    for command in wrong {
        assert!(
            f.app
                .commit_process_checkpoint(&f.executor, id().as_str(), command)
                .is_err()
        );
    }
    report_select(&mut f, false);
    assert!(matches!(
        f.app
            .commit_process_checkpoint(&f.executor, id().as_str(), original),
        Err(StoreError::Rejected(Rejection::StaleRevision))
    ));
    assert_eq!(
        f.app.inspect_run(&f.executor, &target.run).unwrap().0,
        proposal.expected_revision
    );
    let new = prepared(&mut f, &target);
    assert_ne!(new.checkpoint.payload, proposal.checkpoint.payload);
    f.app
        .commit_process_checkpoint(
            &f.executor,
            id().as_str(),
            checkpoint_command(&target, &new),
        )
        .unwrap();
    assert!(
        !f.app
            .process_progress(&f.executor, &target.run, target.visit)
            .unwrap()
            .checkpoint
            .branches[&target.node]
            .chosen
    );
}
#[test]
fn checkpoint_wait_uses_p_time_and_success_cannot_be_committed_after_deadline() {
    let (mut f, mut target) = checkpoint_fixture(TestProcess::Wait);
    let proposal = prepared(&mut f, &target);
    let command = checkpoint_command(&target, &proposal);
    let key = id();
    f.clock.0.store(1100, Ordering::SeqCst);
    f.app
        .commit_process_checkpoint(&f.executor, key.as_str(), command.clone())
        .unwrap();
    let original_window = f
        .app
        .process_progress(&f.executor, &target.run, target.visit)
        .unwrap()
        .checkpoint
        .wait_windows[&target.node]
        .clone();
    assert_eq!(original_window.started_at.ticks_ns, Counter(1000));
    assert_eq!(original_window.expires_at.ticks_ns, Counter(1500));
    assert!(matches!(
        f.app
            .prepare_process_checkpoint(&f.executor, target.clone())
            .unwrap(),
        CheckpointPreparation::AlreadyApplied { .. }
    ));
    target.action = CheckpointAction::CheckWait;
    assert!(matches!(
        f.app
            .prepare_process_checkpoint(&f.executor, target.clone())
            .unwrap(),
        CheckpointPreparation::Waiting { .. }
    ));
    report_select(&mut f, true);
    f.clock.0.store(1400, Ordering::SeqCst);
    let success = prepared(&mut f, &target);
    f.clock.0.store(1500, Ordering::SeqCst);
    assert!(matches!(
        f.app.commit_process_checkpoint(
            &f.executor,
            id().as_str(),
            checkpoint_command(&target, &success)
        ),
        Err(StoreError::Rejected(Rejection::StaleRevision))
    ));
    let timeout = prepared(&mut f, &target);
    f.app
        .commit_process_checkpoint(
            &f.executor,
            id().as_str(),
            checkpoint_command(&target, &timeout),
        )
        .unwrap();
    let progress = f
        .app
        .process_progress(&f.executor, &target.run, target.visit)
        .unwrap();
    assert!(matches!(
        progress.checkpoint.waits[&target.node],
        rx_process_contract::frontier::WaitProgress::TimedOut { .. }
    ));
    assert_eq!(
        progress.checkpoint.wait_windows[&target.node].id,
        original_window.id
    );
    assert!(progress.frontier.operations.is_empty());
    assert_eq!(
        f.app
            .commit_process_checkpoint(&f.executor, key.as_str(), command)
            .unwrap()
            .checkpoint
            .payload,
        proposal.checkpoint.payload
    );
}

#[test]
fn checkpoint_preparation_loss_and_expiry_never_advance_the_run() {
    let (mut f, target) = checkpoint_fixture(TestProcess::Branch);
    report_select(&mut f, true);
    let before = f.app.inspect_run(&f.executor, &target.run).unwrap().0;
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .prepare_process_checkpoint(&f.executor, target.clone())
            .is_err()
    );
    assert_eq!(
        f.app.inspect_run(&f.executor, &target.run).unwrap().0,
        before
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .prepare_process_checkpoint(&f.executor, target.clone())
            .is_err()
    );
    let proposal = prepared(&mut f, &target);
    assert_eq!(
        f.app.inspect_run(&f.executor, &target.run).unwrap().0,
        before
    );
    f.clock
        .0
        .store(proposal.valid_until.ticks_ns.0, Ordering::SeqCst);
    assert!(matches!(
        f.app.commit_process_checkpoint(
            &f.executor,
            id().as_str(),
            checkpoint_command(&target, &proposal)
        ),
        Err(StoreError::Rejected(Rejection::Expired))
    ));
    assert_eq!(
        f.app.inspect_run(&f.executor, &target.run).unwrap().0,
        before
    );
}

#[test]
fn checkpoint_successor_preserves_an_existing_child_slot_from_another_visit() {
    use rx_domain::canonical::bytes;
    let mut f = fixture_with_peer(1, true, false, true, Some(TestProcess::Branch), true);
    let run = start(&mut f, 2);
    let part = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            run.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    report_select(&mut f, true);
    let root = f.configuration.process.as_ref().unwrap().root.id.clone();
    let mut target = CheckpointTarget {
        run: run.id.clone(),
        node: root,
        visit: part.ordinal,
        action: CheckpointAction::ChooseBranch,
    };
    let proposal = prepared(&mut f, &target);
    let selected = f
        .app
        .commit_process_checkpoint(
            &f.executor,
            id().as_str(),
            checkpoint_command(&target, &proposal),
        )
        .unwrap();
    let leaf = f.configuration.steps[0].id.clone();
    let activation = f
        .app
        .resolve_activation(&f.executor, &run.id, &leaf, part.ordinal, selected.revision)
        .unwrap();
    let work = submit(&mut f, &activation, id().as_str()).unwrap();
    let current = f.app.inspect_run(&f.executor, &run.id).unwrap().1;
    let next = f
        .app
        .begin_part(
            &f.executor,
            id().as_str(),
            &run.id,
            current.budget.as_ref().unwrap().revision(),
        )
        .unwrap();
    target.visit = next.ordinal;
    let proposal = prepared(&mut f, &target);
    assert_eq!(proposal.checkpoint.activations.len(), 1);
    assert_eq!(
        proposal.checkpoint.activations[0].slots[0].operation,
        *work.operation.id()
    );
    let command = checkpoint_command(&target, &proposal);
    let mut dropped = command.clone();
    dropped.new_checkpoint.activations.clear();
    assert!(
        f.app
            .commit_process_checkpoint(&f.executor, id().as_str(), dropped)
            .is_err()
    );
    let mut replaced = command.clone();
    replaced.new_checkpoint.activations[0].slots[0].operation = id();
    assert!(
        f.app
            .commit_process_checkpoint(&f.executor, id().as_str(), replaced)
            .is_err()
    );
    let committed = f
        .app
        .commit_process_checkpoint(&f.executor, id().as_str(), command)
        .unwrap();
    assert_eq!(
        bytes(&committed.checkpoint.activations).unwrap(),
        bytes(&proposal.checkpoint.activations).unwrap()
    );
    let unchanged = f
        .app
        .inspect_work(&f.executor, work.operation.id())
        .unwrap();
    assert_eq!(bytes(&unchanged).unwrap(), bytes(&work).unwrap());
}

#[test]
fn production_completion_requires_release_and_preserves_original_reply_and_budget() {
    use rx_process_contract::production::CompletePart;
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    let (work, evidence) = completed_work(&mut f);
    let part = work.part.clone().unwrap();
    let view = f.app.production_view(&f.executor, &work.run).unwrap();
    assert_eq!(view.parts.len(), 1);
    assert_eq!(view.parts[0].disposition, PartDisposition::InProgress);
    let mut command = CompletePart {
        cell: f.configuration.id.clone(),
        run: work.run.clone(),
        part: part.clone(),
        expected_run: view.run.revision,
        expected_part: view.parts[0].revision,
    };
    assert!(
        f.app
            .executor_complete_part(&f.executor, id().as_str(), command.clone())
            .is_err()
    );
    let proof = handover_proof(&f, &work, &evidence);
    f.app
        .release_resources(&f.hosts[0], id().as_str(), proof)
        .unwrap();
    let view = f.app.production_view(&f.executor, &work.run).unwrap();
    command.expected_run = view.run.revision;
    let key = id();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .executor_complete_part(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    assert_eq!(
        f.app.production_view(&f.executor, &work.run).unwrap().parts[0].disposition,
        PartDisposition::InProgress
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .executor_complete_part(&f.executor, key.as_str(), command.clone())
            .is_err()
    );
    let reply = f
        .app
        .executor_complete_part(&f.executor, key.as_str(), command.clone())
        .unwrap();
    let after = f.app.production_view(&f.executor, &work.run).unwrap();
    assert_eq!(after.run.run.state, RunState::Completed);
    assert_eq!(
        after.parts[0].disposition,
        PartDisposition::ConfirmedCompleted
    );
    assert_eq!(
        after.run.run.budget.as_ref().unwrap().consumed(),
        Counter(1)
    );
    let duplicate = f
        .app
        .executor_complete_part(&f.executor, id().as_str(), command.clone())
        .unwrap();
    assert_eq!(reply.revision, duplicate.revision);
    assert_eq!(
        f.app
            .production_view(&f.executor, &work.run)
            .unwrap()
            .run
            .revision,
        after.run.revision
    );
    let mut changed = command.clone();
    changed.expected_part = changed.expected_part.increment().unwrap();
    assert!(matches!(
        f.app
            .executor_complete_part(&f.executor, key.as_str(), changed),
        Err(StoreError::KeyConflict)
    ));
    let mut revoked = principal("executor", &[Role::Executor, Role::Observer]);
    revoked.active = false;
    f.app
        .put_principal(&f.admin, revoked, Some(Counter(1)))
        .unwrap();
    assert!(matches!(
        f.app
            .executor_complete_part(&f.executor, key.as_str(), command),
        Err(StoreError::Rejected(Rejection::Forbidden))
    ));
}
#[test]
fn production_read_before_first_part_has_complete_budget_and_detects_missing_parts() {
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    let run = start(&mut f, 2);
    let view = f.app.production_view(&f.executor, &run.id).unwrap();
    assert!(view.parts.is_empty());
    assert!(view.admission_allowed);
    assert_eq!(
        view.run.run.budget.as_ref().unwrap().remaining(),
        Counter(2)
    );
    let part = f
        .app
        .executor_begin_part(
            &f.executor,
            id().as_str(),
            BeginPartRequest {
                cell: f.configuration.id.clone(),
                run: run.id.clone(),
                mandate: run.mandate.clone().unwrap(),
                expected_budget: view.run.run.budget.as_ref().unwrap().revision(),
                expected_cell: Some(view.cell_revision),
            },
        )
        .unwrap();
    let mut view = f.app.production_view(&f.executor, &run.id).unwrap();
    assert_eq!(view.parts[0].id, part.part.id);
    assert_eq!(view.parts[0].revision, part.revision);
    view.parts.clear();
    assert!(rx_process_contract::production::validate(&view).is_err());
}

fn case_request(
    f: &Fixture,
    kind: rx_application::intervention::CaseType,
) -> rx_application::intervention::OpenCase {
    rx_application::intervention::OpenCase {
        cell: f.configuration.id.clone(),
        expected_cell: None,
        kind,
        scopes: vec![],
        procedure: artifact(95, "rx.test.procedure.v1"),
        lead: name("lead"),
        operation_ids: vec![],
        material_ids: vec![],
    }
}
fn add_case_lead(f: &mut Fixture) {
    f.app
        .put_principal(&f.admin, principal("lead", &[Role::RecoveryLead]), None)
        .unwrap();
}
#[test]
fn physical_case_open_is_atomic_and_acknowledgment_cannot_restore_authority() {
    use rx_application::intervention::*;
    use rx_domain::canonical;
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    add_case_lead(&mut f);
    let (work, _) = native_started(&mut f);
    let mut command = case_request(&f, CaseType::FaultRecovery);
    command.operation_ids.push(work.operation.id().clone());
    let before = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    let key = id();
    f.failure.store(1, Ordering::SeqCst);
    assert!(
        f.app
            .open_case(&f.operator, key.as_str(), command.clone())
            .is_err()
    );
    assert!(
        f.app
            .cases(&f.operator, &f.configuration.id)
            .unwrap()
            .cases
            .is_empty()
    );
    assert_eq!(
        f.app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch,
        before.epoch
    );
    f.failure.store(2, Ordering::SeqCst);
    assert!(
        f.app
            .open_case(&f.operator, key.as_str(), command.clone())
            .is_err()
    );
    let opened = f
        .app
        .open_case(&f.operator, key.as_str(), command.clone())
        .unwrap();
    assert_eq!(opened.case.state, CaseState::ContainmentPending);
    let after = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    assert!(after.epoch > before.epoch);
    assert!(
        after
            .blocks
            .iter()
            .any(|b| b.reason == BlockReason::CaseIntervention && b.latched)
    );
    assert_eq!(
        f.app.inspect_run(&f.executor, &work.run).unwrap().1.state,
        RunState::RecoveryRequired
    );
    assert_eq!(
        f.app
            .inspect_work(&f.operator, work.operation.id())
            .unwrap()
            .operation
            .outcome(),
        rx_domain::operation::Outcome::None
    );
    let ack = AcknowledgeCase {
        cell: f.configuration.id.clone(),
        case: opened.case.id.clone(),
        expected_case: opened.revision,
        occurred_at: "2026-09-11T01:02:03Z".into(),
    };
    let ack_key = id();
    let result = f
        .app
        .acknowledge_case(&f.operator, ack_key.as_str(), ack.clone())
        .unwrap();
    assert_eq!(result.snapshot.case.state, CaseState::ContainmentPending);
    assert!(result.snapshot.case.participants.is_empty());
    assert_eq!(result.acknowledgments.len(), 1);
    assert_eq!(
        f.app
            .inspect_cell(&f.operator, &f.configuration.id)
            .unwrap()
            .1
            .epoch,
        after.epoch
    );
    assert_eq!(
        canonical::bytes(&result).unwrap(),
        canonical::bytes(
            &f.app
                .acknowledge_case(&f.operator, ack_key.as_str(), ack.clone())
                .unwrap()
        )
        .unwrap()
    );
    let mut changed = ack;
    changed.occurred_at = "2026-09-11T01:02:04Z".into();
    assert!(matches!(
        f.app
            .acknowledge_case(&f.operator, ack_key.as_str(), changed),
        Err(StoreError::KeyConflict)
    ));
    assert_eq!(
        f.app
            .cases(&f.operator, &f.configuration.id)
            .unwrap()
            .cases
            .len(),
        1
    );
}
#[test]
fn diagnostic_case_keeps_epoch_and_mandate_but_blocks_new_admission() {
    use rx_application::intervention::*;
    let mut f = fixture_with_peer(1, true, false, true, None, true);
    add_case_lead(&mut f);
    let run = start(&mut f, 2);
    let before = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    let diagnostic = f
        .app
        .open_case(
            &f.operator,
            id().as_str(),
            case_request(&f, CaseType::DiagnosticOnly),
        )
        .unwrap();
    let after = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    assert_eq!(after.epoch, before.epoch);
    assert!(
        after
            .blocks
            .iter()
            .any(|b| b.reason == BlockReason::CaseDiagnostic && !b.latched)
    );
    assert_eq!(
        f.app.inspect_run(&f.executor, &run.id).unwrap().1.state,
        RunState::Executing
    );
    assert!(
        f.app
            .begin_part(
                &f.executor,
                id().as_str(),
                &run.id,
                run.budget.as_ref().unwrap().revision()
            )
            .is_err()
    );
    let other = f
        .app
        .open_case(
            &f.operator,
            id().as_str(),
            case_request(&f, CaseType::PlannedAccess),
        )
        .unwrap();
    let epoch = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1
        .epoch;
    f.app
        .acknowledge_case(
            &f.operator,
            id().as_str(),
            AcknowledgeCase {
                cell: f.configuration.id.clone(),
                case: diagnostic.case.id,
                expected_case: diagnostic.revision,
                occurred_at: "2026-09-11T01:02:03+00:00".into(),
            },
        )
        .unwrap();
    let cell = f
        .app
        .inspect_cell(&f.operator, &f.configuration.id)
        .unwrap()
        .1;
    assert_eq!(cell.epoch, epoch);
    assert!(cell.open_cases.contains(&other.case.id));
    assert!(
        cell.blocks
            .iter()
            .any(|b| other.case.block_ids.contains(&b.id))
    );
}
