use super::*;

impl<R: Repository, C: Clock, A: QualificationAuthority> Engine<R, C, A> {
    pub fn report_fact(&mut self, identity: &Identity, mut fact: FactRecord) -> Result<()> {
        let clock = &self.clock;
        let meta = &self.installation;
        let rejection = self.repository.transact(|tx| {
            let now = clock.now();
            let principal = authorize(
                tx,
                identity,
                meta,
                &now,
                Some(&fact.cell),
                Role::Host,
                false,
            )?;
            let (_, cell): (_, Cell) = load(tx, "cell", &fact.cell, CELL)?;
            let spec = cell
                .configuration
                .fact_specs
                .iter()
                .find(|s| s.id == fact.id)
                .ok_or(StoreError::Rejected(Reject::CapabilityMissing))?;
            let (_, host): (_, HostRegistration) =
                load(tx, "host", (&fact.cell, &principal.id), HOST)?;
            if spec.host != principal.id
                || fact.source_host != principal.id
                || spec.schema != fact.schema
                || spec.unit != fact.unit
                || fact.maximum_age_ns != spec.maximum_age_ns
                || fact.acquisition_uncertainty_ns > spec.maximum_uncertainty_ns
            {
                return reject(Reject::InvalidInput);
            }
            let evidence_key = key("factevidence", &fact.evidence_id);
            let evidence = doc("rx.internal.observation-evidence.v1", &fact.evidence())?;
            if let Some(old) = tx.get(&evidence_key)? {
                if old.document != evidence {
                    let incident = key(
                        "observationincident",
                        (
                            &fact.evidence_id,
                            canonical::digest("RX-EVIDENCE-CONFLICT-v1", &evidence)
                                .map_err(domain_error)?,
                        ),
                    );
                    if tx.get(&incident)?.is_none() {
                        tx.put(&incident, None, &evidence)?;
                        invalidate_fact_dependents(tx, &fact, BlockReason::IntegrityConflict)?;
                        event(tx, "rx.event.observation-conflict.v1", &fact)?;
                    }
                    return Ok(Some(StoreError::KeyConflict));
                }
            } else {
                tx.put(&evidence_key, None, &evidence)?;
            }
            let changed_generation = host.source_sessions.get(&fact.id)
                != Some(&fact.source_generation)
                || fact.acquired_at.clock_id != now.clock_id;
            if changed_generation {
                fact.quality_good = false;
            }
            let current_key = key("fact", (&fact.cell, &fact.id));
            let previous = tx.get(&current_key)?;
            if let Some(record) = &previous {
                let old: FactRecord = decode(record, FACT)?;
                if old.evidence_id == fact.evidence_id && !changed_generation {
                    return Ok(None);
                }
                if !changed_generation
                    && old.acquired_at.clock_id == fact.acquired_at.clock_id
                    && old.acquired_at.ticks_ns > fact.acquired_at.ticks_ns
                {
                    event(tx, "rx.event.historical-observation.v1", &fact)?;
                    return Ok(None);
                }
            }
            tx.put(
                &current_key,
                previous.map(|r| r.revision),
                &doc(FACT, &fact)?,
            )?;
            if changed_generation {
                invalidate_fact_dependents(tx, &fact, BlockReason::DeviceRestart)?;
                event(tx, "rx.event.source-generation-changed.v1", &fact)?;
                return Ok(Some(StoreError::Rejected(Reject::ContinuityUnproven)));
            }
            if fact.disputed {
                invalidate_fact_dependents(tx, &fact, BlockReason::IntegrityConflict)?;
            }
            let maintained_lost = if cell.configuration.maintained_conditions.is_empty() {
                false
            } else {
                match evaluate(tx, &cell, &cell.configuration.maintained_conditions, &now) {
                    Ok(_) => false,
                    Err(StoreError::Rejected(
                        Reject::ConditionFailed | Reject::ConditionUnknown,
                    )) => true,
                    Err(error) => return Err(error),
                }
            };
            if maintained_lost {
                let active = tx
                    .scan("run/")?
                    .iter()
                    .map(|r| decode::<Run>(r, RUN))
                    .collect::<Result<Vec<_>>>()?
                    .iter()
                    .any(|r| {
                        r.cell == cell.configuration.id
                            && (r.state == RunState::Executing || r.pending_attempt.is_some())
                    });
                if active {
                    invalidate_fact_dependents(tx, &fact, BlockReason::ConditionLost)?;
                }
            }
            event(tx, "rx.event.observation-recorded.v1", &fact)?;
            Ok(None)
        })?;
        match rejection {
            Some(error) => Err(error),
            None => Ok(()),
        }
    }
    pub fn inspect_fact(
        &mut self,
        identity: &Identity,
        cell: &Name,
        fact: &Name,
    ) -> Result<FactRecord> {
        let clock = &self.clock;
        let meta = &self.installation;
        self.repository.transact(|tx| {
            let now = clock.now();
            authorize_read(tx, identity, meta, &now, cell)?;
            Ok(load::<FactRecord>(tx, "fact", (cell, fact), FACT)?.1)
        })
    }
}
