# RX 구현 초안 — 진행 기준

2026-09-10 사용자의 명시적 구현 착수 지시에 따른다. 목표는 지금까지의 설계를 두 레포의 실행 가능한 초안으로 연결하고 검증하는 것이다. 첫 현장의 실제 장비 지원 완료·납품 인증을 주장하지 않는다.

## 구현 원칙

- `rx-platform`: Rust domain, application, ports, SQLite adapter, HTTP/gRPC, host maintenance tool. ROS·BT·native driver를 core에 의존시키지 않는다.
- `rx-solutions`: 자사 필수 스택, 장비 Host, ROS/native adapters, 선언형 공정/BT 실행, 패키지, React 구성·운영 앱.
- 두 레포 각각의 이미지. 호스트 관리 도구는 platform 소유이며 제3 레포/이미지가 아니다.
- 하나의 Linux PC·복수 셀·단일 권위 Runtime. 모델별 controller/공유 자원 기준으로 Host를 배치한다.
- 첫 물리 셀은 NOT_COMMISSIONED. 모의 셀과 실물 구성은 분리하고 모의 근거로 실물 qualification을 만들지 않는다.
- 기존 규범 파일과 manifest를 그대로 보존한다. 발견한 규범 공백은 결정 기록으로 남기며, 미구현 기능을 비슷한 구현으로 대체해 완료 표시하지 않는다.

## 작업 순서

1. 계약 표현·검증과 순수 domain의 불변식.
2. 영속 command processing, 원자성, 단일 writer, Host journal 및 장애 복구.
3. 공정·장비·현장 패키지, source 변환과 모의 Host/실행기의 전체 경로.
4. 인증·운영·구성 API 및 시각적 편집/운영/복구 화면.
5. 자사 스택 lock·연동 경계, 두 이미지, 기동/종료/배포/복원 도구.
6. 계약·프로세스·UI·복원 시험, 실제 지원 범위/미결 현장 입력 감사.

순서는 구현상의 의존 순서다. 후반 항목을 목표에서 제외하지 않는다. 완료는 `requirements.md` 전체와 실제 검증 증거로 감사한다.

## 현재 상태

구현 중이다. platform192개 일반 시험, solutions54개, 양쪽 clippy가 통과했다. 별도 프로세스의 명시적 작업·자동 dispatcher·원격 executor 제출·증거 publisher·별도 S 복원 reader·영속 worker E2E6개도 각각 실행해 통과했다. 앞선 UI 단위3개/브라우저 통합과 C++ wire17개 증거를 유지한다. 실제 C++ BT 노드의4개 시나리오와 생성5단계 예제도 검증했다.

application outbox→Host→T2→자원 인계→두 소재 시도 완료, 로컬 계정/API·운영 화면과 별도 Host 증거 전송을 연결했다. Host의 인증된 상태 조회·초기 등록·사용권 갱신도 연결했으며, 동일 boot의 원장 교체를 거부한다. 연결 등록은 장비 조건의 충족이나 운전 허가를 만들지 않는다. 공개 제어 사건의 전체 wire 매핑, 자동 운영 서비스·공정 편집/BT·복구 전체·제품 배포·자사 스택 지원은 아직 미완료다. 각 변경과 시험의 범위는 `progress.md`에 기록한다. 개발 도구는 workspace `.tools` 아래에 설치해 기존 사용자 shell 설정을 변경하지 않는다.

- [로컬 서비스와 HTTP 경계](../../rx-platform/crates/rx-api/README.md)
- [운영 앱과 브라우저 검증 방법](../../rx-solutions/apps/operator/README.md)
- [공정 초안·버전·구조 검사](../../rx-platform/crates/rx-application/PROCESS_DRAFTS.md)
- [솔루션 프로세스 관리](../../rx-solutions/runtime/rx-supervisor/README.md)
- [Host 실행 서비스의 현재 진단](../../rx-platform/crates/rx-runtime/HOST_SERVICE_HEALTH.md)
- [운영 화면의 조건·관측 진단](../../rx-platform/crates/rx-application/OPERATOR_CONDITIONS.md)
- [관측 수집·유지 조건 만료 감시](../../rx-platform/crates/rx-application/OBSERVATION_INGESTION.md)
- [Host bootstrap·lease 연결](../../rx-platform/crates/rx-host-client/HOST_CONNECTION.md)
- [자사 스택과 솔루션 이미지](../../rx-solutions/dependencies/NATIVE_IMAGE.md)
- [플랫폼 실행 파일·기동·종료·첫 이미지](../../rx-platform/crates/rx-platformd/README.md)
- [사용자·등록 단말·HTTPS 신원](../../rx-platform/crates/rx-application/TERMINAL_IDENTITY.md)
- [셀 상태와 운영 API 서비스 세션](../../rx-platform/crates/rx-application/CELL_CONTEXT_AND_OPERATOR_PEER.md)
- [비운전 사건 종료](../../rx-platform/crates/rx-application/NON_OPERATING_CLOSURE.md)
- [절차 사실과 상태 승격](../../rx-platform/crates/rx-application/PROCEDURE_REPORTS.md)
- [개입 사건과 알림 확인](../../rx-platform/crates/rx-application/INTERVENTION_CASES.md)
- [직렬 소재 조정](../../rx-solutions/runtime/rx-executor/PRODUCTION_COORDINATOR.md)
- [실행 서비스와 중단 기록](../../rx-solutions/runtime/rx-executor/SERVICE_LIFECYCLE.md)
- [지속 BT 엔진과 요청 큐](../../rx-solutions/native/executor/PERSISTENT_ENGINE.md)
- [실행기의 분기·대기와 복원](../../rx-solutions/runtime/rx-executor/DECISIONS_AND_RECOVERY.md)
- [분기·대기 후보와 체크포인트 확정](../../rx-platform/crates/rx-application/CHECKPOINT_COMMIT.md)
- [기존 작업 조회와 자원 인계](../../rx-platform/crates/rx-application/RECONCILIATION.md)
- [BT 중단과 PauseRun](../../rx-platform/crates/rx-application/EXECUTOR_PAUSE.md)
- [S 영속 요청과 유한 worker](../../rx-solutions/runtime/rx-executor/JOURNAL_AND_WORKER.md)
- [복원 자료와 현재 실행 상태·Frame 연결](../../rx-platform/crates/rx-application/EXECUTION_READ.md)
- [실행기 유한 작업 제출·현재 결과 조회](../../rx-platform/crates/rx-application/EXECUTOR_SUBMISSION.md)
- [실행기 소재 시도·단계 요청](../../rx-platform/crates/rx-application/EXECUTOR_REQUESTS.md)
- [실행기 세션·원격 Run 조회](../../rx-platform/crates/rx-application/EXECUTOR_PEER.md)
- [실행 복원 상태와 artifact](../../rx-platform/crates/rx-application/CHECKPOINT_ARTIFACT.md)
- [요구 추적표](requirements.md)
- [진행 기록](progress.md)
