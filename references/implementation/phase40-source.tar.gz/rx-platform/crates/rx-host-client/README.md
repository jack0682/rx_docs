# Platform Host client

This crate converts application DTOs into the frozen RX wire contract and communicates over mTLS. It does not modify the application store itself.

The application first commits an outbox entry, claims emission, sends the request with that stable key, and records the Host receipt in a new atomic transaction. A PREPARED receipt schedules Authorize; a captured Host result alone does not set a platform outcome. Native evidence is ingested through T2 and the configured completion policy.

Run the cross-repository, separate-process integration test with:

    ./tools/test_host_e2e.sh

The script builds a feature-gated simulation Host fixture from rx-solutions and then runs the ignored network integration test with its exact path. The regular workspace test command intentionally does not silently substitute a mock for that process.

The client includes bounded outbox dispatch, existing-invocation reconciliation and durable query-driven resource handover. `Operation.Reconcile` schedules Host reads; it never directly resubmits a production invocation. Three fresh correlated handover facts and the existing application release transaction are required. False observations remain recorded without releasing resources. See [query and handover semantics](../rx-application/RECONCILIATION.md).

Background Evidence.Publish is owned by the solutions Host. Product supervision, strict control-delivery latency, indexed large-journal scheduling and the complete recovery workflow remain pending.
