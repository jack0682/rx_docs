use rx_application::{RunState, checkpoint_artifact::*};
use rx_protocol::base;
pub fn run_view(snapshot: &RunSnapshot) -> base::RunView {
    base::RunView {
        run_id: snapshot.run.id.to_string(),
        revision: snapshot.revision.0,
        recipe_digest: snapshot.run.recipe_digest.as_bytes().to_vec(),
        state: match snapshot.run.state {
            RunState::Prepared => base::RunState::Prepared,
            RunState::Executing => base::RunState::Executing,
            RunState::Paused => base::RunState::Paused,
            RunState::RecoveryRequired => base::RunState::RecoveryRequired,
            RunState::Completed => base::RunState::Completed,
            RunState::Abandoned => base::RunState::Abandoned,
        } as i32,
        checkpoint: Some(checkpoint(&snapshot.checkpoint)),
        executor_session_id: snapshot
            .run
            .executor_session
            .as_ref()
            .map(ToString::to_string),
    }
}
pub fn checkpoint(value: &CheckpointView) -> base::Checkpoint {
    base::Checkpoint {
        run_id: value.run.to_string(),
        revision: value.revision.0,
        executor_schema: value.executor_schema.to_string(),
        payload: Some(base::ArtifactRef {
            sha256: value.payload.sha256.as_bytes().to_vec(),
            schema_id: value.payload.schema_id.to_string(),
            size_bytes: value.payload.size_bytes.0,
        }),
        activations: value
            .activations
            .iter()
            .map(|activation| base::ActivationView {
                activation_id: activation.id.to_string(),
                node_id: activation.node.to_string(),
                visit: activation.visit.0,
                slots: activation
                    .slots
                    .iter()
                    .map(|slot| base::SlotBinding {
                        slot: slot.slot.to_string(),
                        operation_id: slot.operation.to_string(),
                        intent_digest: slot.intent_digest.as_bytes().to_vec(),
                    })
                    .collect(),
            })
            .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rx_application::Run;
    use rx_domain::types::*;
    fn id(value: u8) -> Id {
        Id::new(format!("00000000-0000-4000-8000-{value:012}")).unwrap()
    }
    fn name(value: &str) -> Name {
        Name::new(value).unwrap()
    }
    #[test]
    fn frozen_run_view_preserves_counters_slots_and_each_run_state() {
        for (state, expected) in [
            (RunState::Prepared, "PREPARED"),
            (RunState::Executing, "EXECUTING"),
            (RunState::Paused, "PAUSED"),
            (RunState::RecoveryRequired, "RECOVERY_REQUIRED"),
            (RunState::Completed, "COMPLETED"),
            (RunState::Abandoned, "ABANDONED"),
        ] {
            let digest = Digest::from_bytes([37; 32]);
            let snapshot = RunSnapshot {
                revision: Counter(u64::MAX),
                run: Run {
                    id: id(1),
                    cell: name("cell/a"),
                    recipe_digest: digest,
                    envelope_digest: digest,
                    purpose: None,
                    state,
                    budget: None,
                    executor_session: Some(id(2)),
                    mandate: None,
                    part_ids: vec![],
                    pending_attempt: None,
                },
                checkpoint: CheckpointView {
                    run: id(1),
                    revision: Counter(u64::MAX),
                    executor_schema: name(SCHEMA),
                    payload: ArtifactRef {
                        sha256: digest,
                        schema_id: name(SCHEMA),
                        size_bytes: Counter(99),
                    },
                    activations: vec![ActivationSnapshot {
                        id: id(3),
                        node: name("step/place"),
                        visit: Counter(9_007_199_254_740_993),
                        slots: vec![SlotSnapshot {
                            slot: name("main"),
                            operation: id(4),
                            intent_digest: digest,
                        }],
                    }],
                },
            };
            let view = run_view(&snapshot);
            let bytes = rx_protocol::json::to_vec(&view).unwrap();
            let restored: base::RunView = rx_protocol::json::from_slice(&bytes).unwrap();
            assert_eq!(restored, view);
            let json = rx_protocol::json::to_value(&view).unwrap();
            assert_eq!(json["state"].as_str(), Some(expected));
            assert_eq!(json["revision"].as_str(), Some("18446744073709551615"));
            assert_eq!(
                json["checkpoint"]["activations"][0]["visit"].as_str(),
                Some("9007199254740993")
            );
            assert_eq!(
                json["checkpoint"]["activations"][0]["slots"][0]["operation_id"].as_str(),
                Some(id(4).as_str())
            );
            assert_eq!(
                json["checkpoint"]["payload"]["sha256"].as_str(),
                Some(digest.to_string().as_str())
            );
        }
    }
}
