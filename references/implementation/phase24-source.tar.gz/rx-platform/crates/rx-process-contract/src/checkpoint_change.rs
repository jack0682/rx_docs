//! A prepared state is a proposal, never permission or an applied process decision.
use crate::execution::CheckpointView;
use rx_domain::types::*;
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum CheckpointAction {
    ChooseBranch,
    StartWait,
    CheckWait,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CheckpointTarget {
    pub run: Id,
    pub node: Name,
    pub visit: Counter,
    pub action: CheckpointAction,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PreparedCheckpoint {
    pub expected_revision: Counter,
    pub checkpoint: CheckpointView,
    pub prepared_at: TimePoint,
    pub valid_until: TimePoint,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(
    tag = "state",
    rename_all = "SCREAMING_SNAKE_CASE",
    deny_unknown_fields
)]
pub enum CheckpointPreparation {
    Ready { proposal: Box<PreparedCheckpoint> },
    Waiting { run_revision: Counter },
    AlreadyApplied { run_revision: Counter },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CommitCheckpoint {
    pub run: Id,
    pub expected_revision: Counter,
    pub new_checkpoint: CheckpointView,
}
