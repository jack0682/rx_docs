# 구현 요구·검증 추적표

상태: OPEN / PARTIAL / IMPLEMENTED / VERIFIED / FIELD_BLOCKED. VERIFIED에는 구체 시험과 결과가 필요하다. 파일 존재만으로 기능을 검증했다고 표시하지 않는다.

| ID | 요구 | 증거/완료 판단 | 상태 |
|---|---|---|---|
| R01 | 두 독립 레포·두 이미지·Rust ROS 비의존 core | 레포·의존 그래프·이미지 빌드 | PARTIAL |
| R02 | 공통·셀 v1 schema와 strict codec, 정확한 enum/optional/정규화 | Rust/C++ golden vectors, unknown/duplicate 입력 거부 | PARTIAL |
| R03 | intent 동일성·key/activation/slot 유일성 | 중복·충돌·재접속·동시성 및 외부 envelope 검사. S key/body 선행 commit·미확정 보존·확인된 CAS 거부 후 새 attempt 검증 | PARTIAL |
| R04 | T1–T5, SQLite 단일 writer·WAL/FULL | commit 경계 fault injection, atomic rollback | PARTIAL |
| R05 | Host PREPARED/SEND_ENTERED/VOIDED 및 별도 evidence journal | native 진입·restart, publisher131개/ack 유실·H cursor 보존. 전체 전달/복원은 후속 | PARTIAL |
| R06 | 결과/지식/무결성/자원 처분 분리 | UNKNOWN 왕복·후발 모순·지지 인계 및 공개 OperationView의 독립 상태 축 검증. 영속 조회 계획·false 관측 보존·실제 해제와 조회 응답 분리 추가 | PARTIAL |
| R07 | grant/fence/epoch/permit와 native gate | 자동 전달/응답 유실/NOT_FOUND/중복 receipt/Fence 검증. Host snapshot/초기 link/fence·grant 등록·renewal과 별도 TLS 연결을 추가. 동일 boot의 원장 교체 거부·원래 계획/요청 ID 보존도 검증. 전체 취소·rebind는 후속 | PARTIAL |
| R08 | 조건 평가·관측 age/source/단위·세대 | clock/freshness/unknown/모순 fixture. Host 관측 묶음의 원자적 기록·전체 조건 평가, 세대 상실/모순의 사실 보존·반복 차단 방지, 네트워크 독립 유지 조건 만료 감시 및 실제 TLS 반복 수집 연결 | PARTIAL |
| R09 | RunMandate·part/operation 예산·activation/checkpoint | restart 중 사용량 보존·마지막 part 완료. PauseRun의 run/cell closure·fence·최종 응답 원자성 추가. Run/slot/artifact 동일 commit·읽기 검증; 실행기 원격 Run 조회 연결. BeginPart/ResolveActivation 전체 payload·실제 mTLS 연결. 공유 checkpoint DTO·별도 S 복원 reader/C++ Frame 전달 연결. P 후보 준비·CommitCheckpoint의 전체 상태/ID 보존·현재 조건 재계산·실제 mTLS/응답 유실을 검증. S 분기/대기 worker·후보 검증·확정 거부 후 재준비·별도 관측 복원도 검증. 직렬 소재 admission/완료/다음 context와 응답 유실도 검증. 전체 restart는 후속 | PARTIAL |
| R10 | 개입·절차·복구·재시작·비운전 종료 | Case Open/Get·diagnostic/latch·ACK 비승격·atomic 응답 유실 및 UI 확인을 연결. typed procedure report·stale CAS 사실 보존·정책/fence/조건 진입·개인별 종료/인수 및 REVALIDATING 연결. 비운전 clearance/close의 원자성·현재 근거 재검사·기존 UNKNOWN/다른 사건 차단 보존을 추가. recovery/restart·무진입/불명 범위·전체 gRPC/화면과 CO03–12/16/26–28 전체는 후속 | PARTIAL |
| R11 | 여러 셀의 장비·제어기·소재 지지 자원 공유 | alias·공유 JTC·양쪽 지지 해제 반례 | PARTIAL |
| R12 | 고주기 stream latest-only·expiry·단일 consumer | 재정렬·old ticket·권한 변경·재생 금지 | OPEN |
| R13 | 제품군+모델/모드 profile·필수 자사 지원표 | 필수5개 source·22개 구성 catalogue/source hash 검증. 자사/전이8개·ROS42개 compile, 17개 plugin 선언·69개 ELF·정책11개/ONNX4개 load 및 실제 S arm64 image 기동 추가. 실제 profile/장비 검증은 후속 | PARTIAL |
| R14 | 선언형 공정·현장 binding·resolved plan·BT 변환 | 원본/compiler/frontier와 C++ BT 노드 실행 시험. P 내부 checkpoint/eligibility 검증 추가. P artifact/로컬 RunView 조회 연결. 인증된 S snapshot/artifact client와 C++ Frame 경계 추가. 영속 유한 mutation worker 연결. PauseExecutor·RequestHandover와 응답 유실 후 해제 관측도 연결. P CommitCheckpoint는 연결했고, S 분기/대기 요청, 지속 C++ 엔진·private pipe·bounded pending queue도 연결. run/visit 서비스도 연결. 직렬 part coordinator도 연결. 개입 요청·병렬 소재·전체 supervisor는 후속 | PARTIAL |
| R15 | 독립 검증 패키지·유형별 권한·변경 영향 | 서명/내용/종류·권한/전이 의존 검증. Process package 후보/외부 서명 요청·봉인·현재 trust/dependency/asset 검증·signed bytes 재컴파일 추가. P의 immutable object 보관·독점 소유·원자 공개와 오프라인 import/현재 정책 재검증 추가. 원본 변경/키 회수/저장 손상/경로 변경·재실행 거부 시험. 사용자/셀별 반입 preflight·실제 Store proof·현재 권한/정책 재검사·원자 접수/이력·HTTP/단말 mTLS 기동도 연결. 공정의 실제 S 검증 자료·서명, P 원문/결과/셀 대조, 불변 검토 버전과 별도 Verifier 계정의 승인/반려도 연결. 공정 before/after·공유 Host/resource/scope 영향 closure, 독립 영향 검토·STAGED와 단말 ReleaseManager의 epoch/fence 준비를 추가. Device/UI·절차 검증, Host의 공정 문맥/영속 receipt와 mTLS Inspect/Apply/Lookup도 구현. P의 명시적 Host Batch/전송 전 request commit·같은 ID 조회/제한 재전송·receipt 보존과 부분 확인/미확인 집계도 연결. 최근 Host 응답의 메모리 proof와 패키지 재검증 후 실제 P 구성 선택·이전 자격 보관·새 epoch/fence·APPLIED_UNQUALIFIED를 원자 기록. Run별 불변 구성과 과거 artifact/생산 조회도 연결. 정확한 구성/의존 자료·6영역의 재검증 요청, 서명/원본 검증·영속 보고서/독립 검토와 현재성도 연결. Host의 exact-cohort 자격 수용/영속 receipt·immutable ID 의미·새 epoch·device session guard와 별도 Arm도 연결. P의 v2 목적 정책·원본 재검증/자격 발급·영속 task·전체 QUALIFIED_ACTIVE·소유 block 해제/정지와 별도 StartRun도 연결. 전체 취소/복원·production 물리 검증은 후속 | PARTIAL |
| R16 | HTTP/gRPC 동일 application·mTLS/현장 계정/단말 | 인증·권한·회수 namespace·우회 거부. Executor Session/Cell/GetRun/BeginPart/ResolveActivation/유한 Submit·Operation.Get/Reconcile 실제 mTLS. 원격 E·자동 P→H 경로/응답 유실 및 PrepareCheckpoint/CommitCheckpoint 및 S 실제 BT 분기·대기/만료/응답 유실/재시작 mTLS 검증. OPERATOR_API 전송 세션/조회와 canonical Cell.Inspect HTTP·mTLS 연결. 직접 mTLS terminal HTTPS·사용자/단말 scope/등록 revision binding·폐기/재요청 거부 연결. gRPC 사용자 위임 및 제품 배포는 후속 | PARTIAL |
| R17 | 일관 snapshot·SSE·권한별 UI projection | 권한별 overview 구현. 감사/control 저장·cursor 분리와 RunSnapshot/current execution cut 구현. 기록된 모드/자격·차단 생성 revision의 CellContext wire 조회도 연결. 동일 조회 cut의 source/Host 권한/조건 평가 진단과 현재 접근권 필터를 추가. 현재 Runtime owner의 volatile 연결·조회·전달 상태와 보고/활동 만료를 운영 view에 연결. 전체 Event wire 매핑·paging/SSE는 미완료 | PARTIAL |
| R18 | 시각적 공정 편집·새 초안·검증·비교·변환 | 원자적 source draft/이력/index·같은 key 회수·현재 Engineer 권한·CAS 충돌을 구현. 구조 validator를 P 작성/S compiler가 공유. 실제 UI 노드·흐름 편집/비교/복사·buffer 보존·응답 유실 회수 연결. 현재 셀의 step 선택·버전/CAS/구성 digest 고정·stale 표시·matched compile input export 추가. 새 장비 binding/조건/복구 편집·compiler/package UI 통합은 후속 | PARTIAL |
| R19 | 운영/실적/조건/개입/복구 화면 | 로컬 운영/기록·응답 유실/동일 key 회수·stale 검토 시험. 개입 목록/ACK 및 응답 유실 회수도 연결. 운전 조건·관측 근거 페이지, 화면 판정 만료, missing/PASS/FAIL/expired와 모바일/응답 지연 표시도 연결. 실적/절차/복구 전체는 후속 | PARTIAL |
| R20 | 구성·검증·배포·지원·계정/단말 화면 | 구성·내 접근 권한 조회 연결. 반입·검토 요청/자료·과거 버전·별도 계정 승인/반려와 응답 유실 복구 화면을 추가. 파일 전송/서명 자동화·배포/지원/계정·단말 관리 조작은 후속 | PARTIAL |
| R21 | 등록된 외부 UI 패널·제한된 메시지 API | origin·권한·직접 제어/기록 접근 거부 | OPEN |
| R22 | 프로세스·권한·volume·network·variant 구성 | P 실행 파일의 pinned 설정·초기화/기동과 arm64 runtime draft image·비루트/read-only HTTPS/SIGTERM 검증. S arm64 runtime draft의 필수 stack·Rust/BT/UI 포함과 무동작 기동도 검증. S의 영속 process 계획·release-owned recipe·관리 모드 및 instance readiness를 추가. rx-hostd 제품 executable/동일 S image 포함·pinned 설치/원장·실제 Linux clock·명시적 drop proof 종료를 연결했다. FILE_SIMULATION은 실제 제품 binary로 P 통합을 검증하며 physical factory는 미등록이다. 실제 driver lifecycle authority·전체 variant/배포/Host supervision은 후속 | PARTIAL |
| R23 | 정상 종료·부분 장애·제한 재시작 | 지지 미정리 종료 금지·timeout kill 금지. Planner CLOSE와 run/visit 서비스·durable stop intent·시작 전 중단·응답 유실/재시작·저장 장애 중 P pause를 검증. P의 durable stop barrier와 API/writer drain·미결 보고 및 실제 프로세스 SIGTERM도 연결. S의 stop latch·dependency 종료 순서·제어 프로세스 종료 권한/강제 kill 거부와 software 재기동 예산을 추가. Host/전체 현장 종료·supervision은 후속 | PARTIAL |
| R24 | 호스트 관리 도구·고정 작업·유지보수 journal | 중복 교체·준비 중 P/Host 상실·재조정 | OPEN |
| R25 | 백업·복원·binary rollback 구별 | P/H 한쪽·양쪽 유실·generation·epoch 교차 시험 | PARTIAL |
| R26 | 자사 5개 필수 source 및 전이 의존 lock | Git8개/ROS metadata/ONNX·정책 pin, APT1824개 inventory 일치 거부, ROS42개 compile·모델4개 CPU Session load. 실제 장비와 전체 variant는 후속 | PARTIAL |
| R27 | 모의 환경과 실장비 접근 분리 | 모의 프로세스의 device/native network 권한 없음 | PARTIAL |
| R28 | 통합 시험·판정·독립 oracle·증거 반출 | SC/CO/V/OV 추적, PASS와 미수행 구별 | PARTIAL |
| R29 | 납품/운영교육/인건비·지원 공수 측정 구조 | 측정 정의·입력·근거·인수 결과 연결 | OPEN |
| R30 | 첫 현장 미확정 값 및 실제 commissioning 경계 | Q03UDVCPU·로봇/지그/신호 미확정 차단 | FIELD_BLOCKED |

R30의 현장 차단은 공통 구현을 중단시키지 않는다. 이 행의 구현상 완료는 미확정 입력의 강제 검증과 정직한 상태 표시이며, 실제 운전 검증은 제공되지 않은 현장 입력·실물 시험을 요구한다.
