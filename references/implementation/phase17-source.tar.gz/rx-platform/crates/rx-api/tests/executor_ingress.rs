//! Real TLS sockets and SQLite. Read/reconnect fixtures never send device commands.
mod support;
use rx_api::grpc::{Configuration, PlatformIngress, TlsMaterial};
use rx_application::*;
use rx_domain::{canonical, types::*};
use rx_protocol::{base, cell};
use rx_runtime::{
    application::{Application, Command, Handle, Reply},
    writer::Writer,
};
use rx_storage::SqliteRepository;
use std::{collections::BTreeMap, sync::Arc};
use tonic::transport::{
    Certificate as TlsCertificate, Channel, ClientTlsConfig, Identity as TlsIdentity,
};
fn id() -> Id {
    Id::new(uuid::Uuid::new_v4().to_string()).unwrap()
}
fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
struct TestClock;
impl Clock for TestClock {
    fn now(&self) -> TimePoint {
        TimePoint {
            clock_id: "test-clock".into(),
            ticks_ns: Counter(1000),
        }
    }
}
struct Deny;
impl QualificationAuthority for Deny {
    fn verify(&self, _: &CellConfiguration, _: &[ArtifactRef], _: &[Digest]) -> bool {
        false
    }
}
fn manifest(text: &str) -> Vec<u8> {
    use sha2::Digest as _;
    let json: serde_json::Value = serde_json::from_str(text).unwrap();
    sha2::Sha256::digest(canonical::bytes(&json).unwrap()).to_vec()
}
async fn connect(uri: &str, ca: &str, certificate: &str, key: &str) -> Channel {
    Channel::from_shared(uri.to_string())
        .unwrap()
        .tls_config(
            ClientTlsConfig::new()
                .domain_name("localhost")
                .ca_certificate(TlsCertificate::from_pem(ca))
                .identity(TlsIdentity::from_pem(certificate, key)),
        )
        .unwrap()
        .connect()
        .await
        .unwrap()
}
fn call(session: &base::Session) -> base::CallContext {
    base::CallContext {
        session_id: session.session_id.clone(),
        call_id: id().to_string(),
        request_key: None,
        expected_revision: None,
    }
}
#[tokio::test]
async fn executor_run_reads_require_both_negotiations_and_the_same_registered_certificate() {
    use rcgen::*;
    use sha2::Digest as _;
    let directory = tempfile::tempdir().unwrap();
    let db = directory.path().join("p.db");
    let configuration = support::configuration("cell/a");
    let config = configuration.clone();
    let writer = Writer::start(move || {
        let mut engine = Engine::open(
            SqliteRepository::open(db)?,
            TestClock,
            Deny,
            id(),
            Principal {
                id: name("admin"),
                client_namespace: name("admin"),
                roles: [Role::AccountAdmin, Role::Engineer, Role::Operator]
                    .into_iter()
                    .collect(),
                cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
                active: true,
            },
        )?;
        let session = engine.authenticated_session(
            &name("admin"),
            id(),
            TimePoint {
                clock_id: "test-clock".into(),
                ticks_ns: Counter(u64::MAX),
            },
        )?;
        let admin = Identity {
            principal: name("admin"),
            session: session.id,
            terminal: None,
        };
        engine.put_principal(
            &admin,
            Principal {
                id: name("executor"),
                client_namespace: name("executor"),
                roles: [Role::Executor].into_iter().collect(),
                cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
                active: true,
            },
            None,
        )?;
        engine.install_cell(&admin, config.clone())?;
        engine.create_run(
            &admin,
            id().as_str(),
            CreateRun {
                cell: config.id,
                recipe_digest: config.recipe.sha256,
                site_config_digest: config.site_config_digest,
                expected_cell: Counter(1),
            },
        )?;
        let mut other = support::configuration("cell/b");
        other.executor = name("other-executor");
        other.definition.sha256 = Digest::from_bytes([51; 32]);
        engine.install_cell(&admin, other.clone())?;
        engine.create_run(
            &admin,
            id().as_str(),
            CreateRun {
                cell: other.id,
                recipe_digest: other.recipe.sha256,
                site_config_digest: other.site_config_digest,
                expected_cell: Counter(1),
            },
        )?;
        Ok(Application::new(engine))
    })
    .await
    .unwrap();
    let handle = Handle::new(writer);
    let Reply::Installation(installation) = handle.call(Command::Installation).await.unwrap()
    else {
        panic!("installation")
    };
    let mut ca_params = CertificateParams::new(vec![]).unwrap();
    ca_params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
    ca_params.key_usages = vec![KeyUsagePurpose::KeyCertSign];
    let ca = CertifiedIssuer::self_signed(ca_params, KeyPair::generate().unwrap()).unwrap();
    let leaf = |label: &str, usage: ExtendedKeyUsagePurpose| {
        let key = KeyPair::generate().unwrap();
        let mut params = CertificateParams::new(vec![label.into()]).unwrap();
        params.extended_key_usages = vec![usage];
        params.key_usages = vec![KeyUsagePurpose::DigitalSignature];
        (params.signed_by(&key, &ca).unwrap(), key)
    };
    let (server, server_key) = leaf("localhost", ExtendedKeyUsagePurpose::ServerAuth);
    let (executor, executor_key) = leaf("executor", ExtendedKeyUsagePurpose::ClientAuth);
    let (alternate, alternate_key) = leaf("alternate", ExtendedKeyUsagePurpose::ClientAuth);
    let (unregistered, unregistered_key) =
        leaf("unregistered", ExtendedKeyUsagePurpose::ClientAuth);
    let fingerprint =
        |cert: &Certificate| Digest::from_bytes(sha2::Sha256::digest(cert.der().as_ref()).into());
    let release = Digest::from_bytes([8; 32]);
    let ingress = PlatformIngress::new(
        Arc::new(handle.clone()),
        Configuration {
            installation: installation.clone(),
            release_digest: release,
            allowed_certificates: BTreeMap::from([
                (fingerprint(&executor), name("executor")),
                (fingerprint(&alternate), name("executor")),
            ]),
        },
    )
    .await
    .unwrap();
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let uri = format!("https://{}", listener.local_addr().unwrap());
    let tls = TlsMaterial {
        server_certificate_pem: server.pem().into_bytes(),
        server_key_pem: server_key.serialize_pem().into_bytes(),
        client_ca_pem: ca.pem().into_bytes(),
    };
    let (stop, stopped) = tokio::sync::oneshot::channel();
    let task = tokio::spawn(async move {
        ingress
            .serve(listener, tls, async {
                let _ = stopped.await;
            })
            .await
            .unwrap();
    });
    let channel = connect(
        &uri,
        &ca.pem(),
        &executor.pem(),
        &executor_key.serialize_pem(),
    )
    .await;
    let alternate_channel = connect(
        &uri,
        &ca.pem(),
        &alternate.pem(),
        &alternate_key.serialize_pem(),
    )
    .await;
    let unregistered_channel = connect(
        &uri,
        &ca.pem(),
        &unregistered.pem(),
        &unregistered_key.serialize_pem(),
    )
    .await;
    let base_hash = manifest(include_str!(
        "../../../spec/contracts/v1.0/protocol_manifest.json"
    ));
    let cell_hash = manifest(include_str!(
        "../../../spec/cell_operations/v1.0/protocol_manifest.json"
    ));
    let hello = base::PeerHello {
        installation_id: installation.id.to_string(),
        store_generation: installation.store_generation.to_string(),
        peer_id: "executor".into(),
        role: base::Role::Executor as i32,
        boot_id: id().to_string(),
        release_digest: release.as_bytes().to_vec(),
        supported_versions: vec![base::Version {
            major: 1,
            minor: 0,
            schema_hash: base_hash.clone(),
        }],
        shared_clock_id: installation.clock_id.clone(),
        journal_id: None,
        last_seq: None,
    };
    let mut sessions = base::session_service_client::SessionServiceClient::new(channel.clone());
    let session = sessions.open(hello.clone()).await.unwrap().into_inner();
    let mut wrong_role = hello.clone();
    wrong_role.role = base::Role::Host as i32;
    wrong_role.journal_id = Some(id().to_string());
    wrong_role.last_seq = Some(0);
    assert_eq!(
        sessions.open(wrong_role).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );

    assert_eq!(
        sessions
            .open(hello.clone())
            .await
            .unwrap()
            .into_inner()
            .session_id,
        session.session_id
    );
    assert_eq!(
        base::session_service_client::SessionServiceClient::new(unregistered_channel)
            .open(hello.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::PermissionDenied
    );
    let identity = Identity {
        principal: name("executor"),
        session: Id::new(&session.session_id).unwrap(),
        terminal: None,
    };
    let Reply::Overview(overview) = handle
        .call(Command::Overview(identity.clone()))
        .await
        .unwrap()
    else {
        panic!("overview")
    };
    let run = overview
        .cells
        .iter()
        .find(|c| c.cell.value.id == configuration.id)
        .unwrap()
        .runs[0]
        .value
        .id
        .clone();
    let other_run = overview
        .cells
        .iter()
        .find(|c| c.cell.value.id == name("cell/b"))
        .unwrap()
        .runs[0]
        .value
        .id
        .clone();
    let request = base::RunRequest {
        context: Some(call(&session)),
        run_id: Some(run.to_string()),
        recipe_digest: vec![],
        site_config_digest: vec![],
    };
    let mut workflow = base::workflow_service_client::WorkflowServiceClient::new(channel.clone());
    assert_eq!(
        workflow.get_run(request.clone()).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    let cell_hello = cell::CellHello {
        base_session_id: session.session_id.clone(),
        peer_id: "executor".into(),
        base_manifest_hash: base_hash,
        cell_manifest_hash: cell_hash,
        cell_definition_digest: configuration.definition.sha256.as_bytes().to_vec(),
        shared_clock_id: installation.clock_id,
    };
    let mut cells = cell::cell_service_client::CellServiceClient::new(channel.clone());
    let mut mismatch = cell_hello.clone();
    mismatch.cell_manifest_hash[0] ^= 1;
    assert_eq!(
        cells.open(mismatch).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    cells.open(cell_hello.clone()).await.unwrap();
    let view = workflow
        .get_run(request.clone())
        .await
        .unwrap()
        .into_inner();
    assert_eq!(view.run_id, run.to_string());
    assert_eq!(view.state, base::RunState::Prepared as i32);
    assert_eq!(view.checkpoint.as_ref().unwrap().revision, view.revision);
    assert!(view.executor_session_id.is_none());
    let mut bad_revision = request.clone();
    bad_revision.context.as_mut().unwrap().expected_revision = Some(1);
    assert_eq!(
        workflow.get_run(bad_revision).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut bad_digest = request.clone();
    bad_digest.recipe_digest = vec![1; 32];
    assert_eq!(
        workflow.get_run(bad_digest).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut other = request.clone();
    other.run_id = Some(other_run.to_string());
    assert_eq!(
        workflow.get_run(other).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    let mut alternate_workflow =
        base::workflow_service_client::WorkflowServiceClient::new(alternate_channel);
    assert_eq!(
        alternate_workflow
            .get_run(request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unauthenticated
    );
    assert_eq!(
        workflow
            .start_run(request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unimplemented
    );
    let mut newer = hello.clone();
    newer.boot_id = id().to_string();
    let next = sessions.open(newer).await.unwrap().into_inner();
    assert_ne!(next.session_id, session.session_id);
    assert_eq!(
        workflow.get_run(request.clone()).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );
    assert_eq!(
        sessions.open(hello).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );
    let mut next_request = request;
    next_request.context = Some(call(&next));
    assert_eq!(
        workflow
            .get_run(next_request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::FailedPrecondition
    );
    let mut next_cell = cell_hello;
    next_cell.base_session_id = next.session_id;
    cells.open(next_cell).await.unwrap();
    let after = workflow.get_run(next_request).await.unwrap().into_inner();
    assert_ne!(after.state, base::RunState::Executing as i32);
    assert!(after.executor_session_id.is_none());
    stop.send(()).unwrap();
    task.await.unwrap();
    handle.close();
    handle.closed().await;
}
