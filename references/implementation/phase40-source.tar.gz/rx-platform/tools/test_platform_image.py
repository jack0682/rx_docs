#!/usr/bin/env python3
"""Run only the new uncommissioned platform image, using isolated disposable volumes/certificates."""
import argparse,json,os,socket,ssl,subprocess,tempfile,time,urllib.request,uuid
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--image',default='rx-platform:runtime-draft');parser.add_argument('--evidence',required=True,type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
def run(*argv,**kwargs):
    return subprocess.run(argv,check=True,capture_output=True,text=True,**kwargs).stdout.strip()
with socket.socket() as s:
    s.bind(('127.0.0.1',0));port=s.getsockname()[1]
suffix=uuid.uuid4().hex[:12];config_volume='rx-platform-config-'+suffix;data_volume='rx-platform-data-'+suffix;setup='rx-platform-setup-'+suffix;service='rx-platform-smoke-'+suffix
with tempfile.TemporaryDirectory(prefix='rx-platform-image-') as temporary:
    fixture=Path(temporary)/'fixture'
    env=os.environ.copy();env.update(RX_PLATFORM_IMAGE_FIXTURE=str(fixture),RX_PLATFORM_IMAGE_PORT=str(port))
    run(str(root/'tools/cargo'),'test','-p','rx-platformd','--test','composition','export_container_fixture','--locked','--','--ignored','--exact',cwd=root,env=env)
    try:
        for name in [config_volume,data_volume]:run('docker','volume','create',name)
        run('docker','create','--name',setup,'--user','0','--network','none','-v',config_volume+':/config','-v',data_volume+':/data','--entrypoint','/bin/sh',args.image,'-c','chmod 700 /config /data; chmod 600 /config/*; mkdir -p /data/runtime; /usr/local/bin/rx-platformd init /config/startup.json && chown -R 10001:10001 /data /config')
        run('docker','cp',str(fixture)+'/.',setup+':/config');run('docker','start','--attach',setup)
        setup_state=json.loads(run('docker','inspect',setup))[0]['State'];assert setup_state['ExitCode']==0,setup_state
        run('docker','run','-d','--name',service,'--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw','-v',config_volume+':/config:ro','-v',data_volume+':/data:rw','-p',f'127.0.0.1:{port}:8443',args.image,'run','/config/startup.json')
        context=ssl.create_default_context(cafile=str(fixture/'ca.pem'));context.load_cert_chain(str(fixture/'probe.pem'),str(fixture/'probe.key'))
        deadline=time.monotonic()+20;health=None;last_error=None
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
        while time.monotonic()<deadline:
            state=json.loads(run('docker','inspect',service))[0]
            assert state['State']['Running'],run('docker','logs',service)
            try:
                with opener.open(f'https://127.0.0.1:{port}/api/v1/health',timeout=2) as response:health=json.load(response)
                if health.get('admission_open'):break
            except (OSError,urllib.error.URLError) as error:last_error=str(error)
            time.sleep(.1)
        if health is None:
            print(json.dumps({'last_https_error':last_error,'container_logs':run('docker','logs',service),'process_status':run('docker','exec',service,'cat','/data/runtime/platform-status.json')}))
        assert health and health['writer_available'] and health['admission_open'],health
        inspected=json.loads(run('docker','inspect',service))[0]
        assert inspected['Config']['User']=='10001:10001';assert inspected['HostConfig']['ReadonlyRootfs'];assert inspected['HostConfig']['CapDrop']==['ALL']
        before=json.loads(run('docker','exec',service,'cat','/data/runtime/platform-status.json'))
        assert before['phase']=='SOFTWARE_READY_UNCOMMISSIONED';assert before['qualification_authority']=='NOT_CONNECTED'
        run('docker','stop','--time','15',service)
        stopped=json.loads(run('docker','inspect',service))[0];assert stopped['State']['ExitCode']==0,run('docker','logs',service)
        run('docker','cp',service+':/data/runtime/platform-status.json',str(Path(temporary)/'stopped.json'))
        after=json.loads((Path(temporary)/'stopped.json').read_text());assert after['phase']=='PROCESS_STOPPED';assert after['stop']['lifecycle']['phase']=='STOP_COMMITTED';assert not after['physical_shutdown_assessed']
        image=json.loads(run('docker','image','inspect',args.image))[0]
        result={'schema':'rx.platform-image-smoke.v1','status':'PASS','image_id':image['Id'],'os':image['Os'],'architecture':image['Architecture'],'user':inspected['Config']['User'],'read_only_root':True,'cap_drop':['ALL'],'https_health':health,'startup':before,'stop':after,'limitations':['uncommissioned draft authority','no Host/controller launch','no physical shutdown qualification','config/data volumes and test certificates were disposable']}
        args.evidence.parent.mkdir(parents=True,exist_ok=True);args.evidence.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS','image':image['Id']}))
    finally:
        for name in [service,setup]:subprocess.run(['docker','rm','-f',name],capture_output=True)
        for name in [config_volume,data_volume]:subprocess.run(['docker','volume','rm',name],capture_output=True)
