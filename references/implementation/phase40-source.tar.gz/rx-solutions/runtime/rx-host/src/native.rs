use crate::model::*;
use rx_domain::{intent::Intent, types::Id};
use std::sync::Arc;

/// Must not share the Host gate or depend on a successful database transaction.
pub trait LocalProtection: Send + Sync {
    fn react(&self, incident: ProtectionIncident);
}
pub trait NativeAdapter: Send {
    fn environment(&self) -> Environment;
    fn protection(&self) -> Arc<dyn LocalProtection>;
    /// Read-only, explicitly supported native sources. Default cannot synthesize readiness.
    fn observe_sources(
        &self,
        _cell: &rx_domain::types::Name,
        _sources: &[rx_domain::types::Name],
    ) -> Result<Vec<rx_domain::host_snapshot::SourceObservation>> {
        Err(HostError::Guard)
    }
    fn guard(&self, intent: &Intent, now: &rx_domain::types::TimePoint) -> Result<Guard>;
    /// Confirms no residual native command and required physical support/handover.
    fn can_handover(&self, resources: &[rx_domain::types::Name]) -> bool;
    /// Fresh physical/current-state evidence. Unsupported bindings must not synthesize it.
    fn handover_snapshot(&self, _resources: &[rx_domain::types::Name]) -> Result<LocalHandover> {
        Err(HostError::Guard)
    }
    /// Submit exactly once. Return a captured native fact, not a platform outcome.
    fn submit(&mut self, operation: &Id, invocation: &Id, intent: &Intent)
    -> Result<NativeCapture>;
    /// Read-only lookup; it must not re-submit the original command.
    fn lookup(&mut self, operation: &Id, invocation: &Id) -> Result<Option<NativeCapture>>;
}
/// Tests can stop a real process at the two non-atomic database/native boundaries.
/// No hook is configured from an external request.
pub trait BoundaryHook: Send + Sync {
    fn after_send_commit(&self) {}
    fn after_native_entry(&self) {}
}
pub struct NoHooks;
impl BoundaryHook for NoHooks {}
