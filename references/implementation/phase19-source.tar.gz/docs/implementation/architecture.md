# 구현 경계와 선행 설계 연결

## 소유권

| 구성 | 위치 | 의존 규칙 |
|---|---|---|
| rx-domain | platform crate | 순수 타입·정규화·조건·상태 전이. 시간·ID 생성·I/O는 호출자가 제공 |
| rx-ports | platform crate | 동기 원자 transaction 경계·저장용 typed envelope. SQLite 타입 노출 없음 |
| rx-storage | platform crate | 로컬 SQLite·writer 소유 lock·CAS·key/event/outbox·snapshot/backup |
| application/Runtime | platform crate | 요청 인증 후 key 조회→신규 요청의 상태/조건/CAS→단일 commit; 실제 Application Processor/단일 writer thread |
| protocol/API | platform crate | frozen codec·Host mTLS client, 로컬 HTTP BFF를 같은 application에 연결. P RPC 전체·LAN 인증/SSE는 후속 |
| host 관리 도구 | 후속 platform binary | 고정 software 작업·교체 진행 기록. 생산 권한 없음 |
| Host/native/ROS | solutions | 전달 gate·로컬 journal·실제 장비 의미. whole body outcome 쓰기 금지 |
| 공정 원본·변환·BT | solutions | 원본 의미/단계 ID 보존. native UNKNOWN을 자동 retry로 낮추지 않음 |
| UI | solutions | 시각적 편집·역할별 화면. 승인된 API만 요청; 판정 원장 별도 소유 금지 |

rx-ports의 Document는 저장 adapter를 도메인 schema에서 분리하는 envelope다. 공개 API 입력을 검증 없이 이 envelope에 넣는 경로는 만들지 않는다. application은 구체 typed domain을 먼저 검증해야 한다. 현재 저장 foundation만으로 셀 admission/T1 전체가 구현되었다고 주장하지 않는다.

## 앞선 계획에서 유지할 항목

- D2: 단일 P, 복수 셀, bounded queue·동기 writer, 외부 I/O는 transaction 밖. H native gate는 검사/소비/SEND_ENTERED/native 진입을 fence·취소와 직렬화.
- D3: 제품군 패키지+모델/모드 profile; 재사용 공정 원본·현장 binding·resolved plan·검증 기록 분리. case별 복구/재시작 권한은 재사용 패키지에 넣지 않음.
- D4: Linux/systemd host agent, 두 image, s6 자식 관리. effectful driver는 software-ready에서 기동하지 않음. 지지 미확인 때 종료 신호/timeout kill 금지.
- D5: LAN/현장 자체 계정/등록 단말. React 시각 편집은 RX 원본 작성; native capability는 Host 소유. scoped UI projection은 whole-site control journal과 다른 cursor.
- D6: 계약·모의·실장비·FAT·SAT·운영/사업 인수를 구별. native 효과는 독립 관측으로 검증. 제한적 SETUP의 선행 근거로 시험 범위를 확대.

## 초기 구현 결정

- Rust 1.98.1을 workspace에 별도 설치·고정. 사용자 shell rc 변경 없음.
- rusqlite 0.40.2의 bundled SQLite 사용. 실행 시 linked SQLite 3.51.3 이상 요구. 예전 0.38.0에 포함된 3.51.1은 WAL 수정 미포함이므로 채택하지 않음.
- JSON은 중복 key를 먼저 거부한 후 typed decode. counter는 문자열, enum/필드는 닫힌 집합, 의도는 JCS+domain-prefix SHA-256.
- 조건 tree 방어 한도는 깊이 32/노드 1024. 제품 profile 한도에 반영할 구현 값이며 실제 장비의 시간·반응 성능을 뜻하지 않음.
- SQLite 내부 revision/seq가 signed integer 범위를 소진하면 오류로 차단한다. wire uint64를 실수로 변환하거나 wrap하지 않는다.
- 최초 foundation 검증은 라이브러리 단위의 의미·원자성 증거다. 뒤 단계에서 wire 상호운용을 추가했으며 SIGKILL/power-loss·실물 성능은 아직 별도다.

## Wire 및 실행 경계 구체화

- rx-protocol은 generated Protobuf/gRPC와 strict wire/JSON codec을 소유한다. core에는 prost/tonic을 전파하지 않는다.
- proto/README.md에 서비스 이름·enum 이름·cell snapshot union의 구체 binding을 기록했다. 문서 기준판의 원래 hash는 변경하지 않는다.
- rx-solutions/interfaces는 platform export 도구가 만든 별도 hash-pinned source bundle이다. 다른 레포의 작업 경로에 대한 빌드 의존 없이 C++ 코드를 생성한다.
- rx-runtime의 writer는 SQLite를 직접 알지 않는다. 전용 스레드에서 생성한 application Processor만 실행하고 network/native I/O는 outbox consumer에 남긴다.
- 큐는 실행 중 항목을 포함하여 최대32, 일반24/제어8로 제한한다. 제어8개 burst 뒤 일반 항목을 처리해 일방적 기아를 방지한다. 실제 보호 반응이 이 DB queue를 기다려야 한다는 뜻은 아니다.
- 정상 close는 신규 접수 중단 후 이미 접수한 state command를 drain한다. reply timeout/연결 해제는 commit 취소 신호가 아니다. worker panic에서는 남은 receiver에 미확정/불가를 알리고 새 admission을 차단한다.
- writer enqueue 성공은 메모리 큐 수용일 뿐 외부 ADMITTED receipt가 아니다. application의 T1 durable commit 뒤에만 ADMITTED를 반환한다.
- 조건 평가의 현재 시각은 command를 실제 처리할 때 Clock port에서 얻는다. HTTP 수신 시점의 시각을 큐 대기 후에도 현재 시각으로 재사용하지 않는다.
- 고주기 control sample을 이 writer 큐에 넣지 않는다. 보호/무효화 사건과 일반 최신값 telemetry의 보존·합치기 규칙도 구별한다.

## Application 상태 소유

- rx-application은 설치·현재 자격·run/mandate·part/activation/work·resource/permit를 transaction 경계 안에서 변경한다. wire/storage 구현은 import하지 않는다.
- DB 내부 key는 entity 종류와 canonical identity digest로 만든다. 유효한 긴 외부 Name에 prefix를 붙여 Name 길이 제한을 깨뜨리지 않는다.
- principal namespace는 계정 수명 동안 고정한다. 인증 adapter가 확인한 Identity로 현재 session/principal/단말을 조회하며 caller의 역할 주장을 받지 않는다.
- CreateRun에는 실제 시작 예산이 없다. 첫 StartRun이 예산을 고정한다. 같은 시작의 재시도와 다른 예산의 새로운 의도를 혼동하지 않는다.
- 유한 단계 binding의 activation 유일키는 (run,node,visit)이며 part 관계는 별도 metadata다. part마다 visit=1을 재사용하지 않는다.
- 관측의 원본 evidence와 cell별 condition projection을 분리한다. 같은 원본이 여러 셀에서 쓰일 때 cell별 age 정책 차이를 증거 충돌로 오인하지 않는다.
- 실제 변화의 기록을 남기고도 API 오류를 반환해야 하는 경우, transaction은 오류 처분 값을 성공적으로 commit한 후 바깥에서 오류를 반환한다.
- 현재 Helper API는 공개 RPC 전체 구현이 아니다. 계약 메서드별 추가 필드/권한/key semantics와 실제 Host receipt/evidence 연결을 다음 단계에서 완성한다.

## Host 제어와 native 경계

- rx-solutions/runtime/rx-host는 Rust로 journal/gate를 소유하며, native port의 C++/ROS/SDK 구현은 solutions에 둔다.
- P 업무 authority는 재사용 SDK에서 제외한다. Host는 native receipt와 immutable evidence만 만들고 결과/허가의 상위 판단을 복제하지 않는다.
- native submit은 gate 안에서 수행하지만 동작 완료 대기를 의미하지 않는다. 실제 adapter가 제출 API에서 block할 수 있으면 그 호출이 해소되기 전 새 소유권을 주지 않는다.
- 별도 local protection port는 gate·DB와 분리한다. 실제 장비별 반응·지지·시간 보장은 해당 binding의 실물 검증 대상이다.
- 프로세스 kill fixture는 production binary에 기본 포함하지 않으며 test-harness feature로만 빌드한다.

## 실행 복원 상태의 저장 경계

Run 변경 transaction에서 activation/slot/공정 결정을 수집하고 실제 bytes의 내용 주소 artifact와 현재 RunSnapshot, 제어 사건을 함께 기록한다. artifact 생성 때문에 업무 Run revision을 별도로 올리지 않는다. 조회 시 현재 접근권, 현재 Run과 snapshot cut, 실제 payload의 digest/schema/size·연결을 대조한다.

과거 snapshot은 보존하며 현재 운전 허가로 해석하지 않는다. 로컬 HTTP의 frozen RunView 투영까지 연결했고, 원격 executor의 Session/Cell/GetRun 조회에도 연결했다. Workflow 변경·CommitCheckpoint·artifact 확보·C++ Frame 복원은 후속이다. 자세한 저장 구조와 장기 운전 용량 한계는 [checkpoint artifact 명세](../../rx-platform/crates/rx-application/CHECKPOINT_ARTIFACT.md)를 따른다.

실행기 세션은 [ExecutorPeer](../../rx-platform/crates/rx-application/EXECUTOR_PEER.md)로 관리한다. 재접속은 같은 session에 수렴하고, peer boot/binding 교체는 이전 세션 및 관련 운전 권한을 함께 철회한다. 폐기된 boot는 영속 tombstone으로 늦은 재진입을 거부한다. 등록과 transport liveness/readiness를 구별하며, 현재 wire는 Run 조회까지만 활성화했다.

## 실행기 명령과 접수 확인서

공개 BeginPartAttempt/ResolveActivation의 envelope·현재 peer/cell scope·key/fingerprint 검사를 application의 executor_requests에 두고, 실제 상태 변경은 기존 workflow와 공통 transition을 사용한다. 바뀐 mandate/visit/CAS 값을 같은 key로 숨기지 않는다. part/activation의 응답과 Run/checkpoint 변경은 같은 transaction에 저장한다.

신규 Work 생성의 ADMITTED control record seq를 같은 commit의 immutable AdmissionReceipt에 연결한다. P control journal ID는 installation/store generation/view에 결합하며 process boot와 구별한다. 공개 Cell.SubmitOperation의 유한 run envelope/Receipt 반환은 이 접수 근거에 연결했다. Run/activation/part/cell/parent와 중첩 context, 두 CAS를 검증하며 기존 submit transition·dispatcher를 사용한다. 연속 제어·복구 parent는 후속이다.

Operation.Get은 P의 현재 결과/지식/무결성/자원 처분을 그대로 반환한다. SUCCEEDED와 RELEASED를 합치지 않고, 후발 모순은 기존 outcome과 함께 DISPUTED/QUARANTINED로 표현한다. 실제 원격 E→P→별도 모의 H의 양쪽 응답 유실 시험과 native effect 수는 [유한 제출 명세](../../rx-platform/crates/rx-application/EXECUTOR_SUBMISSION.md)에 기록한다.
