use super::*;
use crate::{draft_bindings::*, process_draft::Version as DraftVersion};
use rx_process_contract::model::ActionBinding;
const DRAFT: &str = "rx.internal.process-draft-version.v1";
const BINDINGS: &str = "rx.internal.draft-bindings.v1";
fn catalog(cell: &CellConfiguration) -> Result<Catalog> {
    let digest = canonical::digest(
        "RX-DRAFT-BINDING-CATALOG-v1",
        &(
            cell.id.clone(),
            &cell.definition,
            &cell.envelope,
            cell.site_config_digest,
            &cell.steps,
        ),
    )
    .map_err(domain_error)?;
    let candidates = cell
        .steps
        .iter()
        .map(|step| {
            Ok(Candidate {
                step: step.id.clone(),
                host: step.host.clone(),
                target: step.intent.target.clone(),
                kind: step.intent.kind,
                resources: step.intent.resource_set.clone(),
                intent_digest: step.intent.digest().map_err(domain_error)?,
                step_digest: canonical::digest("RX-DRAFT-BINDING-STEP-v1", step)
                    .map_err(domain_error)?,
            })
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(Catalog {
        cell: cell.id.clone(),
        definition: cell.definition.sha256,
        envelope: cell.envelope.sha256,
        catalog_digest: digest,
        candidates,
    })
}
fn draft(tx: &mut dyn Transaction, cell: &Name, id: &Id) -> Result<DraftVersion> {
    let (_, d): (_, DraftVersion) = load(tx, "processdraft", id, DRAFT)?;
    if d.cell != *cell {
        return reject(Reject::Forbidden);
    }
    Ok(d)
}
impl<R: Repository, C: Clock, A: QualificationAuthority> Engine<R, C, A> {
    pub fn draft_binding_catalog(&mut self, identity: &Identity, cell: &Name) -> Result<Catalog> {
        let meta = &self.installation;
        let clock = &self.clock;
        self.repository.transact(|tx| {
            super::process_draft::read_access(tx, identity, meta, &clock.now(), cell)?;
            let (_, c): (_, Cell) = load(tx, "cell", cell, CELL)?;
            catalog(&c.configuration)
        })
    }
    pub fn save_draft_bindings(
        &mut self,
        identity: &Identity,
        key_: &Id,
        input: Save,
    ) -> Result<Version> {
        let meta = &self.installation;
        let clock = &self.clock;
        self.repository.transact(|tx| {
            let now = clock.now();
            lifecycle::require_serving(tx)?;
            let p = authorize(
                tx,
                identity,
                meta,
                &now,
                Some(&input.cell),
                Role::Engineer,
                false,
            )?;
            let d = draft(tx, &input.cell, &input.draft)?;
            let (scope, fingerprint) = request(
                meta,
                &p,
                "ProcessDraft.Bindings.Save",
                key_.as_str(),
                &input,
            )?;
            if let Some(v) = prior(tx, &scope, fingerprint, BINDINGS)? {
                return Ok(v);
            }
            if d.revision != input.source_revision {
                return reject(Reject::StaleRevision);
            }
            if !d.validation.structurally_valid {
                return reject(Reject::InvalidInput);
            }
            let (_, c): (_, Cell) = load(tx, "cell", &input.cell, CELL)?;
            let current = catalog(&c.configuration)?;
            if current.catalog_digest != input.catalog_digest {
                return reject(Reject::StaleRevision);
            }
            if input.selections.len() > 128
                || input
                    .selections
                    .keys()
                    .any(|b| !d.validation.required_bindings.contains(b))
            {
                return reject(Reject::InvalidInput);
            }
            let record_key = key("draftbindings", &input.draft);
            let old = tx.get(&record_key)?;
            let revision = match (&old, input.expected) {
                (None, None) => Counter(1),
                (Some(r), Some(expected)) => {
                    check_revision(r.revision, expected)?;
                    r.revision.increment().map_err(domain_error)?
                }
                _ => return reject(Reject::StaleRevision),
            };
            let mut resolved = BTreeMap::new();
            let mut origins = BTreeMap::new();
            for (binding, step) in &input.selections {
                let selected = c
                    .configuration
                    .steps
                    .iter()
                    .find(|s| &s.id == step)
                    .ok_or(StoreError::Rejected(Reject::CapabilityMissing))?;
                resolved.insert(
                    binding.clone(),
                    ActionBinding {
                        host: selected.host.clone(),
                        intent: selected.intent.normalized().map_err(domain_error)?,
                    },
                );
                origins.insert(
                    binding.clone(),
                    canonical::digest("RX-DRAFT-BINDING-STEP-v1", selected)
                        .map_err(domain_error)?,
                );
            }
            let missing = d
                .validation
                .required_bindings
                .iter()
                .filter(|b| !resolved.contains_key(*b))
                .cloned()
                .collect::<Vec<_>>();
            let value = Version {
                draft: input.draft.clone(),
                cell: input.cell,
                revision,
                source_revision: d.revision,
                source_digest: d.document_digest,
                catalog_digest: input.catalog_digest,
                selections: input.selections,
                origins,
                resolved,
                complete: missing.is_empty(),
                missing,
                updated_by: p.id,
                updated_at: now,
            };
            if canonical::bytes(&value).map_err(domain_error)?.len() > 262144 {
                return reject(Reject::InvalidInput);
            }
            tx.put(
                &record_key,
                old.map(|r| r.revision),
                &doc(BINDINGS, &value)?,
            )?;
            tx.put(
                &key("draftbindingsrevision", (&value.draft, revision)),
                None,
                &doc(BINDINGS, &value)?,
            )?;
            event(tx, "rx.event.draft-bindings-saved.v1", &value)?;
            remember(tx, &scope, fingerprint, BINDINGS, &value)?;
            Ok(value)
        })
    }
    pub fn draft_bindings(
        &mut self,
        identity: &Identity,
        cell: &Name,
        id: &Id,
        revision: Option<Counter>,
    ) -> Result<View> {
        let meta = &self.installation;
        let clock = &self.clock;
        self.repository.transact(|tx| {
            super::process_draft::read_access(tx, identity, meta, &clock.now(), cell)?;
            let d = draft(tx, cell, id)?;
            let (_, c): (_, Cell) = load(tx, "cell", cell, CELL)?;
            let current = catalog(&c.configuration)?;
            let binding = if let Some(revision) = revision {
                Some(load::<Version>(tx, "draftbindingsrevision", (id, revision), BINDINGS)?.1)
            } else {
                tx.get(&key("draftbindings", id))?
                    .map(|r| decode::<Version>(&r, BINDINGS))
                    .transpose()?
            };
            let mut stale = vec![];
            if let Some(b) = &binding {
                if b.cell != *cell || b.draft != *id {
                    return Err(StoreError::Integrity(
                        "draft binding identity differs".into(),
                    ));
                }
                if b.source_digest != d.document_digest {
                    stale.push(StaleReason::SourceChanged);
                }
                if b.catalog_digest != current.catalog_digest {
                    stale.push(StaleReason::CatalogChanged);
                }
            }
            Ok(View {
                cell: cell.clone(),
                draft: id.clone(),
                current_source_revision: d.revision,
                current_catalog_digest: current.catalog_digest,
                binding,
                stale,
            })
        })
    }
    pub fn draft_compile_input(
        &mut self,
        identity: &Identity,
        cell: &Name,
        id: &Id,
        source_revision: Counter,
        binding_revision: Counter,
    ) -> Result<rx_process_contract::compile_input::CompileInput> {
        let meta = &self.installation;
        let clock = &self.clock;
        self.repository.transact(|tx| {
            super::process_draft::read_access(tx, identity, meta, &clock.now(), cell)?;
            let d = draft(tx, cell, id)?;
            check_revision(d.revision, source_revision)?;
            let (_, b): (_, Version) = load(tx, "draftbindings", id, BINDINGS)?;
            check_revision(b.revision, binding_revision)?;
            let (_, c): (_, Cell) = load(tx, "cell", cell, CELL)?;
            let current = catalog(&c.configuration)?;
            if b.cell != *cell
                || b.draft != *id
                || b.source_digest != d.document_digest
                || b.catalog_digest != current.catalog_digest
            {
                return reject(Reject::StaleRevision);
            }
            if !b.complete || !d.validation.structurally_valid {
                return reject(Reject::InvalidInput);
            }
            let (_, source): (_, serde_json::Value) = load(
                tx,
                "processdraftdocument",
                (cell, d.document_digest),
                "rx.internal.process-draft-document.v1",
            )?;
            let input = rx_process_contract::compile_input::CompileInput {
                schema: name("rx.process-compile-input.v1"),
                draft: id.clone(),
                cell: cell.clone(),
                source_revision: d.revision,
                binding_revision: b.revision,
                source_document_digest: d.document_digest,
                bindings_digest: canonical::digest("RX-DRAFT-COMPILE-BINDINGS-v1", &b.resolved)
                    .map_err(domain_error)?,
                catalog_digest: current.catalog_digest,
                source,
                bindings: b.resolved,
            };
            input
                .validate()
                .map_err(|e| StoreError::Integrity(e.to_string()))?;
            Ok(input)
        })
    }
}
