#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /opt/rx/robotis/setup.bash
set -u
exec python3 /opt/rx/tools/solutions_status.py "$@"
