use rx_domain::{intent::*, types::*};
use rx_host::{native::*, simulation::*, *};
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::{
        Arc,
        atomic::{AtomicU64, Ordering},
    },
};
fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
fn id() -> Id {
    Id::new(uuid::Uuid::new_v4().to_string()).unwrap()
}
fn clock() -> ManualClock {
    ManualClock {
        clock_id: "simulation/boottime".into(),
        ticks: Arc::new(AtomicU64::new(1000)),
    }
}
fn intent() -> Intent {
    Intent {
        kind: Kind::EnsureState,
        target: name("sim/chuck"),
        profile_digest: Digest::from_bytes([1; 32]),
        site_config_digest: Digest::from_bytes([2; 32]),
        calibration_digests: vec![],
        resource_set: vec![name("sim/controller")],
        execution_timeout_ms: Counter(5000),
        prepare_validity_ms: Counter(1000),
        completion_rule: name("sim/closed"),
        cancel_rule: name("sim/stop"),
        body: Body::Predicate(PredicateGoal {
            predicate_id: name("chuck.closed"),
            target: TypedValue::Boolean(true),
            settle_ms: Counter(0),
        }),
    }
}
fn binding() -> Binding {
    Binding {
        host: name("host/sim"),
        platform: name("platform"),
        cell: name("cell/sim"),
        definition: ArtifactRef {
            sha256: Digest::from_bytes([3; 32]),
            schema_id: name("rx.cell-definition.v1"),
            size_bytes: Counter(1),
        },
        envelope: ArtifactRef {
            sha256: Digest::from_bytes([4; 32]),
            schema_id: name("rx.operating-envelope.v1"),
            size_bytes: Counter(1),
        },
        qualification: Id::new("55555555-5555-4555-8555-555555555555").unwrap(),
        qualification_revision: Counter(1),
        allowed_intents: vec![intent()],
        scope_ids: vec![name("scope/main")],
        condition_ids: vec![name("sim/ready")],
        environment: Environment::Simulation,
        purposes: [Purpose::Production, Purpose::Setup].into_iter().collect(),
    }
}
fn scopes(epoch: u64) -> BTreeMap<Name, Counter> {
    [(name("scope/main"), Counter(epoch))].into_iter().collect()
}
fn initialize<N: NativeAdapter, H: BoundaryHook>(
    host: &Host<N, ManualClock, H>,
    caller: &Caller,
    epoch: u64,
) -> StoredGrant {
    host.bind_platform(caller.clone()).unwrap();
    host.arm(
        caller,
        id(),
        &name("cell/sim"),
        Counter(epoch),
        &scopes(epoch),
        &BTreeSet::new(),
    )
    .unwrap();
    host.acquire_grant(
        caller,
        id(),
        vec![name("sim/controller")],
        Counter(epoch),
        Counter(10_000_000_000),
    )
    .unwrap()
}
fn request<N: NativeAdapter, H: BoundaryHook>(
    host: &Host<N, ManualClock, H>,
    grant: &StoredGrant,
    epoch: u64,
) -> Request {
    let intent = intent();
    let digest = intent.digest().unwrap();
    let operation = id();
    Request {
        operation: operation.clone(),
        intent,
        digest,
        grant: grant.id.clone(),
        permit: Permit {
            id: id(),
            operation,
            digest,
            cell: name("cell/sim"),
            epoch: Counter(epoch),
            scopes: scopes(epoch),
            envelope: binding().envelope.sha256,
            qualification: binding().qualification,
            qualification_revision: Counter(1),
            grant: grant.id.clone(),
            host_boot: host.boot_id().unwrap(),
            conditions: [name("sim/ready")].into_iter().collect(),
            expires_at: TimePoint {
                clock_id: "simulation/boottime".into(),
                ticks_ns: Counter(1_000_000_000),
            },
            source_digest: None,
            purpose: Purpose::Production,
            parent: PermitParent::Mandate(id()),
        },
    }
}
fn caller() -> Caller {
    Caller {
        peer: name("platform"),
        session: id(),
    }
}

#[test]
fn prepare_does_not_call_device_and_authorize_duplicates_are_receipt_lookup() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let request = request(&host, &grant, 1);
    let prepared = host.prepare(&caller, request.clone()).unwrap();
    assert!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .is_empty()
    );
    let result = host
        .authorize(
            &caller,
            request.clone(),
            prepared.invocation.as_ref().unwrap(),
        )
        .unwrap();
    assert_eq!(result.state, ReceiptState::ResultCaptured);
    let repeated = host
        .authorize(&caller, request, prepared.invocation.as_ref().unwrap())
        .unwrap();
    assert_eq!(result.journal_seq, repeated.journal_seq);
    assert_eq!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .len(),
        1
    );
    let journals = host.journals().unwrap();
    assert_ne!(journals.delivery_journal, journals.evidence_journal);
    let evidence = host.evidence_after(&caller, Counter(0), 128).unwrap();
    assert_eq!(evidence.len(), 1);
    assert_eq!(evidence[0].0, Counter(1));
    assert!(result.journal_seq.0 > evidence[0].0.0);
}

#[test]
fn altered_permit_and_unapproved_intent_are_rejected_before_effect() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let request = request(&host, &grant, 1);
    let prepared = host.prepare(&caller, request.clone()).unwrap();
    let mut changed = request.clone();
    changed.permit.purpose = Purpose::Setup;
    assert!(matches!(
        host.authorize(&caller, changed, prepared.invocation.as_ref().unwrap()),
        Err(HostError::Conflict)
    ));
    let mut changed = request;
    changed.intent.target = name("sim/other");
    assert!(host.prepare(&caller, changed).is_err());
    assert!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .is_empty()
    );
}

#[test]
fn same_grant_fence_requires_same_request_identity() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    host.bind_platform(caller.clone()).unwrap();
    let key = id();
    let resources = vec![name("sim/controller")];
    let first = host
        .acquire_grant(
            &caller,
            key.clone(),
            resources.clone(),
            Counter(1),
            Counter(100),
        )
        .unwrap();
    let duplicate = host
        .acquire_grant(&caller, key, resources.clone(), Counter(1), Counter(100))
        .unwrap();
    assert_eq!(first.id, duplicate.id);
    assert!(
        host.acquire_grant(&caller, id(), resources, Counter(1), Counter(100))
            .is_err()
    );
}

#[test]
fn renewal_replay_does_not_extend_expiry_and_expired_grant_stays_expired() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c.clone(),
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    host.bind_platform(caller.clone()).unwrap();
    let grant = host
        .acquire_grant(
            &caller,
            id(),
            vec![name("sim/controller")],
            Counter(1),
            Counter(100),
        )
        .unwrap();
    c.ticks.store(1050, Ordering::SeqCst);
    let renewed = host.renew_grant(&caller, &grant.id, Counter(1)).unwrap();
    c.ticks.store(1080, Ordering::SeqCst);
    assert_eq!(
        host.renew_grant(&caller, &grant.id, Counter(1))
            .unwrap()
            .expires_at,
        renewed.expires_at
    );
    c.ticks.store(1200, Ordering::SeqCst);
    assert!(host.renew_grant(&caller, &grant.id, Counter(2)).is_err());
}

#[test]
fn late_fence_replay_cannot_remove_a_new_arm_or_rewind_epoch() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    host.bind_platform(caller.clone()).unwrap();
    let fence = id();
    let block = id();
    let first = host
        .fence(
            &caller,
            fence.clone(),
            &name("cell/sim"),
            Counter(2),
            scopes(2),
            [block.clone()].into_iter().collect(),
        )
        .unwrap();
    let arm = id();
    host.arm(
        &caller,
        arm.clone(),
        &name("cell/sim"),
        Counter(2),
        &scopes(2),
        &[block.clone()].into_iter().collect(),
    )
    .unwrap();
    host.arm(
        &caller,
        arm,
        &name("cell/sim"),
        Counter(2),
        &scopes(2),
        &[block.clone()].into_iter().collect(),
    )
    .unwrap();
    let repeated = host
        .fence(
            &caller,
            fence,
            &name("cell/sim"),
            Counter(2),
            scopes(2),
            [block].into_iter().collect(),
        )
        .unwrap();
    assert_eq!(first.sequence, repeated.sequence);
    let grant = host
        .acquire_grant(
            &caller,
            id(),
            vec![name("sim/controller")],
            Counter(2),
            Counter(10_000_000_000),
        )
        .unwrap();
    assert!(host.prepare(&caller, request(&host, &grant, 2)).is_ok());
    assert!(
        host.fence(
            &caller,
            id(),
            &name("cell/sim"),
            Counter(1),
            scopes(1),
            BTreeSet::new()
        )
        .is_err()
    );
}

#[test]
fn prepared_rebind_retires_old_permit_permanently() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let old = request(&host, &grant, 1);
    let first = host.prepare(&caller, old.clone()).unwrap();
    let mut new = old.clone();
    new.permit.id = id();
    let rebound = host.prepare(&caller, new.clone()).unwrap();
    assert_eq!(first.invocation, rebound.invocation);
    assert!(host.prepare(&caller, old.clone()).is_err());
    assert!(
        host.authorize(&caller, old, first.invocation.as_ref().unwrap())
            .is_err()
    );
    host.authorize(&caller, new, rebound.invocation.as_ref().unwrap())
        .unwrap();
    assert_eq!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .len(),
        1
    );
}

struct ExpireAfterCommit(ManualClock);
impl BoundaryHook for ExpireAfterCommit {
    fn after_send_commit(&self) {
        self.0.ticks.store(2_000_000_000, Ordering::SeqCst);
    }
}
#[test]
fn expiry_during_commit_does_not_enter_native_and_is_not_retried() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::with_hooks(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c.clone(),
        vec![binding()],
        ExpireAfterCommit(c),
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let request = request(&host, &grant, 1);
    let prepared = host.prepare(&caller, request.clone()).unwrap();
    assert!(
        host.authorize(
            &caller,
            request.clone(),
            prepared.invocation.as_ref().unwrap()
        )
        .is_err()
    );
    assert_eq!(
        host.receipt(&caller, &request.operation).unwrap().state,
        ReceiptState::SendEntered
    );
    host.authorize(&caller, request, prepared.invocation.as_ref().unwrap())
        .unwrap();
    assert!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .is_empty()
    );
}

#[test]
fn cancellation_arriving_before_prepare_creates_permanent_tombstone() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let request = request(&host, &grant, 1);
    let first = host
        .void_before_send(&caller, request.operation.clone(), request.digest)
        .unwrap();
    let again = host
        .void_before_send(&caller, request.operation.clone(), request.digest)
        .unwrap();
    assert_eq!(first.sequence, again.sequence);
    assert!(matches!(
        host.prepare(&caller, request.clone()),
        Err(HostError::Voided)
    ));
    let receipt = host.receipt_view(&caller, &request.operation).unwrap();
    assert_eq!(
        receipt.stage,
        rx_protocol::base::ReceiptStage::NotDispatched as i32
    );
    assert!(receipt.invocation_id.is_none());
    assert!(receipt.operation_revision.is_none());
    assert!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .is_empty()
    );
}

struct BlockingDevice {
    device: FileDevice,
    entered: std::sync::mpsc::Sender<()>,
    release: std::sync::mpsc::Receiver<()>,
}
impl NativeAdapter for BlockingDevice {
    fn environment(&self) -> Environment {
        self.device.environment()
    }
    fn protection(&self) -> Arc<dyn LocalProtection> {
        self.device.protection()
    }
    fn guard(&self, intent: &Intent, now: &TimePoint) -> Result<Guard> {
        self.device.guard(intent, now)
    }
    fn can_handover(&self, r: &[Name]) -> bool {
        self.device.can_handover(r)
    }
    fn submit(&mut self, op: &Id, inv: &Id, intent: &Intent) -> Result<NativeCapture> {
        self.entered.send(()).unwrap();
        self.release.recv().unwrap();
        self.device.submit(op, inv, intent)
    }
    fn lookup(&mut self, op: &Id, inv: &Id) -> Result<Option<NativeCapture>> {
        self.device.lookup(op, inv)
    }
}
struct ReleaseGuard(Option<std::sync::mpsc::Sender<()>>);
impl Drop for ReleaseGuard {
    fn drop(&mut self) {
        if let Some(s) = self.0.take() {
            let _ = s.send(());
        }
    }
}
#[test]
fn native_submission_serializes_fence_while_protection_is_independent() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let device = FileDevice::open(directory.path().join("device"), c.clone()).unwrap();
    let protection = device.protection.clone();
    let (entered, wait) = std::sync::mpsc::channel();
    let (release, gate) = std::sync::mpsc::channel();
    let mut release = ReleaseGuard(Some(release));
    let native = BlockingDevice {
        device,
        entered,
        release: gate,
    };
    let host =
        Arc::new(Host::open(directory.path().join("host.db"), native, c, vec![binding()]).unwrap());
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    let request = request(&host, &grant, 1);
    let prepared = host.prepare(&caller, request.clone()).unwrap();
    let send_host = host.clone();
    let send_caller = caller.clone();
    let send = std::thread::spawn(move || {
        send_host.authorize(&send_caller, request, prepared.invocation.as_ref().unwrap())
    });
    wait.recv_timeout(std::time::Duration::from_secs(5))
        .unwrap();
    let (attempted, seen) = std::sync::mpsc::channel();
    let (finished, done) = std::sync::mpsc::channel();
    let fence_host = host.clone();
    let fence_caller = caller.clone();
    let fence = std::thread::spawn(move || {
        attempted.send(()).unwrap();
        let receipt = fence_host
            .fence(
                &fence_caller,
                id(),
                &name("cell/sim"),
                Counter(2),
                scopes(2),
                BTreeSet::new(),
            )
            .unwrap();
        finished.send(()).unwrap();
        receipt
    });
    seen.recv_timeout(std::time::Duration::from_secs(5))
        .unwrap();
    host.protection().react(ProtectionIncident::StoreFault);
    assert_eq!(protection.0.load(Ordering::SeqCst), 1);
    assert!(done.try_recv().is_err());
    release.0.take().unwrap().send(()).unwrap();
    let sent = send.join().unwrap().unwrap();
    let fenced = fence.join().unwrap();
    assert!(fenced.sequence > sent.journal_seq);
}

#[test]
fn simulated_device_has_an_independent_exclusive_owner() {
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let first = FileDevice::open(directory.path(), c.clone()).unwrap();
    assert!(matches!(
        FileDevice::open(directory.path(), c.clone()),
        Err(HostError::Busy)
    ));
    drop(first);
    assert!(FileDevice::open(directory.path(), c).is_ok());
}

#[test]
fn evidence_publication_cursor_is_durable_scoped_and_never_accepts_a_foreign_ack() {
    use rx_host::publication::*;
    let directory = tempfile::tempdir().unwrap();
    let c = clock();
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c.clone(),
        vec![binding()],
    )
    .unwrap();
    let caller = caller();
    let grant = initialize(&host, &caller, 1);
    for _ in 0..3 {
        let request = request(&host, &grant, 1);
        let prepared = host.prepare(&caller, request.clone()).unwrap();
        host.authorize(&caller, request, prepared.invocation.as_ref().unwrap())
            .unwrap();
    }
    let destination = Destination {
        platform: name("platform"),
        installation: id(),
        store_generation: id(),
    };
    let chunk = host.publication_chunk(&destination).unwrap();
    assert_eq!(chunk.first, Counter(1));
    assert_eq!(chunk.tail, Counter(3));
    assert_eq!(chunk.records.len(), 3);
    let ack = |through, sequence| PublicationAck {
        installation: destination.installation.clone(),
        store_generation: destination.store_generation.clone(),
        view_id: CONTROL_VIEW.into(),
        journal: chunk.journal.clone(),
        through: Counter(through),
        platform_sequence: Counter(sequence),
    };
    assert!(
        host.acknowledge_publication(&destination, ack(4, 10))
            .is_err()
    );
    let mut wrong = ack(1, 10);
    wrong.store_generation = id();
    assert!(host.acknowledge_publication(&destination, wrong).is_err());
    let cursor = host
        .acknowledge_publication(&destination, ack(2, 10))
        .unwrap();
    assert_eq!(
        host.acknowledge_publication(&destination, ack(1, 9))
            .unwrap(),
        cursor
    );
    assert!(
        host.acknowledge_publication(&destination, ack(1, 11))
            .is_err()
    );
    let chunk = host.publication_chunk(&destination).unwrap();
    assert_eq!(chunk.first, Counter(3));
    assert_eq!(chunk.records.len(), 1);
    drop(host);
    let host = Host::open(
        directory.path().join("host.db"),
        FileDevice::open(directory.path().join("device"), c.clone()).unwrap(),
        c,
        vec![binding()],
    )
    .unwrap();
    assert_eq!(host.publication_chunk(&destination).unwrap().cursor, cursor);
    let restored = Destination {
        store_generation: id(),
        ..destination
    };
    assert_eq!(host.publication_chunk(&restored).unwrap().first, Counter(1));
    assert_eq!(
        FileDevice::effects(directory.path().join("device"))
            .unwrap()
            .len(),
        3
    );
}
