use ed25519_dalek::{Signer, SigningKey};
use rx_domain::types::*;
use rx_package::*;
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::Arc,
};
fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
fn path(s: &str) -> PackagePath {
    PackagePath::new(s).unwrap()
}
fn contracts() -> ContractSet {
    ContractSet {
        base: Digest::from_bytes([1; 32]),
        cell: Digest::from_bytes([2; 32]),
        package_abi: name("rx.package-abi.v1"),
    }
}
fn target() -> Target {
    Target {
        os: OperatingSystem::Linux,
        architecture: Architecture::Amd64,
        ros_distribution: None,
    }
}
fn fixture() -> (
    Manifest,
    BTreeMap<PackagePath, Vec<u8>>,
    VerificationPolicy,
    SigningKey,
) {
    let key = SigningKey::from_bytes(&[42; 32]);
    let data = b"{\"schema\":\"rx.process-source.v1\"}".to_vec();
    let manifest = Manifest {
        schema: name("rx.package.v1"),
        package: name("example/tending"),
        version: "0.1.0".parse().unwrap(),
        publisher: name("example"),
        contracts: contracts(),
        targets: vec![target()],
        entry: EntryPoint::Process {
            source: path("process.json"),
        },
        permissions: vec![Permission::ArtifactRead],
        dependencies: vec![],
        assets: vec![],
        files: vec![FileEntry {
            path: path("process.json"),
            sha256: content_digest(&data),
            size_bytes: Counter(data.len() as u64),
            executable: false,
        }],
    };
    let trusted = TrustedPublisher {
        publisher: name("example"),
        verifying_key: key.verifying_key().to_bytes(),
        kinds: [PackageKind::Process, PackageKind::Ui, PackageKind::Device]
            .into_iter()
            .collect(),
        permissions: [
            Permission::ArtifactRead,
            Permission::NativeEndpoint { role: name("arm") },
            Permission::UiPanelRead {
                topic: name("overview"),
            },
        ]
        .into_iter()
        .collect(),
    };
    let policy = VerificationPolicy {
        publishers: BTreeMap::from([(name("test-key"), trusted)]),
        contracts: contracts(),
        target: target(),
        dependencies: BTreeMap::new(),
        assets: BTreeMap::new(),
        max_files: 128,
        max_content_bytes: 64 * 1024 * 1024,
    };
    (
        manifest,
        BTreeMap::from([(path("process.json"), data)]),
        policy,
        key,
    )
}
fn signed(manifest: &Manifest, key: &SigningKey) -> Vec<u8> {
    let key_id = name("test-key");
    let signature = key.sign(&signing_message(manifest, &key_id).unwrap());
    serde_json::to_vec(&SignatureEnvelope {
        key: key_id,
        signature: signature
            .to_bytes()
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect(),
    })
    .unwrap()
}
fn check(
    manifest: &Manifest,
    files: BTreeMap<PackagePath, Vec<u8>>,
    policy: &VerificationPolicy,
    key: &SigningKey,
) -> Result<VerifiedPackage> {
    verify_package(
        &serde_json::to_vec(manifest).unwrap(),
        &signed(manifest, key),
        files,
        policy,
    )
}
#[test]
fn signed_content_is_immutable_and_signature_is_bound_to_key_identity() {
    let (manifest, files, mut policy, key) = fixture();
    let original = files[&path("process.json")].clone();
    let verified = check(&manifest, files.clone(), &policy, &key).unwrap();
    assert_eq!(verified.file(&path("process.json")).unwrap(), original);
    let mut changed = files;
    changed.get_mut(&path("process.json")).unwrap().push(0);
    assert!(matches!(
        check(&manifest, changed, &policy, &key),
        Err(Error::Content(_))
    ));
    let mut envelope: SignatureEnvelope = serde_json::from_slice(&signed(&manifest, &key)).unwrap();
    policy
        .publishers
        .insert(name("alias"), policy.publishers[&name("test-key")].clone());
    envelope.key = name("alias");
    assert!(matches!(
        verify_package(
            &serde_json::to_vec(&manifest).unwrap(),
            &serde_json::to_vec(&envelope).unwrap(),
            BTreeMap::from([(path("process.json"), original)]),
            &policy
        ),
        Err(Error::Signature)
    ));
}
#[test]
fn closed_paths_and_inventory_reject_traversal_aliases_and_hidden_files() {
    for value in [
        "../secret",
        "/absolute",
        "a/../b",
        "a//b",
        "C:secret",
        "dir\\x",
        "CON.txt",
        "a/lpt1",
        "x/",
        "a.",
        "a b",
    ] {
        assert!(PackagePath::new(value).is_err(), "{value}");
    }
    let (mut manifest, mut files, policy, key) = fixture();
    files.insert(path("extra.txt"), vec![]);
    assert!(matches!(
        check(&manifest, files.clone(), &policy, &key),
        Err(Error::Content(_))
    ));
    files.remove(&path("extra.txt"));
    manifest.files.push(FileEntry {
        path: path("PROCESS.json"),
        sha256: manifest.files[0].sha256,
        size_bytes: manifest.files[0].size_bytes,
        executable: false,
    });
    assert!(matches!(
        check(&manifest, files, &policy, &key),
        Err(Error::Invalid(_))
    ));
}
#[test]
fn package_kind_target_contract_and_publisher_scope_are_checked() {
    let (mut manifest, files, mut policy, key) = fixture();
    policy.target.ros_distribution = Some(name("jazzy"));
    check(&manifest, files.clone(), &policy, &key).unwrap();
    manifest.targets[0].ros_distribution = Some(name("humble"));
    assert!(matches!(
        check(&manifest, files.clone(), &policy, &key),
        Err(Error::Incompatible)
    ));
    manifest.targets[0].ros_distribution = None;
    policy.target = target();
    manifest
        .permissions
        .push(Permission::NativeEndpoint { role: name("arm") });
    assert!(matches!(
        check(&manifest, files.clone(), &policy, &key),
        Err(Error::Untrusted)
    ));
    manifest.permissions.pop();
    policy.target.architecture = Architecture::Arm64;
    assert!(matches!(
        check(&manifest, files.clone(), &policy, &key),
        Err(Error::Incompatible)
    ));
    policy.target = target();
    policy.contracts.cell = Digest::from_bytes([7; 32]);
    assert!(matches!(
        check(&manifest, files.clone(), &policy, &key),
        Err(Error::Incompatible)
    ));
    policy.contracts = contracts();
    policy.publishers.get_mut(&name("test-key")).unwrap().kinds = BTreeSet::new();
    assert!(matches!(
        check(&manifest, files, &policy, &key),
        Err(Error::Untrusted)
    ));
}
#[test]
fn dependency_closure_is_pinned_and_rechecked_against_current_trust() {
    let (mut dependency, files, mut policy, key) = fixture();
    dependency.package = name("example/base");
    let verified = Arc::new(check(&dependency, files.clone(), &policy, &key).unwrap());
    let mut root = dependency.clone();
    root.package = name("example/root");
    root.dependencies.push(Dependency {
        package: dependency.package.clone(),
        version: dependency.version.clone(),
        manifest_digest: verified.digest(),
        kind: PackageKind::Process,
    });
    assert!(matches!(
        check(&root, files.clone(), &policy, &key),
        Err(Error::Dependency(_))
    ));
    policy
        .dependencies
        .insert(dependency.package.clone(), verified);
    check(&root, files.clone(), &policy, &key).unwrap();
    root.dependencies[0].manifest_digest = Digest::from_bytes([99; 32]);
    assert!(matches!(
        check(&root, files.clone(), &policy, &key),
        Err(Error::Dependency(_))
    ));
    root.dependencies[0].manifest_digest = policy.dependencies[&dependency.package].digest();
    // The direct dependency's signed file cannot turn into a different target after verification.
    policy.target = Target {
        os: OperatingSystem::Windows,
        ..target()
    };
    root.targets.push(policy.target.clone());
    assert!(matches!(
        check(&root, files, &policy, &key),
        Err(Error::Incompatible)
    ));
}
#[test]
fn canonical_set_order_is_stable_and_duplicate_json_fields_are_rejected() {
    let (mut manifest, files, policy, key) = fixture();
    manifest.targets.push(Target {
        architecture: Architecture::Arm64,
        ..target()
    });
    let before = manifest_bytes(&manifest).unwrap();
    manifest.targets.reverse();
    assert_eq!(manifest_bytes(&manifest).unwrap(), before);
    let body = serde_json::to_string(&manifest).unwrap();
    let duplicate = body.replacen('{', "{\"publisher\":\"attacker\",", 1);
    assert!(matches!(
        verify_package(
            duplicate.as_bytes(),
            &signed(&manifest, &key),
            files,
            &policy
        ),
        Err(Error::Invalid(_))
    ));
}

#[test]
fn directory_verification_owns_bytes_and_rejects_links() {
    let (manifest, files, policy, key) = fixture();
    let temp = tempfile::tempdir().unwrap();
    std::fs::write(
        temp.path().join("manifest.json"),
        serde_json::to_vec(&manifest).unwrap(),
    )
    .unwrap();
    std::fs::write(
        temp.path().join("manifest.sig.json"),
        signed(&manifest, &key),
    )
    .unwrap();
    for (path, data) in &files {
        std::fs::write(temp.path().join(path.as_str()), data).unwrap();
    }
    let package = rx_package::directory::verify_directory(temp.path(), &policy).unwrap();
    std::fs::write(
        temp.path().join("process.json"),
        b"changed after verification",
    )
    .unwrap();
    assert_eq!(
        package.file(&path("process.json")).unwrap(),
        files[&path("process.json")]
    );
    assert!(rx_package::directory::verify_directory(temp.path(), &policy).is_err());
    #[cfg(unix)]
    {
        std::fs::remove_file(temp.path().join("process.json")).unwrap();
        std::os::unix::fs::symlink("/etc/hosts", temp.path().join("process.json")).unwrap();
        assert!(matches!(
            rx_package::directory::verify_directory(temp.path(), &policy),
            Err(Error::Content(_))
        ));
    }
}

#[test]
fn dependency_cannot_pull_an_older_copy_of_the_root_back_into_the_bundle() {
    let (mut old_root, files, mut policy, key) = fixture();
    old_root.package = name("example/a");
    let old = Arc::new(check(&old_root, files.clone(), &policy, &key).unwrap());
    policy
        .dependencies
        .insert(old_root.package.clone(), old.clone());
    let mut child = old_root.clone();
    child.package = name("example/b");
    child.dependencies = vec![Dependency {
        package: old_root.package.clone(),
        version: old_root.version.clone(),
        manifest_digest: old.digest(),
        kind: PackageKind::Process,
    }];
    let child_verified = Arc::new(check(&child, files.clone(), &policy, &key).unwrap());
    policy
        .dependencies
        .insert(child.package.clone(), child_verified.clone());
    let mut next = old_root;
    next.version = "0.2.0".parse().unwrap();
    next.dependencies = vec![Dependency {
        package: child.package,
        version: child.version,
        manifest_digest: child_verified.digest(),
        kind: PackageKind::Process,
    }];
    assert!(matches!(
        check(&next, files, &policy, &key),
        Err(Error::Dependency(_))
    ));
}

#[test]
fn a_dependency_verified_before_key_revocation_is_not_retrusted_implicitly() {
    let (mut dependency, files, mut policy, key) = fixture();
    dependency.package = name("example/dependency");
    let verified = Arc::new(check(&dependency, files.clone(), &policy, &key).unwrap());
    policy
        .dependencies
        .insert(dependency.package.clone(), verified.clone());
    let mut root = dependency.clone();
    root.package = name("example/root");
    root.dependencies = vec![Dependency {
        package: dependency.package,
        version: dependency.version,
        manifest_digest: verified.digest(),
        kind: PackageKind::Process,
    }];
    let root_key = SigningKey::from_bytes(&[43; 32]);
    let key_id = name("root-key");
    let trusted = TrustedPublisher {
        publisher: name("example"),
        verifying_key: root_key.verifying_key().to_bytes(),
        kinds: [PackageKind::Process].into_iter().collect(),
        permissions: [Permission::ArtifactRead].into_iter().collect(),
    };
    policy.publishers.insert(key_id.clone(), trusted);
    policy.publishers.remove(&name("test-key"));
    let signature = root_key.sign(&signing_message(&root, &key_id).unwrap());
    let envelope = SignatureEnvelope {
        key: key_id,
        signature: signature
            .to_bytes()
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect(),
    };
    assert!(matches!(
        verify_package(
            &serde_json::to_vec(&root).unwrap(),
            &serde_json::to_vec(&envelope).unwrap(),
            files,
            &policy
        ),
        Err(Error::Untrusted)
    ));
}
