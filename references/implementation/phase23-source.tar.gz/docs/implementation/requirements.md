# 구현 요구·검증 추적표

상태: OPEN / PARTIAL / IMPLEMENTED / VERIFIED / FIELD_BLOCKED. VERIFIED에는 구체 시험과 결과가 필요하다. 파일 존재만으로 기능을 검증했다고 표시하지 않는다.

| ID | 요구 | 증거/완료 판단 | 상태 |
|---|---|---|---|
| R01 | 두 독립 레포·두 이미지·Rust ROS 비의존 core | 레포·의존 그래프·이미지 빌드 | PARTIAL |
| R02 | 공통·셀 v1 schema와 strict codec, 정확한 enum/optional/정규화 | Rust/C++ golden vectors, unknown/duplicate 입력 거부 | PARTIAL |
| R03 | intent 동일성·key/activation/slot 유일성 | 중복·충돌·재접속·동시성 및 외부 envelope 검사. S key/body 선행 commit·미확정 보존·확인된 CAS 거부 후 새 attempt 검증 | PARTIAL |
| R04 | T1–T5, SQLite 단일 writer·WAL/FULL | commit 경계 fault injection, atomic rollback | PARTIAL |
| R05 | Host PREPARED/SEND_ENTERED/VOIDED 및 별도 evidence journal | native 진입·restart, publisher131개/ack 유실·H cursor 보존. 전체 전달/복원은 후속 | PARTIAL |
| R06 | 결과/지식/무결성/자원 처분 분리 | UNKNOWN 왕복·후발 모순·지지 인계 및 공개 OperationView의 독립 상태 축 검증. 영속 조회 계획·false 관측 보존·실제 해제와 조회 응답 분리 추가 | PARTIAL |
| R07 | grant/fence/epoch/permit와 native gate | 자동 전달/응답 유실/NOT_FOUND/중복 receipt/Fence 검증. 전체 취소·rebind는 후속 | PARTIAL |
| R08 | 조건 평가·관측 age/source/단위·세대 | clock/freshness/unknown/모순 fixture | PARTIAL |
| R09 | RunMandate·part/operation 예산·activation/checkpoint | restart 중 사용량 보존·마지막 part 완료. PauseRun의 run/cell closure·fence·최종 응답 원자성 추가. Run/slot/artifact 동일 commit·읽기 검증; 실행기 원격 Run 조회 연결. BeginPart/ResolveActivation 전체 payload·실제 mTLS 연결. 공유 checkpoint DTO·별도 S 복원 reader/C++ Frame 전달 연결. checkpoint 변경/전체 worker 복원은 후속 | PARTIAL |
| R10 | 개입·절차·복구·재시작·비운전 종료 | CO03–12/16/26–28 대응 시험 | PARTIAL |
| R11 | 여러 셀의 장비·제어기·소재 지지 자원 공유 | alias·공유 JTC·양쪽 지지 해제 반례 | PARTIAL |
| R12 | 고주기 stream latest-only·expiry·단일 consumer | 재정렬·old ticket·권한 변경·재생 금지 | OPEN |
| R13 | 제품군+모델/모드 profile·필수 자사 지원표 | 필수5개 source·22개 구성 catalogue/source hash 검증. 실제 profile/장비 검증은 후속 | PARTIAL |
| R14 | 선언형 공정·현장 binding·resolved plan·BT 변환 | 원본/compiler/frontier와 C++ BT 노드 실행 시험. P 내부 checkpoint/eligibility 검증 추가. P artifact/로컬 RunView 조회 연결. 인증된 S snapshot/artifact client와 C++ Frame 경계 추가. 영속 유한 mutation worker 연결. PauseExecutor·RequestHandover와 응답 유실 후 해제 관측도 연결. 나머지 요청 종류/daemon/CommitCheckpoint는 후속 | PARTIAL |
| R15 | 독립 검증 패키지·유형별 권한·변경 영향 | 서명/내용/종류·권한/전이 의존 검증. 설치/활성/qualification·변경 영향은 후속 | PARTIAL |
| R16 | HTTP/gRPC 동일 application·mTLS/현장 계정/단말 | 인증·권한·회수 namespace·우회 거부. Executor Session/Cell/GetRun/BeginPart/ResolveActivation/유한 Submit·Operation.Get/Reconcile 실제 mTLS. 원격 E·자동 P→H 경로/응답 유실 검증 | PARTIAL |
| R17 | 일관 snapshot·SSE·권한별 UI projection | 권한별 overview 구현. 감사/control 저장·cursor 분리와 RunSnapshot/current execution cut 구현. 전체 Event wire 매핑·paging/SSE는 미완료 | PARTIAL |
| R18 | 시각적 공정 편집·새 초안·검증·비교·변환 | 실제 저장·CAS 충돌·오류 위치·BT 대응 | OPEN |
| R19 | 운영/실적/조건/개입/복구 화면 | 로컬 운영/기록·응답 유실/동일 key 회수·stale 검토 시험. 실적/복구 전체는 후속 | PARTIAL |
| R20 | 구성·검증·배포·지원·계정/단말 화면 | 구성·내 접근 권한 조회 연결. 검증/배포/지원/계정·단말 관리 조작은 후속 | PARTIAL |
| R21 | 등록된 외부 UI 패널·제한된 메시지 API | origin·권한·직접 제어/기록 접근 거부 | OPEN |
| R22 | 프로세스·권한·volume·network·variant 구성 | 이미지별 manifest·무동작 startup | OPEN |
| R23 | 정상 종료·부분 장애·제한 재시작 | 지지 미정리 종료 금지·timeout kill 금지 | PARTIAL |
| R24 | 호스트 관리 도구·고정 작업·유지보수 journal | 중복 교체·준비 중 P/Host 상실·재조정 | OPEN |
| R25 | 백업·복원·binary rollback 구별 | P/H 한쪽·양쪽 유실·generation·epoch 교차 시험 | PARTIAL |
| R26 | 자사 5개 필수 source 및 전이 의존 lock | pin 확인·컨테이너 compile·모델별 로딩 | PARTIAL |
| R27 | 모의 환경과 실장비 접근 분리 | 모의 프로세스의 device/native network 권한 없음 | PARTIAL |
| R28 | 통합 시험·판정·독립 oracle·증거 반출 | SC/CO/V/OV 추적, PASS와 미수행 구별 | PARTIAL |
| R29 | 납품/운영교육/인건비·지원 공수 측정 구조 | 측정 정의·입력·근거·인수 결과 연결 | OPEN |
| R30 | 첫 현장 미확정 값 및 실제 commissioning 경계 | Q03UDVCPU·로봇/지그/신호 미확정 차단 | FIELD_BLOCKED |

R30의 현장 차단은 공통 구현을 중단시키지 않는다. 이 행의 구현상 완료는 미확정 입력의 강제 검증과 정직한 상태 표시이며, 실제 운전 검증은 제공되지 않은 현장 입력·실물 시험을 요구한다.
