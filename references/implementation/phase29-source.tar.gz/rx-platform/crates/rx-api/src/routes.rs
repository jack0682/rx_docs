use crate::{
    auth::{Auth, COOKIE, Credentials, SESSION_SECONDS},
    error::ApiError,
};
use axum::{
    Json, Router,
    body::Bytes,
    extract::{ConnectInfo, DefaultBodyLimit, Query, Request, State},
    http::{HeaderMap, HeaderValue, Method, StatusCode, Uri, header},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{get, post},
};
use rx_application::{CellConfiguration, CreateRun, Identity, StartRun};
use rx_domain::{canonical, types::*};
use rx_runtime::{
    application::{ApplicationPort, Command, Reply},
    writer::Status,
};
use serde::{Deserialize, Serialize, de::DeserializeOwned};
use std::{net::SocketAddr, sync::Arc};

/// Deliberately supports loopback development only. LAN requires a separate authenticated TLS ingress.
#[derive(Clone)]
pub struct LocalPolicy {
    origin: String,
    host: String,
}
impl LocalPolicy {
    pub fn new(origin: &str) -> Result<Self, String> {
        let uri: Uri = origin.parse().map_err(|_| "invalid public origin")?;
        if uri.scheme_str() != Some("http")
            || !matches!(uri.host(), Some("127.0.0.1" | "[::1]" | "localhost"))
            || uri.path_and_query().is_some_and(|p| p.as_str() != "/")
            || origin.ends_with('/')
        {
            return Err(
                "local service requires an exact HTTP loopback origin without trailing slash"
                    .into(),
            );
        }
        Ok(Self {
            origin: origin.into(),
            host: uri.authority().ok_or("origin authority")?.to_string(),
        })
    }
}
#[derive(Clone)]
struct ApiState {
    runtime: Arc<dyn ApplicationPort>,
    auth: Arc<Auth>,
    policy: LocalPolicy,
}

pub fn router(
    runtime: Arc<dyn ApplicationPort>,
    credentials: Credentials,
    policy: LocalPolicy,
) -> Result<Router, String> {
    let state = ApiState {
        runtime,
        auth: Arc::new(Auth::new(credentials)?),
        policy,
    };
    Ok(Router::new()
        .route("/api/v1/health", get(health))
        .route("/api/v1/session", post(login).get(profile))
        .route("/api/v1/session/end", post(logout))
        .route("/api/v1/overview", get(overview))
        .route("/api/v1/cell", get(cell))
        .route("/api/v1/cells", post(install_cell))
        .route("/api/v1/runs", post(create_run))
        .route("/api/v1/run/checkpoint", get(run_checkpoint))
        .route("/api/v1/run/checkpoint/artifact", get(checkpoint_artifact))
        .route("/api/v1/runs/start", post(start_run))
        .route("/api/v1/cells/hold", post(hold))
        .route("/api/v1/cases", get(cases))
        .route("/api/v1/case", get(case_detail))
        .route("/api/v1/cases/open", post(open_case))
        .route("/api/v1/cases/acknowledge", post(acknowledge_case))
        .fallback(|| async { ApiError::new(StatusCode::NOT_FOUND, "NOT_FOUND") })
        .layer(DefaultBodyLimit::max(1024 * 1024))
        .layer(middleware::from_fn_with_state(state.clone(), ingress))
        .with_state(state))
}

async fn ingress(State(state): State<ApiState>, request: Request, next: Next) -> Response {
    let result = validate_ingress(&state.policy, &request);
    let mut response = match result {
        Ok(()) => next.run(request).await,
        Err(error) => error.into_response(),
    };
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response
        .headers_mut()
        .insert(header::PRAGMA, HeaderValue::from_static("no-cache"));
    response.headers_mut().insert(
        header::X_CONTENT_TYPE_OPTIONS,
        HeaderValue::from_static("nosniff"),
    );
    response.headers_mut().insert(
        header::CONTENT_SECURITY_POLICY,
        HeaderValue::from_static("default-src 'none'; frame-ancestors 'none'"),
    );
    response
}
fn exactly_one<'a>(headers: &'a HeaderMap, name: &str) -> Option<&'a str> {
    let mut values = headers.get_all(name).iter();
    let first = values.next()?.to_str().ok()?;
    if values.next().is_some() {
        None
    } else {
        Some(first)
    }
}
fn validate_ingress(policy: &LocalPolicy, request: &Request) -> Result<(), ApiError> {
    let peer = request
        .extensions()
        .get::<ConnectInfo<SocketAddr>>()
        .ok_or_else(ApiError::forbidden)?;
    if !peer.0.ip().is_loopback() || exactly_one(request.headers(), "host") != Some(&policy.host) {
        return Err(ApiError::forbidden());
    }
    let headers = request.headers();
    if headers.contains_key("origin") && exactly_one(headers, "origin") != Some(&policy.origin) {
        return Err(ApiError::forbidden());
    }
    if !matches!(*request.method(), Method::GET | Method::HEAD) {
        if exactly_one(headers, "origin") != Some(&policy.origin)
            || exactly_one(headers, "x-rx-client") != Some("browser-v1")
        {
            return Err(ApiError::forbidden());
        }
        if exactly_one(headers, "content-type")
            .is_none_or(|v| !matches!(v, "application/json" | "application/json; charset=utf-8"))
        {
            return Err(ApiError::new(
                StatusCode::UNSUPPORTED_MEDIA_TYPE,
                "JSON_REQUIRED",
            ));
        }
    }
    Ok(())
}
fn decode<T: DeserializeOwned>(body: &[u8]) -> Result<T, ApiError> {
    canonical::decode_json(body).map_err(|_| ApiError::invalid())
}
fn cookie(headers: &HeaderMap) -> Result<&str, ApiError> {
    let mut found = None;
    for value in headers.get_all(header::COOKIE).iter() {
        for segment in value
            .to_str()
            .map_err(|_| ApiError::unauthenticated())?
            .split(';')
        {
            let Some((key, value)) = segment.trim().split_once('=') else {
                continue;
            };
            if key == COOKIE {
                if found.is_some()
                    || value.len() != 64
                    || !value
                        .bytes()
                        .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
                {
                    return Err(ApiError::unauthenticated());
                }
                found = Some(value);
            }
        }
    }
    found.ok_or_else(ApiError::unauthenticated)
}
fn identity(state: &ApiState, headers: &HeaderMap) -> Result<Identity, ApiError> {
    state.auth.resolve(cookie(headers)?)
}
fn mismatch() -> ApiError {
    ApiError::unavailable()
}

async fn health(State(s): State<ApiState>) -> Response {
    let ready = s.runtime.status() == Status::Running;
    (
        if ready {
            StatusCode::OK
        } else {
            StatusCode::SERVICE_UNAVAILABLE
        },
        Json(serde_json::json!({
            "service":"rx-platform", "mode":"DEVELOPMENT_LOOPBACK", "writer_available":ready,
            "device_control_enabled":false, "terminal_authenticated":false
        })),
    )
        .into_response()
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Login {
    principal: String,
    password: String,
}
async fn login(State(s): State<ApiState>, body: Bytes) -> Result<Response, ApiError> {
    if body.len() > 4096 {
        return Err(ApiError::invalid());
    }
    let value: Login = decode(&body)?;
    let principal = s.auth.verify(value.principal, value.password).await?;
    let id = Id::new(uuid::Uuid::new_v4().to_string()).map_err(|_| mismatch())?;
    let reply = s
        .runtime
        .request(Command::OpenUserSession {
            principal: principal.clone(),
            id,
            ttl_ns: Counter(SESSION_SECONDS * 1_000_000_000),
        })
        .await?;
    let Reply::Session(session) = reply else {
        return Err(mismatch());
    };
    // No body/header can set a terminal certificate or service identity.
    let identity = Identity {
        principal,
        session: session.id,
        terminal: None,
    };
    let Reply::Profile(profile) = s
        .runtime
        .request(Command::UserProfile(identity.clone()))
        .await?
    else {
        return Err(mismatch());
    };
    let token = s.auth.insert(identity)?;
    let mut response = Json(profile).into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_str(&format!(
            "{COOKIE}={token}; Path=/api; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}"
        ))
        .map_err(|_| mismatch())?,
    );
    Ok(response)
}
async fn profile(State(s): State<ApiState>, headers: HeaderMap) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::UserProfile(identity(&s, &headers)?))
        .await?
    {
        Reply::Profile(profile) => Ok(Json(profile).into_response()),
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Empty {}
async fn logout(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let _: Empty = decode(&body)?;
    let token = cookie(&headers)?;
    let current = s.auth.resolve(token)?;
    let reply = s.runtime.request(Command::EndUserSession(current)).await?;
    if !matches!(reply, Reply::Done) {
        return Err(mismatch());
    }
    s.auth.remove(token)?;
    let mut response = StatusCode::NO_CONTENT.into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_static("rx_session=; Path=/api; HttpOnly; SameSite=Strict; Max-Age=0"),
    );
    Ok(response)
}
async fn overview(State(s): State<ApiState>, headers: HeaderMap) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::Overview(identity(&s, &headers)?))
        .await?
    {
        Reply::Overview(value) => Ok(Json(value).into_response()),
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CellQuery {
    id: Name,
}
async fn cell(
    State(s): State<ApiState>,
    headers: HeaderMap,
    Query(q): Query<CellQuery>,
) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::InspectCell {
            identity: identity(&s, &headers)?,
            cell: q.id,
        })
        .await?
    {
        Reply::Cell(revision, value) => {
            Ok(Json(rx_application::projection::Versioned { revision, value }).into_response())
        }
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RunQuery {
    id: Id,
}
async fn run_checkpoint(
    State(s): State<ApiState>,
    headers: HeaderMap,
    Query(q): Query<RunQuery>,
) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::RunCheckpoint {
            identity: identity(&s, &headers)?,
            run: q.id,
        })
        .await?
    {
        Reply::RunCheckpoint(snapshot) => {
            let view = rx_protocol_adapter::workflow::run_view(&snapshot);
            let value = rx_protocol::json::to_value(&view).map_err(|_| mismatch())?;
            Ok(Json(value).into_response())
        }
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ArtifactQuery {
    run: Id,
    sha256: Digest,
    schema_id: Name,
    size_bytes: Counter,
}
async fn checkpoint_artifact(
    State(s): State<ApiState>,
    headers: HeaderMap,
    Query(q): Query<ArtifactQuery>,
) -> Result<Response, ApiError> {
    let reference = ArtifactRef {
        sha256: q.sha256,
        schema_id: q.schema_id,
        size_bytes: q.size_bytes,
    };
    match s
        .runtime
        .request(Command::CheckpointArtifact {
            identity: identity(&s, &headers)?,
            run: q.run,
            reference,
        })
        .await?
    {
        // These are the exact canonical bytes addressed by the checkpoint, not a rewrapped view.
        Reply::ArtifactBytes(bytes) => {
            Ok(([(header::CONTENT_TYPE, "application/json")], bytes).into_response())
        }
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Mutation<T> {
    request_key: Id,
    command: T,
}
#[derive(Serialize)]
struct Revision {
    revision: Counter,
}
async fn install_cell(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<CellConfiguration> = decode(&body)?;
    match s
        .runtime
        .request(Command::InstallCell {
            identity: current,
            key: value.request_key,
            configuration: Box::new(value.command),
        })
        .await?
    {
        Reply::Revision(revision) => Ok(Json(Revision { revision }).into_response()),
        _ => Err(mismatch()),
    }
}
async fn create_run(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<CreateRun> = decode(&body)?;
    match s
        .runtime
        .request(Command::CreateRun {
            identity: current,
            key: value.request_key,
            command: value.command,
        })
        .await?
    {
        Reply::Run(run) => Ok(Json(run).into_response()),
        _ => Err(mismatch()),
    }
}
async fn start_run(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<StartRun> = decode(&body)?;
    match s
        .runtime
        .request(Command::StartRun {
            identity: current,
            key: value.request_key,
            command: value.command,
        })
        .await?
    {
        Reply::Attempt(attempt) => Ok(Json(attempt).into_response()),
        _ => Err(mismatch()),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Hold {
    cell: Name,
}
async fn hold(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<Hold> = decode(&body)?;
    match s
        .runtime
        .request(Command::Hold {
            identity: current,
            key: value.request_key,
            cell: value.command.cell,
        })
        .await?
    {
        Reply::Held(cell) => Ok(Json(cell).into_response()),
        _ => Err(mismatch()),
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CaseQuery {
    cell: Name,
    case: Id,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CasesQuery {
    cell: Name,
}
async fn cases(
    State(s): State<ApiState>,
    headers: HeaderMap,
    Query(q): Query<CasesQuery>,
) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::Cases {
            identity: identity(&s, &headers)?,
            cell: q.cell,
        })
        .await?
    {
        Reply::Cases(v) => Ok(Json(v).into_response()),
        _ => Err(mismatch()),
    }
}
async fn case_detail(
    State(s): State<ApiState>,
    headers: HeaderMap,
    Query(q): Query<CaseQuery>,
) -> Result<Response, ApiError> {
    match s
        .runtime
        .request(Command::InspectCase {
            identity: identity(&s, &headers)?,
            cell: q.cell,
            case: q.case,
        })
        .await?
    {
        Reply::CaseDetail(v) => Ok(Json(v).into_response()),
        _ => Err(mismatch()),
    }
}
async fn open_case(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<rx_application::intervention::OpenCase> = decode(&body)?;
    match s
        .runtime
        .request(Command::OpenCase {
            identity: current,
            key: value.request_key,
            command: value.command,
        })
        .await?
    {
        Reply::CaseSnapshot(v) => Ok(Json(v).into_response()),
        _ => Err(mismatch()),
    }
}
async fn acknowledge_case(
    State(s): State<ApiState>,
    headers: HeaderMap,
    body: Bytes,
) -> Result<Response, ApiError> {
    let current = identity(&s, &headers)?;
    let value: Mutation<rx_application::intervention::AcknowledgeCase> = decode(&body)?;
    match s
        .runtime
        .request(Command::AcknowledgeCase {
            identity: current,
            key: value.request_key,
            command: value.command,
        })
        .await?
    {
        Reply::CaseDetail(v) => Ok(Json(v).into_response()),
        _ => Err(mismatch()),
    }
}
