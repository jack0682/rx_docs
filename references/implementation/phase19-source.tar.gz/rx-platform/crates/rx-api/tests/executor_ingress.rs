//! Real TLS sockets and SQLite. Read/reconnect fixtures never send device commands.
mod support;
use rx_api::grpc::{Configuration, PlatformIngress, TlsMaterial};
use rx_application::*;
use rx_domain::{canonical, types::*};
use rx_protocol::{base, cell};
use rx_runtime::{
    application::{Application, Command, Handle, Reply},
    writer::Writer,
};
use rx_storage::SqliteRepository;
use std::{collections::BTreeMap, sync::Arc};
use tonic::transport::{
    Certificate as TlsCertificate, Channel, ClientTlsConfig, Identity as TlsIdentity,
};
fn id() -> Id {
    Id::new(uuid::Uuid::new_v4().to_string()).unwrap()
}
fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
struct TestClock;
impl Clock for TestClock {
    fn now(&self) -> TimePoint {
        TimePoint {
            clock_id: "test-clock".into(),
            ticks_ns: Counter(1000),
        }
    }
}
struct SimulationOnly;
fn simulation_report() -> ArtifactRef {
    ArtifactRef {
        sha256: Digest::from_bytes([9; 32]),
        schema_id: name("rx.validation.simulation.v1"),
        size_bytes: Counter(1),
    }
}
impl QualificationAuthority for SimulationOnly {
    fn verify(&self, c: &CellConfiguration, e: &[ArtifactRef], d: &[Digest]) -> bool {
        c.environment == Environment::Simulation
            && e == [simulation_report()]
            && d.len() == 4
            && [
                c.definition.sha256,
                c.envelope.sha256,
                c.recipe.sha256,
                c.site_config_digest,
            ]
            .iter()
            .all(|v| d.contains(v))
    }
}
fn manifest(text: &str) -> Vec<u8> {
    use sha2::Digest as _;
    let json: serde_json::Value = serde_json::from_str(text).unwrap();
    sha2::Sha256::digest(canonical::bytes(&json).unwrap()).to_vec()
}
async fn connect(uri: &str, ca: &str, certificate: &str, key: &str) -> Channel {
    Channel::from_shared(uri.to_string())
        .unwrap()
        .tls_config(
            ClientTlsConfig::new()
                .domain_name("localhost")
                .ca_certificate(TlsCertificate::from_pem(ca))
                .identity(TlsIdentity::from_pem(certificate, key)),
        )
        .unwrap()
        .connect()
        .await
        .unwrap()
}
fn call(session: &base::Session) -> base::CallContext {
    base::CallContext {
        session_id: session.session_id.clone(),
        call_id: id().to_string(),
        request_key: None,
        expected_revision: None,
    }
}
#[tokio::test]
async fn executor_run_reads_require_both_negotiations_and_the_same_registered_certificate() {
    run_fixture(false).await;
}
#[tokio::test]
async fn remote_executor_allocates_and_submits_after_a_simulated_operator_start() {
    run_fixture(true).await;
}
async fn run_fixture(mutate: bool) {
    use rcgen::*;
    use sha2::Digest as _;
    let directory = tempfile::tempdir().unwrap();
    let db = directory.path().join("p.db");
    let configuration = support::configuration("cell/a");
    let config = configuration.clone();
    let admin_session = id();
    let setup_admin_session = admin_session.clone();
    let host_session = id();
    let setup_host_session = host_session.clone();
    let writer = Writer::start(move || {
        let mut engine = Engine::open(
            SqliteRepository::open(db)?,
            TestClock,
            SimulationOnly,
            id(),
            Principal {
                id: name("admin"),
                client_namespace: name("admin"),
                roles: [
                    Role::AccountAdmin,
                    Role::Engineer,
                    Role::Operator,
                    Role::Verifier,
                ]
                .into_iter()
                .collect(),
                cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
                active: true,
            },
        )?;
        let session = engine.authenticated_session(
            &name("admin"),
            setup_admin_session,
            TimePoint {
                clock_id: "test-clock".into(),
                ticks_ns: Counter(u64::MAX),
            },
        )?;
        let admin = Identity {
            principal: name("admin"),
            session: session.id,
            terminal: None,
        };
        engine.put_principal(
            &admin,
            Principal {
                id: name("executor"),
                client_namespace: name("executor"),
                roles: [Role::Executor].into_iter().collect(),
                cells: [name("cell/a"), name("cell/b")].into_iter().collect(),
                active: true,
            },
            None,
        )?;
        engine.install_cell(&admin, config.clone())?;
        engine.create_run(
            &admin,
            id().as_str(),
            CreateRun {
                cell: config.id.clone(),
                recipe_digest: config.recipe.sha256,
                site_config_digest: config.site_config_digest,
                expected_cell: Counter(1),
            },
        )?;
        let mut other = support::configuration("cell/b");
        other.executor = name("other-executor");
        other.definition.sha256 = Digest::from_bytes([51; 32]);
        engine.install_cell(&admin, other.clone())?;
        engine.create_run(
            &admin,
            id().as_str(),
            CreateRun {
                cell: other.id,
                recipe_digest: other.recipe.sha256,
                site_config_digest: other.site_config_digest,
                expected_cell: Counter(1),
            },
        )?;
        if mutate {
            prepare_simulated_host(&mut engine, &admin, &config, setup_host_session)?;
        }
        Ok(Application::new(engine))
    })
    .await
    .unwrap();
    let handle = Handle::new(writer);
    let Reply::Installation(installation) = handle.call(Command::Installation).await.unwrap()
    else {
        panic!("installation")
    };
    let mut ca_params = CertificateParams::new(vec![]).unwrap();
    ca_params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
    ca_params.key_usages = vec![KeyUsagePurpose::KeyCertSign];
    let ca = CertifiedIssuer::self_signed(ca_params, KeyPair::generate().unwrap()).unwrap();
    let leaf = |label: &str, usage: ExtendedKeyUsagePurpose| {
        let key = KeyPair::generate().unwrap();
        let mut params = CertificateParams::new(vec![label.into()]).unwrap();
        params.extended_key_usages = vec![usage];
        params.key_usages = vec![KeyUsagePurpose::DigitalSignature];
        (params.signed_by(&key, &ca).unwrap(), key)
    };
    let (server, server_key) = leaf("localhost", ExtendedKeyUsagePurpose::ServerAuth);
    let (executor, executor_key) = leaf("executor", ExtendedKeyUsagePurpose::ClientAuth);
    let (alternate, alternate_key) = leaf("alternate", ExtendedKeyUsagePurpose::ClientAuth);
    let (unregistered, unregistered_key) =
        leaf("unregistered", ExtendedKeyUsagePurpose::ClientAuth);
    let fingerprint =
        |cert: &Certificate| Digest::from_bytes(sha2::Sha256::digest(cert.der().as_ref()).into());
    let release = Digest::from_bytes([8; 32]);
    let ingress = PlatformIngress::new(
        Arc::new(handle.clone()),
        Configuration {
            installation: installation.clone(),
            release_digest: release,
            allowed_certificates: BTreeMap::from([
                (fingerprint(&executor), name("executor")),
                (fingerprint(&alternate), name("executor")),
            ]),
        },
    )
    .await
    .unwrap();
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let uri = format!("https://{}", listener.local_addr().unwrap());
    let tls = TlsMaterial {
        server_certificate_pem: server.pem().into_bytes(),
        server_key_pem: server_key.serialize_pem().into_bytes(),
        client_ca_pem: ca.pem().into_bytes(),
    };
    let (stop, stopped) = tokio::sync::oneshot::channel();
    let task = tokio::spawn(async move {
        ingress
            .serve(listener, tls, async {
                let _ = stopped.await;
            })
            .await
            .unwrap();
    });
    let channel = connect(
        &uri,
        &ca.pem(),
        &executor.pem(),
        &executor_key.serialize_pem(),
    )
    .await;
    let alternate_channel = connect(
        &uri,
        &ca.pem(),
        &alternate.pem(),
        &alternate_key.serialize_pem(),
    )
    .await;
    let unregistered_channel = connect(
        &uri,
        &ca.pem(),
        &unregistered.pem(),
        &unregistered_key.serialize_pem(),
    )
    .await;
    let base_hash = manifest(include_str!(
        "../../../spec/contracts/v1.0/protocol_manifest.json"
    ));
    let cell_hash = manifest(include_str!(
        "../../../spec/cell_operations/v1.0/protocol_manifest.json"
    ));
    let hello = base::PeerHello {
        installation_id: installation.id.to_string(),
        store_generation: installation.store_generation.to_string(),
        peer_id: "executor".into(),
        role: base::Role::Executor as i32,
        boot_id: id().to_string(),
        release_digest: release.as_bytes().to_vec(),
        supported_versions: vec![base::Version {
            major: 1,
            minor: 0,
            schema_hash: base_hash.clone(),
        }],
        shared_clock_id: installation.clock_id.clone(),
        journal_id: None,
        last_seq: None,
    };
    let mut sessions = base::session_service_client::SessionServiceClient::new(channel.clone());
    let session = sessions.open(hello.clone()).await.unwrap().into_inner();
    let mut wrong_role = hello.clone();
    wrong_role.role = base::Role::Host as i32;
    wrong_role.journal_id = Some(id().to_string());
    wrong_role.last_seq = Some(0);
    assert_eq!(
        sessions.open(wrong_role).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );

    assert_eq!(
        sessions
            .open(hello.clone())
            .await
            .unwrap()
            .into_inner()
            .session_id,
        session.session_id
    );
    assert_eq!(
        base::session_service_client::SessionServiceClient::new(unregistered_channel)
            .open(hello.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::PermissionDenied
    );
    let identity = Identity {
        principal: name("executor"),
        session: Id::new(&session.session_id).unwrap(),
        terminal: None,
    };
    let Reply::Overview(overview) = handle
        .call(Command::Overview(identity.clone()))
        .await
        .unwrap()
    else {
        panic!("overview")
    };
    let run = overview
        .cells
        .iter()
        .find(|c| c.cell.value.id == configuration.id)
        .unwrap()
        .runs[0]
        .value
        .id
        .clone();
    let other_run = overview
        .cells
        .iter()
        .find(|c| c.cell.value.id == name("cell/b"))
        .unwrap()
        .runs[0]
        .value
        .id
        .clone();
    let request = base::RunRequest {
        context: Some(call(&session)),
        run_id: Some(run.to_string()),
        recipe_digest: vec![],
        site_config_digest: vec![],
    };
    let mut workflow = base::workflow_service_client::WorkflowServiceClient::new(channel.clone());
    assert_eq!(
        workflow.get_run(request.clone()).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    let cell_hello = cell::CellHello {
        base_session_id: session.session_id.clone(),
        peer_id: "executor".into(),
        base_manifest_hash: base_hash,
        cell_manifest_hash: cell_hash,
        cell_definition_digest: configuration.definition.sha256.as_bytes().to_vec(),
        shared_clock_id: installation.clock_id,
    };
    let mut cells = cell::cell_service_client::CellServiceClient::new(channel.clone());
    let mut mismatch = cell_hello.clone();
    mismatch.cell_manifest_hash[0] ^= 1;
    assert_eq!(
        cells.open(mismatch).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    cells.open(cell_hello.clone()).await.unwrap();
    let view = workflow
        .get_run(request.clone())
        .await
        .unwrap()
        .into_inner();
    assert_eq!(view.run_id, run.to_string());
    assert_eq!(view.state, base::RunState::Prepared as i32);
    assert_eq!(view.checkpoint.as_ref().unwrap().revision, view.revision);
    assert!(view.executor_session_id.is_none());
    let mut bad_revision = request.clone();
    bad_revision.context.as_mut().unwrap().expected_revision = Some(1);
    assert_eq!(
        workflow.get_run(bad_revision).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut bad_digest = request.clone();
    bad_digest.recipe_digest = vec![1; 32];
    assert_eq!(
        workflow.get_run(bad_digest).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut other = request.clone();
    other.run_id = Some(other_run.to_string());
    assert_eq!(
        workflow.get_run(other).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    let mut alternate_workflow =
        base::workflow_service_client::WorkflowServiceClient::new(alternate_channel);
    assert_eq!(
        alternate_workflow
            .get_run(request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unauthenticated
    );
    assert_eq!(
        workflow
            .start_run(request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unimplemented
    );
    if mutate {
        let admin = Identity {
            principal: name("admin"),
            session: admin_session,
            terminal: Some((name("test/panel"), Digest::from_bytes([77; 32]))),
        };
        let host = Identity {
            principal: name("host/sim"),
            session: host_session,
            terminal: None,
        };
        run_mutations(
            &handle,
            channel.clone(),
            &mut cells,
            &mut workflow,
            &session,
            &configuration,
            &run,
            &admin,
            &host,
        )
        .await;
    }
    let mut newer = hello.clone();
    newer.boot_id = id().to_string();
    let next = sessions.open(newer).await.unwrap().into_inner();
    assert_ne!(next.session_id, session.session_id);
    assert_eq!(
        workflow.get_run(request.clone()).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );
    assert_eq!(
        sessions.open(hello).await.unwrap_err().code(),
        tonic::Code::Unauthenticated
    );
    let mut next_request = request;
    next_request.context = Some(call(&next));
    assert_eq!(
        workflow
            .get_run(next_request.clone())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::FailedPrecondition
    );
    let mut next_cell = cell_hello;
    next_cell.base_session_id = next.session_id;
    cells.open(next_cell).await.unwrap();
    let after = workflow.get_run(next_request).await.unwrap().into_inner();
    assert_ne!(after.state, base::RunState::Executing as i32);
    assert!(after.executor_session_id.is_none());
    stop.send(()).unwrap();
    task.await.unwrap();
    handle.close();
    handle.closed().await;
}

fn prepare_simulated_host(
    engine: &mut Engine<SqliteRepository, TestClock, SimulationOnly>,
    admin: &Identity,
    configuration: &CellConfiguration,
    host_session: Id,
) -> rx_ports::Result<()> {
    engine.put_principal(
        admin,
        Principal {
            id: name("host/sim"),
            client_namespace: name("host/sim"),
            roles: [Role::Host].into_iter().collect(),
            cells: [configuration.id.clone()].into_iter().collect(),
            active: true,
        },
        None,
    )?;
    engine.authenticated_session(
        &name("host/sim"),
        host_session.clone(),
        TimePoint {
            clock_id: "test-clock".into(),
            ticks_ns: Counter(u64::MAX),
        },
    )?;
    let host = Identity {
        principal: name("host/sim"),
        session: host_session.clone(),
        terminal: None,
    };
    let (revision, _) = engine.inspect_cell(admin, &configuration.id)?;
    engine.qualify(
        admin,
        &configuration.id,
        revision,
        vec![simulation_report()],
        vec![
            configuration.definition.sha256,
            configuration.envelope.sha256,
            configuration.recipe.sha256,
            configuration.site_config_digest,
        ],
    )?;
    engine.put_terminal(
        admin,
        Terminal {
            id: name("test/panel"),
            certificate_digest: Digest::from_bytes([77; 32]),
            cells: [configuration.id.clone()].into_iter().collect(),
            active: true,
        },
        None,
    )?;
    let (_, cell) = engine.inspect_cell(admin, &configuration.id)?;
    let source = id();
    let registration = HostRegistration {
        id: host.principal.clone(),
        session: host_session,
        boot_id: id(),
        delivery_journal: id(),
        cell: configuration.id.clone(),
        epoch: cell.epoch,
        scopes: cell.scope_epochs,
        source_sessions: BTreeMap::from([(name("ready"), source.clone())]),
        grant: Grant {
            id: id(),
            fence: Counter(1),
            resources: configuration.steps[0].intent.resource_set.clone(),
            owner: name(engine.installation.id.as_str()),
            valid_until: TimePoint {
                clock_id: "test-clock".into(),
                ticks_ns: Counter(1_000_000_000),
            },
            ttl_ms: Counter(1000),
        },
    };
    engine.register_host(&host, registration)?;
    engine.report_fact(
        &host,
        FactRecord {
            cell: configuration.id.clone(),
            id: name("ready"),
            source_host: host.principal.clone(),
            source_generation: source,
            schema: name("boolean/v1"),
            unit: name("unitless"),
            acquired_at: TimePoint {
                clock_id: "test-clock".into(),
                ticks_ns: Counter(1000),
            },
            maximum_age_ns: Counter(1_000_000_000),
            acquisition_uncertainty_ns: Counter(0),
            quality_good: true,
            origin_age_bounded: true,
            disputed: false,
            value: TypedValue::Boolean(true),
            evidence_id: id(),
        },
    )?;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
async fn run_mutations(
    handle: &Handle<Application<SqliteRepository, TestClock, SimulationOnly>>,
    channel: Channel,
    cells: &mut cell::cell_service_client::CellServiceClient<Channel>,
    workflow: &mut base::workflow_service_client::WorkflowServiceClient<Channel>,
    session: &base::Session,
    configuration: &CellConfiguration,
    run: &Id,
    admin: &Identity,
    host: &Identity,
) {
    let Reply::Cell(cell_revision, _) = handle
        .call(Command::InspectCell {
            identity: admin.clone(),
            cell: configuration.id.clone(),
        })
        .await
        .unwrap()
    else {
        panic!("cell")
    };
    let Reply::Attempt(attempt) = handle
        .call(Command::StartRun {
            identity: admin.clone(),
            key: id(),
            command: StartRun {
                run: run.clone(),
                envelope_digest: configuration.envelope.sha256,
                purpose: Purpose::Production,
                budget_unit: rx_domain::budget::BudgetUnit::PartAttempt,
                budget_limit: Counter(1),
                expected_cell: cell_revision,
                expected_run: Counter(1),
            },
        })
        .await
        .unwrap()
    else {
        panic!("attempt")
    };
    let Reply::PendingDeliveries(pending) = handle
        .call(Command::PendingDeliveries {
            after: None,
            limit: 8,
        })
        .await
        .unwrap()
    else {
        panic!("outbox")
    };
    let message = pending
        .iter()
        .find(|p| matches!(&p.payload,Delivery::Arm {attempt:target,..} if target==&attempt.id))
        .unwrap()
        .id
        .clone();
    let Reply::DeliveryPlan(plan) = handle
        .call(Command::PlanDelivery {
            identity: host.clone(),
            message: message.clone(),
        })
        .await
        .unwrap()
    else {
        panic!("plan")
    };
    let registration = plan.registration;
    handle
        .call(Command::FinishArm {
            identity: host.clone(),
            message,
            ack: ArmAcknowledgment {
                attempt: attempt.id,
                host_boot: registration.boot_id,
                delivery_journal: registration.delivery_journal,
                sequence: Counter(1),
                epoch: registration.epoch,
                scopes: registration.scopes,
            },
        })
        .await
        .unwrap();
    let Reply::VersionedRun(_, running) = handle
        .call(Command::InspectRun {
            identity: admin.clone(),
            run: run.clone(),
        })
        .await
        .unwrap()
    else {
        panic!("run")
    };
    assert_eq!(running.state, RunState::Executing);
    let begin = cell::BeginPartAttemptRequest {
        call: Some(cell::CellCall {
            context: Some(base::CallContext {
                request_key: Some(id().to_string()),
                ..call(session)
            }),
            cell_id: configuration.id.to_string(),
            expected_cell_revision: Some(cell_revision.0),
        }),
        run_id: run.to_string(),
        mandate_id: running.mandate.unwrap().to_string(),
        expected_budget_revision: running.budget.unwrap().revision().0,
    };
    let part = cells
        .begin_part_attempt(begin.clone())
        .await
        .unwrap()
        .into_inner();
    assert_eq!(part.revision, 1);
    assert_eq!(part.ordinal, 1);
    assert_eq!(part.disposition, cell::PartDisposition::InProgress as i32);
    assert_eq!(
        cells
            .begin_part_attempt(begin.clone())
            .await
            .unwrap()
            .into_inner(),
        part
    );
    let mandate = begin.mandate_id.clone();
    let mut changed = begin;
    changed.mandate_id = id().to_string();
    assert_eq!(
        cells.begin_part_attempt(changed).await.unwrap_err().code(),
        tonic::Code::AlreadyExists
    );
    let request = base::RunRequest {
        context: Some(call(session)),
        run_id: Some(run.to_string()),
        recipe_digest: vec![],
        site_config_digest: vec![],
    };
    let before = workflow
        .get_run(request.clone())
        .await
        .unwrap()
        .into_inner();
    let resolve = base::ResolveActivation {
        context: Some(base::CallContext {
            request_key: Some(id().to_string()),
            expected_revision: Some(before.revision),
            ..call(session)
        }),
        run_id: run.to_string(),
        node_id: configuration.steps[0].id.to_string(),
        visit: part.ordinal,
    };
    let activation = workflow
        .resolve_activation(resolve.clone())
        .await
        .unwrap()
        .into_inner();
    assert_eq!(
        workflow
            .resolve_activation(resolve.clone())
            .await
            .unwrap()
            .into_inner(),
        activation
    );
    let mut changed = resolve.clone();
    changed.visit = 2;
    assert_eq!(
        workflow
            .resolve_activation(changed)
            .await
            .unwrap_err()
            .code(),
        tonic::Code::AlreadyExists
    );
    let mut another_key = resolve;
    another_key.context.as_mut().unwrap().request_key = Some(id().to_string());
    assert_eq!(
        workflow
            .resolve_activation(another_key)
            .await
            .unwrap()
            .into_inner(),
        activation
    );
    let after = workflow.get_run(request).await.unwrap().into_inner();
    assert_eq!(after.revision, before.revision + 1);
    assert_eq!(
        after.checkpoint.unwrap().activations,
        vec![activation.clone()]
    );
    let context = base::CallContext {
        request_key: Some(id().to_string()),
        ..call(session)
    };
    let intent = rx_protocol::json::from_slice::<base::Intent>(
        &canonical::bytes(&configuration.steps[0].intent).unwrap(),
    )
    .unwrap();
    let submission = cell::SubmitOperationRequest {
        call: Some(cell::CellCall {
            context: Some(context.clone()),
            cell_id: configuration.id.to_string(),
            expected_cell_revision: Some(cell_revision.0),
        }),
        request: Some(base::SubmitOperation {
            context: Some(context),
            intent: Some(intent),
            run_id: Some(run.to_string()),
            activation_id: Some(activation.activation_id),
            slot: Some("main".into()),
        }),
        parent: Some(cell::PermitParent {
            value: Some(cell::permit_parent::Value::MandateId(mandate)),
        }),
        part_attempt_id: Some(part.part_attempt_id),
        expected_run_revision: Some(after.revision),
        expected_case_revision: None,
    };
    let mut mismatch = submission.clone();
    mismatch
        .request
        .as_mut()
        .unwrap()
        .context
        .as_mut()
        .unwrap()
        .call_id = id().to_string();
    assert_eq!(
        cells.submit_operation(mismatch).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut mismatch = submission.clone();
    mismatch.part_attempt_id = Some(id().to_string());
    assert_eq!(
        cells.submit_operation(mismatch).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut mismatch = submission.clone();
    mismatch.request.as_mut().unwrap().run_id = Some(id().to_string());
    assert_eq!(
        cells.submit_operation(mismatch).await.unwrap_err().code(),
        tonic::Code::InvalidArgument
    );
    let mut mismatch = submission.clone();
    mismatch.parent = Some(cell::PermitParent {
        value: Some(cell::permit_parent::Value::MandateId(id().to_string())),
    });
    assert_eq!(
        cells.submit_operation(mismatch).await.unwrap_err().code(),
        tonic::Code::FailedPrecondition
    );
    let mut stale = submission.clone();
    stale.expected_run_revision = Some(after.revision - 1);
    assert_eq!(
        cells.submit_operation(stale).await.unwrap_err().code(),
        tonic::Code::Aborted
    );
    let receipt = cells
        .submit_operation(submission.clone())
        .await
        .unwrap()
        .into_inner();
    assert_eq!(receipt.stage, base::ReceiptStage::Admitted as i32);
    assert_eq!(receipt.operation_revision, Some(1));
    assert!(
        receipt.journal_seq > 0 && receipt.invocation_id.is_none() && receipt.host_state.is_none()
    );
    let mut retry = submission.clone();
    let trace = id().to_string();
    retry
        .call
        .as_mut()
        .unwrap()
        .context
        .as_mut()
        .unwrap()
        .call_id = trace.clone();
    retry
        .request
        .as_mut()
        .unwrap()
        .context
        .as_mut()
        .unwrap()
        .call_id = trace;
    assert_eq!(
        cells.submit_operation(retry).await.unwrap().into_inner(),
        receipt
    );
    let mut changed = submission.clone();
    changed.expected_run_revision = Some(after.revision + 1);
    assert_eq!(
        cells.submit_operation(changed).await.unwrap_err().code(),
        tonic::Code::AlreadyExists
    );
    let mut second_key = submission.clone();
    let key = id().to_string();
    second_key
        .call
        .as_mut()
        .unwrap()
        .context
        .as_mut()
        .unwrap()
        .request_key = Some(key.clone());
    second_key
        .request
        .as_mut()
        .unwrap()
        .context
        .as_mut()
        .unwrap()
        .request_key = Some(key);
    assert_eq!(
        cells
            .submit_operation(second_key)
            .await
            .unwrap()
            .into_inner(),
        receipt
    );
    let mut operations = base::operation_service_client::OperationServiceClient::new(channel);
    assert_eq!(
        operations
            .submit(submission.request.unwrap())
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unimplemented
    );
    let view = operations
        .get(base::OperationRef {
            context: Some(call(session)),
            operation_id: receipt.operation_id.clone(),
        })
        .await
        .unwrap()
        .into_inner();
    assert_eq!(view.operation_id, receipt.operation_id);
    assert_eq!(view.intent_digest, receipt.intent_digest);
    assert_eq!(view.phase, base::Phase::Admitted as i32);
    assert_eq!(view.execution_knowledge, base::Knowledge::NotSent as i32);
    assert_eq!(view.outcome, base::Outcome::None as i32);
    assert_eq!(view.disposition, base::Disposition::Held as i32);
    assert!(view.evidence_ids.is_empty());
    let Reply::VersionedRun(_, run_state) = handle
        .call(Command::InspectRun {
            identity: admin.clone(),
            run: run.clone(),
        })
        .await
        .unwrap()
    else {
        panic!("run")
    };
    assert_eq!(run_state.part_ids.len(), 1);
    let Reply::Overview(overview) = handle.call(Command::Overview(admin.clone())).await.unwrap()
    else {
        panic!("overview")
    };
    assert_eq!(
        overview
            .cells
            .iter()
            .map(|cell| cell.work.len())
            .sum::<usize>(),
        1
    );
}
