//! CLI trust input comes from an explicit local composition policy, never from the package being verified.
use crate::{Error, Result};
use rx_domain::{canonical, types::*};
use rx_package::*;
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, BTreeSet},
    io::Read,
    path::{Path, PathBuf},
    sync::Arc,
};
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Key {
    pub id: Name,
    pub publisher: Name,
    pub verifying_key: Digest,
    pub kinds: BTreeSet<PackageKind>,
    pub permissions: BTreeSet<Permission>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Asset {
    pub reference: ArtifactRef,
    pub path: PathBuf,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DependencyInput {
    pub path: PathBuf,
    pub manifest_digest: Digest,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Policy {
    pub schema: Name,
    pub contracts: ContractSet,
    pub target: Target,
    pub keys: Vec<Key>,
    pub assets: Vec<Asset>,
    pub dependencies: Vec<DependencyInput>,
}
pub fn read<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T> {
    let metadata = std::fs::symlink_metadata(path)?;
    if !metadata.is_file() || metadata.file_type().is_symlink() || metadata.len() > 1_048_576 {
        return Err(Error::Invalid("policy/input file type or size".into()));
    }
    let mut bytes = vec![];
    std::fs::File::open(path)?
        .take(1_048_577)
        .read_to_end(&mut bytes)?;
    if bytes.len() > 1_048_576 {
        return Err(Error::Invalid("input file too large".into()));
    }
    canonical::decode_json(&bytes).map_err(|e| Error::Invalid(e.to_string()))
}
impl Policy {
    pub fn load(&self) -> Result<VerificationPolicy> {
        if self.schema.as_str() != "rx.package-verification-policy.v1"
            || self.keys.len() > 128
            || self.assets.len() > 1024
            || self.dependencies.len() > 128
        {
            return Err(Error::Invalid("verification policy shape".into()));
        }
        let mut publishers = BTreeMap::new();
        for key in &self.keys {
            if publishers
                .insert(
                    key.id.clone(),
                    TrustedPublisher {
                        publisher: key.publisher.clone(),
                        verifying_key: *key.verifying_key.as_bytes(),
                        kinds: key.kinds.clone(),
                        permissions: key.permissions.clone(),
                    },
                )
                .is_some()
            {
                return Err(Error::Invalid("duplicate policy key ID".into()));
            }
        }
        let mut assets = BTreeMap::new();
        let mut total = 0u64;
        for asset in &self.assets {
            total = total
                .checked_add(asset.reference.size_bytes.0)
                .ok_or_else(|| Error::Invalid("asset size overflow".into()))?;
            if total > 256 * 1024 * 1024 {
                return Err(Error::Invalid(
                    "policy asset acquisition exceeds 256 MiB".into(),
                ));
            }
            let m = std::fs::symlink_metadata(&asset.path)?;
            if !m.is_file() || m.file_type().is_symlink() || m.len() != asset.reference.size_bytes.0
            {
                return Err(Error::Invalid("asset file metadata differs".into()));
            }
            let mut data = vec![];
            std::fs::File::open(&asset.path)?
                .take(asset.reference.size_bytes.0 + 1)
                .read_to_end(&mut data)?;
            if data.len() as u64 != asset.reference.size_bytes.0
                || content_digest(&data) != asset.reference.sha256
                || assets
                    .insert(asset.reference.sha256, asset.reference.clone())
                    .is_some()
            {
                return Err(Error::Invalid(
                    "asset file digest or duplicate differs".into(),
                ));
            }
        }
        let mut policy = VerificationPolicy {
            publishers,
            contracts: self.contracts.clone(),
            target: self.target.clone(),
            assets,
            dependencies: BTreeMap::new(),
            max_files: 32,
            max_content_bytes: 4 * 1024 * 1024,
        };
        let mut pending = BTreeMap::new();
        for input in &self.dependencies {
            let mut files =
                rx_package::directory::acquire_directory(&input.path, 32, 4 * 1024 * 1024)?;
            let manifest = files
                .remove(&PackagePath::new("manifest.json").expect("literal"))
                .ok_or_else(|| Error::Invalid("dependency manifest missing".into()))?;
            let signature = files
                .remove(&PackagePath::new("manifest.sig.json").expect("literal"))
                .ok_or_else(|| Error::Invalid("dependency signature missing".into()))?;
            let metadata: Manifest =
                canonical::decode_json(&manifest).map_err(|e| Error::Invalid(e.to_string()))?;
            if content_digest(&manifest_bytes(&metadata)?) != input.manifest_digest
                || pending
                    .insert(
                        metadata.package.clone(),
                        (metadata, manifest, signature, files),
                    )
                    .is_some()
            {
                return Err(Error::Invalid(
                    "dependency identity or duplicate differs".into(),
                ));
            }
        }
        while !pending.is_empty() {
            let ready = pending
                .iter()
                .find(|(_, item)| {
                    item.0
                        .dependencies
                        .iter()
                        .all(|d| policy.dependencies.contains_key(&d.package))
                })
                .map(|(id, _)| id.clone())
                .ok_or_else(|| {
                    Error::Invalid("dependency cycle or unresolved dependency".into())
                })?;
            let (_, manifest, signature, files) =
                pending.remove(&ready).expect("selected dependency");
            let verified = verify_package(&manifest, &signature, files, &policy)?;
            policy.dependencies.insert(ready, Arc::new(verified));
        }
        Ok(policy)
    }
}
