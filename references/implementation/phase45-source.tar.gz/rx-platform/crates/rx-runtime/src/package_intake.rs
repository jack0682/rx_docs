//! Bounded off-writer filesystem/crypto work. Every result still requires authoritative commit.
use rx_application::package_intake::{Prepared, Ticket};
use rx_domain::types::*;
use rx_package::{VerificationPolicy, store::Store};
use std::{
    path::PathBuf,
    sync::{Arc, Mutex},
};
use tokio::sync::Semaphore;
pub struct Worker {
    root: PathBuf,
    store: Mutex<Store>,
    policy: VerificationPolicy,
    owner: Id,
    fingerprint: Digest,
    policy_file_digest: Digest,
    policy_file: Option<PathBuf>,
    permit: Arc<Semaphore>,
}
impl Worker {
    pub fn new(
        root: PathBuf,
        store: Store,
        policy: VerificationPolicy,
        policy_file_digest: Digest,
    ) -> Result<Arc<Self>, String> {
        Self::build(root, store, policy, policy_file_digest, None)
    }
    pub fn new_pinned(
        root: PathBuf,
        store: Store,
        policy: VerificationPolicy,
        policy_file_digest: Digest,
        policy_file: PathBuf,
    ) -> Result<Arc<Self>, String> {
        if !policy_file.is_absolute() {
            return Err("absolute policy source required".into());
        }
        Self::build(root, store, policy, policy_file_digest, Some(policy_file))
    }
    fn build(
        root: PathBuf,
        store: Store,
        policy: VerificationPolicy,
        policy_file_digest: Digest,
        policy_file: Option<PathBuf>,
    ) -> Result<Arc<Self>, String> {
        if !root.is_absolute() {
            return Err("absolute package import root required".into());
        }
        let owner = store.owner().clone();
        let fingerprint = policy.fingerprint().map_err(|e| e.to_string())?;
        Ok(Arc::new(Self {
            root,
            store: Mutex::new(store),
            policy,
            owner,
            fingerprint,
            policy_file_digest,
            policy_file,
            permit: Arc::new(Semaphore::new(1)),
        }))
    }
    pub fn registration(&self) -> (Id, Digest, Digest) {
        (
            self.owner.clone(),
            self.fingerprint,
            self.policy_file_digest,
        )
    }
    pub async fn prepare(self: &Arc<Self>, ticket: Ticket) -> Result<Prepared, String> {
        // No unbounded blocking-task queue; one acquisition includes at most the policy limits.
        let permit = self
            .permit
            .clone()
            .try_acquire_owned()
            .map_err(|_| "package intake worker is busy")?;
        let worker = self.clone();
        tokio::task::spawn_blocking(move || {
            let _permit = permit;
            if ticket.registration().store_owner != worker.owner
                || ticket.registration().policy_fingerprint != worker.fingerprint
                || ticket.registration().policy_file_digest != worker.policy_file_digest
            {
                return Err("package intake worker registration differs".into());
            }
            let refreshed = if let Some(path) = &worker.policy_file {
                let (document, digest) =
                    rx_package::policy::read_with_digest::<rx_package::policy::Policy>(path)
                        .map_err(|e| e.to_string())?;
                if digest != worker.policy_file_digest {
                    return Err("package policy file changed".into());
                }
                let value = document.load().map_err(|e| e.to_string())?;
                if value.fingerprint().map_err(|e| e.to_string())? != worker.fingerprint {
                    return Err("package verification policy changed".into());
                }
                Some(value)
            } else {
                None
            };
            let policy = refreshed.as_ref().unwrap_or(&worker.policy);
            let package = rx_package::directory::verify_relative(
                &worker.root,
                ticket.relative_path(),
                policy,
            )
            .map_err(|e| e.to_string())?;
            let expected = ticket.object();
            let signature = rx_package::content_digest(
                &rx_domain::canonical::bytes(package.signature()).map_err(|e| e.to_string())?,
            );
            if package.digest() != expected.manifest || signature != expected.signature {
                return Err("import source does not match requested object".into());
            }
            let mut store = worker
                .store
                .lock()
                .map_err(|_| "package store owner failed")?;
            let actual = store.put(&package).map_err(|e| e.to_string())?;
            let stored = store
                .verify_owned(&actual, policy)
                .map_err(|e| e.to_string())?;
            Prepared::new(ticket, stored)
        })
        .await
        .map_err(|_| "package intake worker task failed")?
    }
}
