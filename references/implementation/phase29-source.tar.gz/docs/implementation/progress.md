# 구현 작업 기록

## 2026-09-10 · 착수

- 기존 규범 8개 파일의 SHA-256과 두 protocol manifest 일치 확인.
- 신규 두 레포와 제품 소스가 없음을 확인. 이전 세부 계획은 문서 구현 완료로 취급하지 않음.
- Docker Desktop Linux arm64 engine 사용 가능. Rust는 미설치여서 workspace 전용 toolchain 설치 시작.
- 사용자 결정: Linux 현장 PC/LAN, 등록 조작 단말, 현장 계정, 시각적 편집기, 호스트 관리 도구.
- 다음: 순수 domain 계약 표현·정규화·상태/조건 불변식과 저장 경계부터 구현.

## 2026-09-10 · 순수 domain과 저장 foundation

- 두 로컬 Git 레포를 codex/initial-draft에 생성. 외부 remote/push/장비 실행 없음.
- platform에 rx-domain / rx-ports / rx-storage 구현. core의 시간·ID 생성도 바깥에서 주입하도록 정리.
- frozen CV01–03, strict JSON/oneof/counter, UNKNOWN/후발 모순, 관측 age/source/세대, 예산·scope epoch 19개 시험 통과.
- 원자 rollback·CAS·요청 key 보존·outbox tombstone·snapshot cut·writer lock·온라인 backup 8개 시험 통과.
- 총 27개 시험 통과. cargo fmt 적용, clippy --all-targets -D warnings 통과.
- bundled SQLite 실제 소스 3.53.2 확인. 시작 시 3.51.3 이상 검사. 기존 0.38/rusqlite + SQLite 3.51.1 선택은 수정됨.
- 두 규범 기준판 복사본과 원본 8개 파일 hash 일치. 규범 본문 수정 없음.
- solutions 필수 자사 5개 레포의 정확한 원격·HEAD·clean 상태 재확인 후 robotis.repos 고정. 전체 전이 의존 lock·빌드는 아직 미완료.
- 시험 출력: references/implementation/phase01_checks.txt. 이 결과는 라이브러리 의미·저장 원자성의 범위다. 전체 T1/cell admission, gRPC/C++ 상호운용, 프로세스 강제 종료·실물 검증을 대신하지 않는다.

### 다음 작업

1. frozen Protobuf/셀 타입과 strict wire decoder, 타입/상태 원본의 직렬화·복원 검증.
2. application의 실제 셀·run·command 상태 소유와 단일 writer actor. Repository 위에 전체 T1–T5와 조건/예산/자원 CAS 결합.
3. solutions Host journal·모의 native endpoint·executor 연결. SEND_ENTERED 전후 실제 프로세스 장애와 응답 유실 검증.
4. 패키지·UI·인증·두 image·관리 도구·통합 인수까지 requirements 전체를 계속 구현.

초안 전체는 아직 미완료다. 이 checkpoint로 목표 범위를 축소하지 않는다.

## 2026-09-10 · v1 wire binding·C++ 상호운용·writer 실행 기반

- rx-protocol 추가: 두 Protobuf schema, 583개 필드 의미 alias, 생성된 Rust gRPC client/server 타입.
- rx-domain에는 통신 의존을 추가하지 않았다. wire→domain 변환은 rx-protocol 바깥 경계에서 수행한다.
- 문서 원본에서 독립적으로 추출한 403개 field 번호·타입·optional/repeated와 compiled descriptor 일치 확인.
- proto3 기본 parser 이전에 미지 필드, 중복 singular/oneof, 미지/명시 UNSPECIFIED enum, 잘못된 wire type, overflow/truncation, 비유한 실수를 거부.
- JSON은 일반 ProtoJSON 대신 RX 규약의 snake_case·hex Digest·문자열 uint64·명시 false/zero·닫힌 oneof를 사용. CV01 digest 보존 확인.
- 실제 loopback gRPC 시험에서 잘못된 bytes가 업무 handler에 도달하지 않음을 확인. 이 시험은 인증/mTLS 시험이 아니다.
- solutions에 독립 C++ strict parser와 CMake protocol target 추가. 프로토콜 source bundle의 hash를 빌드 전에 검사.
- Linux arm64 C++ Protobuf 3.21.12로 17개 positive/negative fixture 통과. Rust→C++→Rust 왕복 후 CV01 digest·uint64 최대값·optional zero·Cell.StartRun message 보존.
- 변조된 protocol bundle의 빌드 전 거부 확인. 검증용 image ID: sha256:efb3b752bd6f7d69dadf038330511997d4e5f3013302355e76a03e15e886525d.
- Operation/RunBudget의 저장 상태 복원 검증 추가. UNKNOWN·DISPUTED·소비 이력을 보존하며 모순/중복된 저장 상태를 거부.
- rx-runtime writer 추가: 전용 state thread, 전체 처리 중 요청 최대32(일반24/제어8), 제어 burst8 후 일반 처리, enqueue/close 직렬화, drain·panic 차단. Processor가 command 우선순위를 결정하며 client 입력에 priority를 받지 않는다.
- 응답 receiver 폐기 후에도 실제 SQLite commit이 남는지, 일반 부하가 제어8개 공간을 침범하지 않는지, worker panic 때 자동 replay 없이 차단하는지 시험.
- Rust 전체47개 시험 통과. 마지막 변경 후 writer3개 재검증 및 workspace clippy --all-targets -D warnings 통과.
- 출력/소스 hash 증거는 references/implementation/phase02_checks.*에 보존.

### 구현 바인딩 결정과 남은 범위

- 문서의 Session/Evidence는 message와 logical service 이름이 겹친다. 실제 IDL service에 Service 접미사를 붙이고 모든 generated client/server에 동일하게 적용했다. enum 상수에는 충돌 방지 prefix를 쓰며 RX JSON token과 wire 번호는 유지했다.
- CellSnapshot의 typed union을 SnapshotEntity(base_entity=1/cell_entity=2)로 구체화했다. 원문 manifest와 IDL/source bundle hash는 별도로 관리한다.
- strict wire 검사는 인증·필수 업무 필드·profile/현재 조건 검사를 대신하지 않는다. 각 실제 application/RPC handler의 검증은 다음 단계다.
- C++ 결과는 message 상호운용 증거다. C++ Intent JCS/digest 계산, gRPC Host, native journal·gate는 미구현.
- writer의 Processor는 현재 실제 업무 engine이 아니라 실행 경계다. 전체 T1–T5/cell admission, key/slot/budget/resource의 공동 transaction을 실제 command handler로 연결해야 한다.
- 다음 우선 작업은 rx-application의 설치·셀·run·명령·권한 state ownership과 Host handshake/outbox/evidence. 이후 패키지/BT/계정·UI/자사 전체 빌드/제품 image/설치복원까지 계속한다.

## 2026-09-10 · 실제 application state와 T1

- rx-application 추가. SQLite/Protobuf/ROS를 의존하지 않고 rx-ports transaction을 사용한다.
- 구현을 identity/access, configuration/admission, observation, workflow, dispatch, invalidation, request identity 모듈로 분리했다.
- principal/현재 session/단말 certificate binding을 저장 상태로 대조. 운영 요청의 key 조회 전에 현재 접근권 검사.
- CreateRun은 예산 없는 PREPARED draft를 만든다. StartRun에서 목적·예산 단위·한도를 고정하며 같은 key의 다른 예산은 충돌이다.
- StartAttempt는 run의 pending slot을 예약하고 모든 Host의 동일 epoch/boot Arm ack 이후에만 mandate·EXECUTING을 commit한다. 시작 준비 기한과 origin 권한/단말을 재검사한다.
- PartAttempt는 한 번만 예산을 소비하고 activation은 (run,node,visit)에 유일하다. 현재 유한 단계 binding에서 visit는 run 전체의 part ordinal을 사용한다.
- T1에 key/intent·activation slot·run CAS·전역 자원 예약·permit·outbox·사건을 결합했다. 실패 전 rollback과 commit 후 응답 유실을 실제 SQLite로 시험했다.
- permit 만료는 envelope TTL, grant 유효 기간, 사용한 관측의 유효 기간 중 가장 이른 시각으로 제한한다. 조건 ANY는 유효한 witness를, ALL은 전체 근거의 가장 이른 기한을 사용한다.
- 중단은 공통 resource/zone의 연결 범위로 전파한다. 공유 자원을 쓰는 셀은 함께 차단하고 독립된 셀은 계속 실행할 수 있다.
- 미전송 outbox를 원자적으로 VOIDED한 작업은 NOT_EXECUTED로 기록하되 자원은 격리한다. 이미 emit에 진입한 작업은 불명 재조정 경로로 남긴다.
- 동일 observation ID의 충돌이나 source generation 변화는 incident/무효화를 commit한 뒤 오류를 반환한다. 오류 응답 때문에 실제 변화 기록이 rollback되지 않는다.
- Runtime 재시작은 세션·mandate·permit를 되살리지 않는다. run 소비량을 보존하고 새 epoch/fence/차단 상태로 복원한다. 현재 검증 catalog와 맞지 않는 qualification은 이력에 남기고 활성 자격에서 제거한다.
- application18개 + 조건 witness1개 시험 추가. Rust 전체66개 시험·workspace clippy -D warnings 통과.

### 이번 단계의 한계와 다음 작업

- Host 준비/lease/Arm은 테스트의 검증된 입력이다. 실제 Host native gate·전달/evidence journal·gRPC 양방향 연결은 다음 단계다.
- 첫 resolved workflow는 유한 dependency steps다. 일반 분기·반복·하위 공정·BT compiler/체크포인트의 전체 의미는 아직 미완료이며 범위에서 제외하지 않는다.
- qualification 검증은 in-memory catalog port와 SimulationAuthority 시험이다. 실제 서명/보고서 validator·physical qualification은 미완료다.
- 공개 RPC와 application DTO의 전체 mapping, auth credential 검증, operator recovery/change/clearance, native 결과 T2/취소/T3–T5, 전체 UI와 제품 배포는 계속 남아 있다.
- 후속 우선순위: Host journal과 native-once gate → 모의 장비의 실제 Prepare/Authorize/Evidence 교환 → application 결과·자원/복구 → 공개 API·패키지/BT·UI·제품 image/관리 도구.

## 2026-09-10 · Host journal·native gate·프로세스 강제 종료

- solutions Rust workspace와 rx-host 추가. Host의 제어/기록은 Rust, ROS/SDK native 접근은 C++ 경계로 유지하는 구현 결정을 기록.
- 공통 SDK를 producer에서 export하고 46개 source 파일의 hash/inventory를 검증. P 업무 engine인 rx-application은 Host SDK에 포함하지 않음.
- Host delivery journal과 evidence outbox의 ID/순번을 분리했다. 같은 SQLite transaction에 permit 소비와 SEND_ENTERED를 저장한다.
- caller/session, binding/intent digest, permit 전체 내용, purpose/parent, Host boot, grant/fence, epoch/scope, local guard와 expiry를 대조한다.
- 같은 gate를 native 제출 진입까지 유지한다. 저장 이후 시간이 지난 경우 native 진입 전 유효성을 재검사한다.
- grant renewal replay는 유효 기간을 연장하지 않음. 같은 fence의 새 grant를 거부. Fence/Arm의 durable request receipt를 재사용하여 지연된 재전송이 새 상태를 지우지 않음.
- PREPARED를 새 permit로 검토·재결합할 때 이전 permit ID를 영구 폐기. SEND_ENTERED 뒤에는 조회/근거 회수만 수행하며 native 자동 재호출 없음.
- Prepare보다 먼저 온 취소/void 요청을 영속 tombstone으로 기록. Host receipt에 platform의 RESULT_RECORDED/operation revision을 부여하지 않음.
- 독립 file device를 사용하고 device 자체 owner lock과 실제 호출 로그를 Host DB와 분리했다. 장비 모형은 호출을 dedup하지 않으므로 중복이 발생하면 시험에서 드러난다.
- SIGKILL을 SEND_ENTERED commit 후/native 호출 전과 native 호출 후/evidence commit 전 두 지점에 주입. 재기동/동일 요청 재전송 후 효과 수가 각각 0회/1회로 유지됨.
- gate가 native 호출을 기다릴 때 fence가 앞질러 확정되지 않으며, 별도 protection port는 호출 가능함을 시험.
- Host11개 시험 및 clippy -D warnings 통과. platform66개 시험 증거는 phase03이며 이번 변경으로 그 결과를 전체 플랫폼-Host 통합 완료로 확대하지 않는다.
- 실제 build verifier에 미등록 build.rs 추가·기존 SDK source 변경을 주입해 빌드 전 거부를 확인.
- 증거: references/implementation/phase04_checks.* 및 phase04_sdk_check.json.

### 다음 우선 작업

1. Host의 mTLS/gRPC 표면과 platform의 outbox delivery/receipt/evidence ingest를 연결.
2. native 결과 T2, resource handover, 취소 journal, 연속제어 expiry/deadman 및 복구 명세의 실제 처리.
3. 선언형 공정/BT·패키지·공통 UI·계정/단말과 제품 두 이미지·관리 도구·통합 인수까지 진행.

현재는 Host library와 process-crash fixture 검증이다. 실제 보호 성능, 물리 장비 지원, 전원 상실 내구성, 전체 Runtime–Host 네트워크 흐름은 아직 검증하지 않았다.

## 2026-09-10 · Host mTLS/gRPC 실제 왕복

- Host server에 필수 client certificate, CA chain, 명시적 leaf fingerprint 등록을 적용했다. 인증된 peer 이름과 PeerHello의 설치/release/clock/base manifest를 대조한다.
- Cell.Open에서 cell manifest와 CellDefinition을 별도로 협상해야 해당 cell/resource API를 사용한다.
- session handshake의 동시 재시도는 같은 사용 가능한 세션으로 수렴한다. 요청 future가 사라져도 Host bind와 session publish가 어긋나지 않도록 blocking 작업에 handshake 소유권을 넘긴다.
- Host-owned grant/renew/inspect/fence/arm/prepare/authorize/receipt/reconcile를 실제 generated gRPC 표면에 연결했다.
- 플랫폼 소유 업무 메서드는 Host에서 거부한다. legacy base Prepare/Authorize도 cell gate 우회 경로로 사용하지 못한다.
- RPC request key와 stable effect ID를 정규화된 업무 body에 영속 결합. wire permit 전체의 digest를 저장해 로컬 gate에 직접 쓰지 않는 필드가 바뀌어도 같은 ID를 재사용하지 못하게 한다.
- 네트워크 handler는 장비/저장 작업을 bounded blocking 실행으로 넘기고, event loop에서 Host gate를 기다리지 않는다.
- 실제 test CA/server/client certificate로 session→cell negotiation→grant→Arm→Prepare→Authorize→Evidence 회수 수행. 중복 Authorize 뒤에도 독립 device log는1회.
- 유효 CA에 속하지만 미등록인 client, client cert 없는 접속, manifest 불일치, cell 협상 누락, key 내용 변경, legacy 우회를 거부하는 시험 통과.
- Host 전체16개 시험 및 clippy -D warnings 통과. 그중 mTLS 네트워크 시험5개. 기존 platform66개·C++17개 증거는 각각 앞선 단계의 범위다.

### 다음 구현의 입력

- 현재 네트워크 client는 테스트의 platform-like client다. rx-application의 실제 outbox consumer/receipt 처리/T2와 연결해야 한다.
- Host Reconcile의 최초 retained prefix만으로 큰 journal 전체를 따라잡을 수 없다. background Evidence.Publish와 durable ack cursor, 재연결/복원 generation별 catch-up을 구현해야 한다.
- H→P publish session과 P→H request session의 신원을 혼동하지 않는다. Reconcile 응답의 context는 echo/correlation이며 producer 권한은 검증된 Host 채널에서 얻는다.
- native result의 의미/후조건, observation·material/support evidence, cancellation journal, streaming/deadman/복구, 패키지/BT/UI/두 제품 이미지/인수는 여전히 남아 있다.

## 2026-09-10 · application outbox→Host→T2 실제 연결

- SQLite schema2 migration과 DELIVERED outbox 상태 추가. 이전 EMIT_ENTERED를 보존하며 처리 완료된 메시지를 NEW로 되살리지 않는다.
- application이 pending delivery를 제공하고 emission 전에 현재 run/permit/condition을 재검사한다. 이미 emit에 진입한 항목에는 원격 receipt 재조정이 필요하다는 결과를 반환한다.
- Host PREPARED receipt의 불변 식별·journal/seq·invocation을 저장하고 Authorize outbox를 같은 transaction에서 만든다. Arm ack와 그 outbox 완료도 공동 commit 경로로 연결.
- T2에 native evidence·source slot·연속 cursor·work 결과·사건을 결합. 중복 prefix는 재적용하지 않고 GAP을 건너뛰지 않는다. 동일 seq/ID의 상충은 증거와 차단을 commit한 뒤 오류를 반환.
- Native/Predicate/Unobservable completion policy를 구별했다. Host capture가 곧 성공이 되지 않으며 성공 기록과 자원 해제를 분리한다. 후발 모순은 원 outcome을 보존하고 DISPUTED로 격리한다.
- journal ID 변경은 자동으로 순번0부터 허용하지 않는다. 변경 사건과 관련 차단을 기록하고 명시적 gap 재조정을 요구한다.
- rx-host-client 추가: mTLS/계약 협상, grant·fence·Arm·Prepare·Authorize·receipt·evidence를 application DTO와 연결. 정해진 Host receipt 단계/증거 schema를 대조한다.
- 별도 Host 프로세스를 실행하는 end-to-end 시험 통과: application의 실제 시작/part/activation/T1 outbox → mTLS Host → 독립 device log1회 → Host receipt → T2 SUCCEEDED. 초기 준비 관측은 명시된 시나리오 fixture이며 TLS 연결 성공으로 추론하지 않았다.
- platform 일반73개 시험 통과. 별도 network end-to-end1개는 tools/test_host_e2e.sh로 실제 실행하여 통과. Host16개/C++17개 기존 범위도 구분한다.
- schema1→2 migration 보존, T2 rollback/ack 유실, 증거 중복/누락/상충, journal 변경 검증 추가. workspace clippy -D warnings 통과.

### 남은 작업

- 실제 사용되는 background outbox pump/receipt 조정/Evidence.Publish 및 durable ack/catch-up. 현재 E2E는 명시적 단계 호출로 경로를 검증했다.
- resource release는 성공과 별도이며 아직 HELD다. 현재 상태·잔류 명령·소재 지지 근거를 받아 다음 작업으로 넘기는 경로를 구현해야 한다.
- 일반 workflow/BT·공정/장비 패키지, operator recovery/change/clearance, native cancellation/stream, 전체 UI/auth 사용자 흐름, 자사 의존 전체 빌드·두 제품 image·설치복원·인수.

## 2026-09-10 · 현재 인계 근거와 반복 소재 시도

- Host native adapter에 handover_snapshot port 추가. 미구현 adapter는 근거를 합성하지 않고 거부한다.
- 모의 file device의 현재 잔류 명령·제어 사용 가능·지지 상태를 작업/호출/device session에 결합한 세 관측으로 제공한다. 현재 물리 장비 구현이나 보호 성능 검증은 아니다.
- Host.WatchObservations의 명시된 handover source 집합으로 최신 snapshot을 받는다. 클라이언트는 schema·source 집합·correlation·quality·획득 오차를 대조한다.
- 플랫폼은 작업 완료와 자원 해제를 분리한다. 현재 cell revision/epoch, Host boot, device session, 원 invocation, 실제 완료 이후 관측, 세 조건·최대 age가 모두 맞을 때만 release를 commit한다.
- release에 사용한 관측·resource holder 변경·operation disposition·key·사건을 같은 transaction으로 기록한다. 실패 rollback과 같은 key 반복을 검증했다.
- PartAttempt 처분과 complete_part 검증 추가. 해당 part의 필수 단계가 SUCCEEDED/VALID이고 자원 인계까지 끝나야 CONFIRMED_COMPLETED가 된다.
- 허용 시도 예산을 다 사용하고 모든 part가 완료되면 run COMPLETED·mandate EXHAUSTED를 기록한다. 양품 품질 판정을 의미하지 않는다.
- 별도 Host process/mTLS E2E를 2개 소재 시도로 확장. 첫 작업 완료·인계 후 같은 자원을 두 번째 작업이 사용하고 최종 run 완료, 독립 device effect log2회를 확인.
- platform76개 일반 시험 통과 + 별도 network E2E1개 통과. Host16개 시험과 양쪽 clippy도 통과.

### 남은 경계

- 현재 E2E는 명시적 executor 단계 호출이다. 자동 운영 service/outbox pump/사용자 API와 UI가 아직 아니다.
- handover source는 snapshot 조회이며 일반 센서의 지속 stream·고속 control/deadman은 별도다.
- recovery/UNRESOLVED 후 인계·clearance, full workflow/BT·packages, 실제 지원/제품 image/유지보수·인수 목표를 계속 유지한다.

## 2026-09-10 · 실제 writer 기반 로컬 서비스와 운영 화면

- `rx-runtime::application`에 typed Command/Reply, Application Processor와 외부 서비스용 Handle/Port를 추가했다. 실제 application/SQLite는 전용 writer thread에서 소유한다. 조회·운영·세션 요청도 이 경계를 통과한다.
- `rx-application`에 현재 사용자 profile, user session 발급/종료, 권한별 일관 overview, idempotent 최초 셀 구성 등록을 추가했다. profile·셀·run·work를 같은 transaction에서 읽는다. 전역 control journal seq를 UI cursor로 노출하지 않는다.
- `rx-api`와 `rx-platform-local` 실행 파일을 만들었다. Argon2id 검증은 별도 제한된 worker에서 수행한다. 실제 socket/Host/Origin, JSON 중복/unknown field, cookie session, DB의 현재 역할/셀 권한을 검사한다.
- 이 실행 파일은 명시적 loopback 개발 설치만 받는다. 별도 Host 연결·자격 발급·장비 launcher가 없고, caller가 입력한 단말/역할 헤더를 신원으로 쓰지 않는다. 로그인은 실제 StartRun의 단말 검사를 우회하지 못한다.
- `rx-solutions/apps/operator`에 React/TypeScript 운영 앱을 만들었다. 로그인, 셀 상태, 새 실행 준비, 운전 보류, 실행/작업 기록, 현재 구성과 내 권한을 실제 API에서 조회한다. 장비 관측/결과/무결성/자원 처분을 구별한다.
- UI는 권한·자격을 자체 생성하지 않는다. 현재 연결/운전 가능으로 확인되지 않은 구성 항목을 연결 성공으로 표시하지 않는다. 셀 revision과 run revision은 각각 기록 버전으로 표시한다.
- 확인 창에서 검토한 cell revision과 요청 내용을 고정했다. 배경 조회가 갱신돼도 자동 교체하지 않는다. 상태가 바뀌면 application이 stale revision을 거부한다.
- mutation 전 key/내용/principal/installation/store generation을 sessionStorage에 보관한다. commit 뒤 응답을 잃어도 reload 후 같은 요청으로 회수한다. 미확정 요청을 새 key로 바꾸거나 조용히 지우지 않는다. 권한·복원 세대가 다르면 재전송을 막는다.
- 서버 조회 오류 또는 표시 상태가 오래되면 새 요청을 비활성화한다. 비밀번호와 session token은 브라우저 저장소에 보관하지 않는다. UI와 API 양쪽에 별도 구현한 운전 상태기계는 없다.
- platform 일반 시험81개(HTTP/실제 writer5개 포함) 통과, ignored network E2E1개는 이번 일반 시험의 통과 수에 포함하지 않았다. 기존 단계의 Host16개·C++17개·P–H network E2E 증거는 해당 범위를 유지한다.
- UI unit3개와 TypeScript/Vite build·format 검사 통과. 실제 server commit 후 응답 유실→reload→동일 key 회수에서 실행 기록이1개로 유지됨을 headless Chromium으로 확인했다. 검토 중 상태 변화·조회 연결 상실·logout·모바일 overflow도 확인했다. 실제 장비/모의 Host 프로세스는 이 UI 시험에 기동하지 않았다.

### 새 실행 입구와 증거

- [platform 서비스 경계와 실행 방법](../../rx-platform/crates/rx-api/README.md)
- [solutions UI 구조와 재현 방법](../../rx-solutions/apps/operator/README.md)
- [브라우저 검사 결과](../../references/implementation/phase08-ui/browser-result.json)
- [운영 화면](../../references/implementation/phase08-ui/operator-overview.png)
- [응답 유실 후 확인 화면](../../references/implementation/phase08-ui/operator-pending.png)
- [모바일 화면](../../references/implementation/phase08-ui/operator-mobile.png)
- `phase08_checks.json`에 검증한 source hash·명령 결과·제한을 기록한다.

### 다음 구현의 범위

- 이번 서비스에 automatic outbox pump/Evidence.Publish/지속 관측/공정 실행기를 연결하는 일은 남았다. 현재 브라우저는 새 실행 기록을 준비하며 실장비를 시작하지 않는다.
- snapshot은 3초 polling이며 SSE·paged projection·대규모 indexed read가 아니다. 내부 scan 비용을 제품 규모에서 검증하지 않았다.
- 로컬 credential 파일과 DB 계정 권한을 하나의 관리/변경 흐름으로 완성하지 않았다. LAN/TLS/등록 단말, credential rotation·제품 secret 공급은 후속이다.
- UI는 기본 운영과 읽기 화면이다. 시각 공정 편집/BT·장비/공정 패키지, recovery/clearance/change/검증/배포/지원의 전체 사용자 흐름은 계속 구축한다.
- 두 제품 이미지, 자사5개 필수 stack와 전이 의존 빌드, Host lifecycle/continuous control/deadman, 설치·업데이트·복원·인수 목표는 그대로 유지한다.

## 2026-09-10 · 원본 보존과 Host 증거 전송

- 공유 `rx-protocol-adapter`를 추가해 Publish와 Reconcile가 같은 native evidence 변환을 사용하게 했다. 이전 변환에서 누락하던 native_id/native_data도 immutable 비교와 원본 조회에 포함한다. 과거 불완전 projection은 완전한 wire 원본으로 재구성하지 않는다.
- T2 결과에 producer through와 같은 transaction의 사건 위치를 결합했다. producer 소유권도 기록해 다른 Host가 동일 evidence ID를 재사용하거나 원본을 조회하지 못하게 한다.
- P의 `EvidenceIngress`에 실제 mTLS listener, Session.Open, Cell.Open, Evidence.Publish/Get을 연결했다. 등록 certificate·현재 principal·installation/store generation·release/clock·두 manifest·cell membership을 검사한다.
- producer session/Host boot/journal/인증 binding을 영속 연결했다. 동일 reconnect는 같은 session으로 수렴한다. 다른 incarnation/binding은 이전 session과 연관 운전 권한을 무효화한다. 브라우저 계정 수명과 구별하며 새 session으로 native 권한을 재생성하지 않는다.
- S의 `publication::Publisher`가 Host evidence journal을128개/1 MiB 및 협상된 더 작은 한도에 맞춰 전송한다. 각 destination의 ack 위치를 H에 저장하고, 응답 유실에는 같은 source seq/ID를 다시 전송한다. native 명령의 재전송 API는 이 모듈에 없다.
- ack의 설치/복원 세대/view/journal/range·일관된 순번을 검사한다. 과거 ack가 cursor를 되돌리지 않으며, 잘못된 세대·범위·후퇴·부분 batch ack는 수용하지 않는다. 원본 retention 삭제는 아직 하지 않는다.
- `Repository::journal_head`를 추가해 cursor/tail 읽기에 entity 전체 snapshot을 사용하지 않도록 했다. 갱신된 SDK47개 source bundle을 S에 재수출했으며 P application은 여전히 제외했다.
- platform 일반85개, Host17개 시험 통과. 양쪽 clippy -D warnings 통과. 별도 모의 장비 P–H E2E와 별도 publisher E2E를 각각 실행하여 통과했다. 일반85개의 ignored2개를 통과 수에 포함하지 않았다.
- publisher E2E는131개의 합성 orphan evidence를 사용했다. 첫 data batch를 P가 commit한 뒤 ack를 잃게 했고, 저장 slot은131개로 유지됐다. H restart 후 같은 journal/cursor, 이전 producer session 거부, 미등록 certificate 거부, 마지막 native metadata 조회를 확인했다. 이 시험에서는 실제/모의 native 호출을 하지 않았으며 qualification도 부여하지 않았다.
- 기존 P–H 작업 E2E는 별도로 두 모의 소재 시도의 T1→Host→T2→handover를 확인했다. publisher의 합성 기록 시험을 native 효과 검증으로 합쳐 표현하지 않는다.

### 관련 문서와 재현

- [P 증거 수신 경계](../../rx-platform/crates/rx-api/src/grpc/README.md)
- [무손실 protocol 변환](../../rx-platform/crates/rx-protocol-adapter/README.md)
- [H 전송과 영속 ack](../../rx-solutions/runtime/rx-host/PUBLICATION.md)
- `rx-platform/tools/test_evidence_e2e.sh`, `rx-platform/tools/test_host_e2e.sh`
- `references/implementation/phase09_checks.json` 및 각 실행 log

### 다음 필수 경계

1. **공개 제어 원장 cursor**: 현재 DurableAck.platform_cursor.seq는 공유 내부 사건 로그 위치다. 내부 감사 사건과 공개 EventType/EntityView의 분리·정확한 매핑이 미완료다. `Journal.Subscribe/GetSnapshot`은 열지 않았으며, cursor binding을 정리하기 전 해당 계약을 VERIFIED로 올리지 않는다. producer through의 전달 검증과 공개 원장 적합성은 별개다.
2. **P→H 자동 outbox 전달**: 아직 명시적 단계 호출을 사용하는 작업 E2E다. 송신 재개 시 current authority/Host receipt 확인, PREPARED와 SEND_ENTERED의 다른 처리, 알려진 receipt 중복의 outbox 완료, 증거/receipt 도착 순서와 재조정까지 연결해야 한다.
3. **구성·배포 합성**: EvidenceIngress/Publisher는 library와 시험 프로세스에서 동작한다. 제품 두 이미지의 상주 프로세스/호스트 관리 도구와 자동 운전 서비스 구성은 후속이다.
4. 전체 source/profile/cancel/observation/attestation evidence, P 업무 RPC·공정/BT·packages·복구/clearance, 자사 필수 stack 빌드·업데이트·복원·인수를 계속 구현한다.

## 2026-09-10 · 감사/제어 순번 분리와 atomic control capture

- SQLite schema3에 control_events/control_entities를 추가했다. 기존 내부 audit/events, Host evidence journal, request/outbox 자료는 보존한다. 제어 사건과 현재 projection은 독립적인 연속 seq를 사용한다.
- Journaled<R>가 application transaction의 실제 core entity put을 추적하고 원래 transaction 안에서 최종 변화와 projection을 기록한다. handler별 event 호출에만 의존하지 않는다. 같은 transaction의 중간 값을 공개된 상태처럼 기록하지 않는다.
- 첫 제어 원장 초기화에서 기존 상태는 SNAPSHOT_SEED로 표현하며, 과거 사건을 새 실행 접수로 위장하지 않는다. 초기화 marker를 영속 보관한다.
- T2 ack는 control capture가 끝난 동일 transaction의 head를 받는다. 로그인/감사 append가 이 seq를 바꾸지 않으며 동일 evidence batch 재수신으로 제어 사건이 늘어나지 않는다.
- 셀 확장의 올바른 view 이름 site-cell-control-v1로 수정했다. H의 ack 검사와 영속 cursor key에도 view 이름을 반영하여 예전 audit/base 위치를 재사용하지 않는다. 빈 원장의 seq0도 표현할 수 있다.
- 저장/원장 원자성 fault injection, 직접 tx.put을 사용하는 Hold capture, source event의 연속 순번/exclusive after와 현재 projection 일치를 검증했다.
- platform 일반88개·Host17개와 양쪽 clippy 통과. 별도 publisher131개/ack 유실/restart 시험과 두 모의 소재 시도 P–H 작업 시험도 각각 통과했다. ignored2개는 일반 시험 통과 수에서 제외한다.
- SDK48개 파일을 재수출했고 P application은 S에 넣지 않았다. frozen 규범8개 파일은 변경하지 않았다.

### 완료한 것과 남은 것

내부 감사 순번을 control cursor에 넣던 문제는 별도 저장 구조와 같은 transaction cut으로 수정했다. **저장된 control payload는 현재 typed application 상태 snapshot이다.** 공개 CellJournalRecord/EntityView의 전체 변환·snapshot/paging·구독은 아직 미완료다.

특히 CellContext mode/commissioning·Block 생성 revision, Qualification limitations/상태, 검증된 checkpoint artifact, Mandate/Permit의 당시 관련 상태, 후속 case/material/change 모델을 정확히 보존·변환해야 한다. 현재 DB 값을 과거 사건에 붙이거나 빈 필드를 임의 값으로 채우지 않는다. 공개 Journal RPC를 아직 열지 않았고 R17은 PARTIAL이다.

다음 구현은 [제어 원장 상세](../../rx-platform/crates/rx-application/CONTROL_JOURNAL.md)의 모델·wire mapping과 P→H 자동 outbox 전달 경계다. 공정/장비 패키지·BT·복구·제품 이미지·자사 지원·설치복원·인수의 전체 목표는 유지한다.

## 2026-09-10 · P→H 자동 전달과 수신 기록 경합

- Host마다 bounded Dispatcher를 구성하고 실제 writer의 typed Command를 통해 Arm/Prepare/Authorize/Fence 전달과 GetReceipt/Reconcile/T2 조정을 수행한다. SDK 직접 호출과 workflow 결과 판정을 sender에 넣지 않았다.
- plan_delivery는 Host 권한·메시지 관계와 최초 emission의 현재 run/permit/condition을 같은 transaction에서 확인한다. 이미 EMIT_ENTERED이면 operation 요청을 다시 보내지 않고 receipt를 조회한다.
- pending outbox의 exclusive key paging과 cursor 순환, 제한된 pass/backoff를 구현했다. 앞쪽 미결 항목 때문에 뒤쪽 메시지가 영구적으로 숨지 않는다. scheduling memory와 별개로 미결 상태는 영속 저장된다.
- PREPARED 응답으로 Authorize outbox를 완료 처리하던 경계를 수정했다. 동일 receipt를 이미 저장했어도 올바른 관련 outbox는 완료한다. 잘못된 message를 cached receipt 때문에 수락하지 않는다.
- timeout/NOT_FOUND 등에는 UNKNOWN/격리와 영속 attention을 남긴다. PREPARED 상태의 이전 authorization은 새 grant/permit 재결합이 필요하다고 표시하며 자동 native 재전송하지 않는다.
- 늦은 receipt가 invocation 상관관계를 확정하면 보관한 native evidence를 같은 transaction에서 재평가한다. native entry가 입증되면 permit를 소비하고 아직 NEW인 authorization을 폐기한다.
- Fence ack의 Host boot/journal/target/message 관계를 확인하고 수신 근거와 outbox 완료를 함께 기록한다.
- Runtime은 새 전달·작업·인계 command를 같은 application에 연결한다. SubmitWork payload는 큐 메시지 크기를 줄이도록 box 처리했다.
- platform 일반92개·Host17개 및 양쪽 clippy 통과. 별도 프로세스 통합 시험은 명시적 작업 경로, 자동 dispatcher 경로, evidence publisher 경로의3개를 실제 실행했다. 일반 시험의 ignored3개를 pass 수에 포함하지 않았다.
- 자동 dispatcher 시험은 첫 Host Authorize가 실제 모의 호출을 마친 뒤 응답을 잃게 한다. 두 part에서 Authorize2회·독립 device effect2회로 유지됐고, GetReceipt/Reconcile로 결과를 회수했다. 완료 후 Hold의 Fence가 Host에 자동 적용되는 것도 확인했다.

### 범위와 다음 연결

[자동 전달 구조](../../rx-platform/crates/rx-host-client/DELIVERY.md)에 수신 기록별 행동과 한도를 기록했다. part/activation 생성, 인계 proof 취득·release, part 완료는 시험 executor가 명시적으로 수행한다. 이를 완전한 자율 생산 서비스로 표현하지 않는다.

새 grant/rebind·Host 재등록·attention→case/절차 UI, 큰 저장소의 reconciliation index, 제품 process supervisor 통합은 남았다. Reconcile의 초기128개 prefix를 넘어서는 전달은 별도 Publisher를 함께 배치해야 한다. 공개 제어 원장 wire mapping과 checkpoint 모델, 공정/장비 패키지·BT/편집기, 실제 자사 지원·두 이미지·설치복원·인수의 전체 목표도 계속 유지한다.

## 2026-09-11 · 패키지 신뢰/내용 경계와 자사 기본 catalogue

- P의 ROS 비의존 rx-package에 Device/Process/UI 공통 manifest, 파일 inventory, target/계약/ABI, 잠긴 의존성과 외부 asset 참조를 구현했다. S SDK에 같은 verifier를 수출한다.
- Ed25519 strict signature는 domain/key ID/정규화 manifest에 결합한다. 내용 digest와 signer rotation을 구별하며, 다른 key alias의 권한을 같은 서명으로 이용하지 못하게 한다.
- 종류별 permission 요청과 signer 허용 범위를 검사한다. UI/Process가 native endpoint 권한을 요구하거나 Process/UI가 native executable을 포함하면 거부한다. 검증 통과가 OS 접근권·장비 실행권·qualification 부여를 뜻하지 않는다.
- 전이 dependency에서 정확한 version/kind/digest, target/contract, 현재 trust를 재검사한다. root 구버전 재유입·동일 이름의 다른 버전·cycle·회수된 key의 기존 검증 결과를 거부한다.
- 폴더는 capability 안에서 regular file만 읽고 경로 탈출·symlink·case/hierarchy alias·reserved 이름을 차단한다. 수/깊이/bytes를 제한하며 검증 후에는 원본 경로가 아닌 immutable bytes를 보유한다.
- ROS 비의존 target과 특정 ROS 배포판 요구를 구별한다. 큰 policy/model asset은 독립 검증된 ArtifactRef catalogue로 연결할 수 있으며 대형 asset store/streaming 자체는 후속이다.
- S에 rx-solution-catalog와 robotis-support.v1.json을 추가했다. 다섯 필수 source와22개 모델/역할 구성을 유지한다. FFW BG2 revision3개와 leader/follower를 분리했다. Host가 이 catalogue를 필수 의존하며 시작 때 기본 구성을 확인한다.
- 모든 catalogue 행은 SOURCE_OBSERVED다. GPIO의 중첩 interface 구조를 보존하고 선언된 update rate/관절 배열을 실측/actuator 개수/완료 보장으로 바꾸지 않는다.
- Git commit blob으로 출처22개 파일을 대조했다. 다섯 레포 pin은 기존 확정 값과 같았다. 실제 ROS 패키지 로딩이나 controller 활성화는 하지 않았다.
- SDK exporter는 신선한 staging inventory를 만들고 교체한다. 기존 SDK의 수정·추가 파일은 덮어쓰기 전에 거부하고, 과거 inventory의 불필요한 생성 파일은 새 수출에 전파하지 않는다. P authority engine은 제외하며 SDK53개 파일을 수출했다.
- platform 일반100개, solutions19개(Host17+catalogue2), 양쪽 clippy 통과. 기존 명시적/자동 작업 및 publisher 별도 프로세스 E2E3개도 통과했다. 패키지8개 시험과 SDK 수출 regression, source identity 검사 범위를 각각 구별한다.

### 산출물과 다음 경계

- [패키지 신뢰·파일 경계](../../rx-platform/crates/rx-package/README.md)
- [자사 기본 catalogue](../../rx-solutions/catalogs/README.md)
- tools/test_export_host_sdk.py, tools/check_robotis_catalog_sources.py 및 phase12 검증 기록

현재 VerifiedPackage는 내용·서명·호환 검사 결과다. 실제 descriptor semantic validation, DeviceFamily/Profile/ProcessSource·현장 resolved binding, package stage/install/activate, trust key 운영·OS sandbox, image 전체 전이 의존 빌드와 qualification은 아직 미완료다. 원래의 공개 원장 wire/checkpoint, 공정/BT/편집기, 복구/배포/복원/인수 목표를 그대로 유지한다.

## 2026-09-11 · 공정 원본·확장·후보 계획

- S의 rx-process에 Sequence/ParallelAll/Branch/Repeat/Call/Operation/Wait/Intervention 원본 schema와 결정적 compiler를 추가했다. 기존 source ID와 인스턴스 경로를 보존한다.
- 반복과 하위 flow를 유한하게 확장하고 고유 node identity를 만든다. duplicate/cycle/shared node/누락/도달 불가/깊이·확장 상한을 검사한다. 병렬의 실제 normalized resource set이 겹치면 거부한다.
- resolved source와 binding digest를 ProgressView에 결합했다. 다음 후보는 완전한 P view·기록된 branch/wait/개입 결정과 operation 결과·자원 인계를 기준으로 계산한다.
- UNKNOWN/DISPUTED/UNRESOLVED를 FAILURE로 낮추지 않는다. 미선택 branch 이력·부분 view·앞 단계가 없는 뒤 단계 이력은 거부한다. 계획 완료를 part/품질/운전 허가로 기록하지 않는다.
- VerifiedPackage Process entry에서만 source를 가져오는 semantic compiler 경로와 선언된 OperationSubmit permission 검사를 추가했다. 서명된 잘못된 문법도 거부한다.
- BT.CPP format4의 RX 전용 노드 XML, resolved JSON과 compile report를 생성하는 CLI를 추가했다. 임의 script/include/retry decorator는 출력하지 않는다.
- 소재 공급5단계 예제 파일을 컴파일하고 XML 구문을 확인했다. 산출물은 COMPILED_NOT_QUALIFIED다. placeholder program/parameter와 simulation 대상이며 실제 장비/현장 입력을 검증하지 않았다.
- process 관련9개 시험이 통과했고 solutions 전체28개 및 clippy가 통과했다. P 코드는 변경하지 않았으며 앞 단계의100개/P–H 통합 증거는 그 범위를 유지한다.

### 산출물과 필수 후속

[공정 모델/계획 경계](../../rx-solutions/runtime/rx-process/README.md), [예제 원본](../../rx-solutions/examples/process/README.md), [컴파일 보고서](../../references/implementation/phase13-compiled-example-v2/compile-report.json).

현재는 compiler와 pure frontier planner다. RX C++ BT 노드·factory/P client·halt/restart 복원, P의 branch/visit/checkpoint eligibility, 전체 public journal mapping, visual editor를 아직 연결하지 않았다. P의 기존 finite StepBinding에 분기/반복을 임의 flatten하여 운전하지 않는다. package/profile/site resolver·복구·실제 자사 image build·배포복원/인수 목표도 그대로 유지한다.

## 2026-09-11 · 실제 C++ BT 노드와 제한된 요청 큐

- BehaviorTree.CPP4.8.3 exact commit을 별도 dependency lock에 고정하고 실제 Linux C++17 build를 만들었다. Vendor는 원본 cache이며 source 변경을 검증 도구가 거부한다.
- RXSequence/RXParallelAll/RXBranch/RXOperation/RXWait/RXIntervention을 실제 factory에 등록했다. tick은 immutable Frame을 읽고 제한된 큐에 요청을 넣으며 ROS/native SDK나 P 결과 저장을 직접 호출하지 않는다.
- Context를 run/session/resolved digest/visit/epoch에 묶었다. complete/current/monotonic expiry/현재 submission 권한/eligible node를 확인하며, 큐에서 꺼낼 때도 회수·만료를 다시 검사한다.
- 동일 operation ID/branch decision/terminal outcome의 변경과 complete view의 binding 유실을 거부한다. 잘못된 Frame은 이전 정상 Frame을 계속 쓰지 않도록 정지하고 pause 요청을 남긴다.
- 반복 tick과 트리 재구성이 같은 요청을 재생성하지 않도록 Context 수준으로 dedup한다. 정상 요청32개와 별도 pause1개를 둔다. Halt는 pause 요청이며 native cancel/정지/자원 해제 완료가 아니다.
- UNKNOWN/UNRESOLVED/상충은 RUNNING으로 대기한다. 성공 후 release를 기다리고, parallel의 불명·실패·개입 대기에서는 새 admission을 억제한다. 진행 중 sibling을 임의로 완료/취소 처리하지 않는다.
- Factory 이전 XML 허용 목록을 구현했다. registry와 node kind/ID/속성/자식 순서·전체 목록을 대조하며 script/pre/post/include/임의 builtin/추가 attribute를 거부한다.
- 네 C++ 시나리오와 Rust compiler가 생성한5단계 예제를 실제 BT 엔진에서 실행해 통과했다. 시험은 network none/read-only/cap-drop all/no-new-privileges, 읽기 전용 fixture mount로 수행했다. C++ build는 -Wall/-Wextra/-Werror다.

### 검증의 범위와 다음 작업

[native executor](../../rx-solutions/native/executor/README.md), tools/test_bt_executor.py, [시험 결과](../../references/implementation/phase14-bt/result.json).

P Frame·완료·decision·clearance는 합성 fixture다. 실제 P 통신 client, 정확한 protocol-to-Frame/eligibility mapping, 영속 request key/checkpoint와 restart 조정은 아직 연결하지 않았다. executor-validation은 제품 두 이미지가 아닌 검증 target이다. 이 시험을 장비 동작·실제 로봇·qualification 인수로 표현하지 않는다.

P의 공개 원장/완전한 checkpoint와 분기·visit 검증, package/profile/site resolver·시각 편집·전체 복구, 자사 stack의 두 제품 image·설치/업데이트/복원·인수를 계속 구축한다.

## 2026-09-11 · P 공정 결정/eligibility와 공통 의미 모델

- 공정 schema/frontier를 ROS·BT·I/O 비의존 rx-process-contract로 옮겼다. S는 SDK를 사용하며 source compiler/XML/C++ runtime 구현은 계속 S 소유다. P authority engine은 S에 넣지 않았다.
- CellConfiguration의 graph mode에서 resolved 구조·ID·resource와 recipe digest/schema/size, StepBinding Host/Intent를 검증한다. Graph와 별도 predecessor 해석을 섞지 않는다.
- P가 branch 선택을 현재 fact로 평가하고 decision/근거/시각/checkpoint/run revision/key를 함께 저장한다. UNKNOWN은 선택하지 않는다. 기존 선택은 재요청이나 이후 조건 변화로 바꾸지 않는다.
- P가 wait window와 deadline을 소유하고, 현재 조건/마감으로 결과를 기록한다. 재요청이 마감을 연장하지 않으며 caller의 PASS/시각을 받지 않는다.
- ResolveActivation과 새 Submit 모두 P의 실제 frontier eligibility를 검사한다. 선택하지 않은 branch와 미완료 wait/predecessor를 우회하지 못한다.
- Part 완료는 선택된 graph와 작업 결과/인계를 확인한다. P restart 후 decision/checkpoint는 유지되고 run authority는 철회된다.
- Runtime typed Command와 P progress 읽기에 연결했다. 외부 Workflow.CommitCheckpoint wire·artifact·C++ P client 연결은 아직 미완료다.
- P의5개 추가 시나리오가 통과했다. 전체 platform105개/solutions28개·양쪽 clippy, 별도 작업/dispatcher/publisher E2E3개와 실제 BT engine 시나리오/생성예제 검증이 통과했다. Frozen 규범 파일은 변경하지 않았다.

[공통 모델](../../rx-platform/crates/rx-process-contract/README.md), [P checkpoint](../../rx-platform/crates/rx-application/PROCESS_CHECKPOINT.md).

남은 핵심은 실제 executor wire adapter·checkpoint artifact/public journal 전체 표현, intervention/recovery/restart, index/성능, 시각 편집·현장 package resolver, 두 제품 image의 자사 stack·설치업데이트복원·인수다. Graph의 내부 결정 검증을 전체 외부 계약/물리 운전 검증으로 승격하지 않는다.

## 2026-09-11 · 내용 주소 checkpoint와 일관된 RunView 읽기

- 실제 Run 변경 transaction에서 activation/slot/intent 연결과 visit별 공정 결정을 수집하여 `rx.executor-state.v1` artifact를 만든다. canonical bytes의 실제 SHA-256/size를 저장한다.
- 원래 Run revision과 현재 RunSnapshot, immutable artifact·run 소유 참조, control event/projection을 같은 commit에 묶었다. schema 초기화 marker도 같은 transaction에 기록한다.
- slot의 Work가 실제 run/activation/part/cell/slot/operation에 속하는지 대조한다. 복원 조회에서 현재 Run과 snapshot, payload의 revision/내용·연결을 다시 확인한다.
- 이전 artifact는 새 revision 및 P restart 후에도 보존한다. restart 뒤 새 snapshot의 현재 상태는 권한 철회를 반영하며, 과거 EXECUTING이 현재 권한이 되지 않는다.
- Runtime typed command 및 로컬 BFF 두 GET route에 연결했다. RunView는 frozen codec의 Counter/enum/optional 규칙을 사용한다. Artifact 조회는 현재 세션·셀 접근권과 run별 소유 참조를 요구한다.
- T1 rollback/commit 후 응답 유실·동일 key 회수·원장 projection 일치, 이전 artifact 보존·잘못된 ref/접근권 거부를 검증했다. 기존 restart 시나리오에 branch 결정과 과거/현재 artifact 대조를 추가했다.
- 실제 HTTP/SQLite 조회와 strict query 입력, 여섯 RunState·2^53 초과 Counter를 검증했다. 최신 view에 정상적인 과거 artifact를 끼워 넣거나 저장 payload를 변경하면 무결성 오류가 난다.
- 전체 P109개 일반 시험 후 추가 무결성 시험을 포함한 영향 패키지를 재검증했다. 누적 P110개, 실패0. 현재 소스로 clippy와 별도 작업/자동 dispatcher/publisher E2E3개가 통과했다. S의 일반28개와 실제 BT 시험은 phase15의 범위이며 이번에 반복 실행했다고 표시하지 않는다. frozen 규범8개는 변경하지 않았다.

[저장/조회 명세](../../rx-platform/crates/rx-application/CHECKPOINT_ARTIFACT.md), [검증 기록](../../references/implementation/phase16_checks.json).

현재 artifact는 내부 run history를 한 문서로 담으며 entity scan과1 MiB 제한을 사용한다. 장기 생산의 용량 예약·분할·index·retention 및 한계 근처의 제어/evidence 수용 보장은 아직 완료하지 않았다. 실제 executor mTLS/Workflow.GetRun/CommitCheckpoint·artifact 확보·C++ Frame/worker 복원, 전체 public journal, intervention/recovery, 현장 package·시각 편집·자사 제품 image/배포/인수 목표를 유지한다. 원격 실행기 복원 또는 실제 장비 qualification 완료로 승격하지 않는다.

## 2026-09-11 · 실행기 peer 협상과 실제 원격 Run 조회

- PlatformIngress에 등록된 Executor의 Session.Open/Cell.Open/Workflow.GetRun을 연결했다. 기존 EvidenceIngress 이름은 호환 alias이며 Host evidence의 인증 binding은 유지했다.
- P의 ExecutorPeer는 principal/session/boot/인증 binding/협상한 cell definition을 영속 기록한다. Host와 Executor principal을 분리하고 body role을 권한으로 받아들이지 않는다.
- 동일 Open/응답 유실 뒤 session ID와 epoch는 유지한다. peer boot/binding 교체는 기존·legacy session을 철회하고 해당 실행기의 셀 및 공유 자원 영향 범위를 같은 transaction에서 무효화한다.
- 폐기된 E boot를 영속 기록하여 늦은 이전 프로세스의 Open이 새 session을 밀어내지 못하게 했다. P 재시작 뒤에도 이전 session/폐기 boot는 거부하고 현재 E boot는 새 P session/셀 협상을 요구한다.
- GetRun은 같은 인증서의 현재 base session, cell 협상, 계정 셀 범위, 실제 executor 배정과 현재 checkpoint 무결성을 확인한다. 이 조회가 run의 executor 권한을 호출자의 새 session으로 교체하지 않는다.
- 실제 TLS socket/SQLite 시험으로 두 manifest 협상 전 조회 거부, 미등록 인증서·역할 사칭·동일 principal의 다른 인증서 session 재사용·다른 executor 배정 셀 접근 거부를 검증했다.
- 현재 P 일반112개·clippy가 통과했다. 별도 명시적 작업/자동 dispatcher/Host publisher E2E3개도 새 ingress로 통과했다. frozen 규범8개와 phase15에서 검증한 S source는 유지한다. S 일반28개/실제 BT 증거는 이번 반복 실행으로 표시하지 않는다.

[실행기 세션 명세](../../rx-platform/crates/rx-application/EXECUTOR_PEER.md), [검증 기록](../../references/implementation/phase17_checks.json).

Workflow mutation/CommitCheckpoint, E의 artifact 확보·C++ Frame/request worker와 영속 pending key 복원은 아직 미완료다. 서비스 등록은 connection liveness/readiness가 아니며 heartbeat/disconnect monitor·새 시작 판단과 함께 구현해야 한다. 현재 등록/조회 경로만으로 실장비 운전이나 자동 복구 완료를 주장하지 않는다. 장기 run 용량·index/원장전체/복구·현장 package·편집기·자사 두 제품 이미지·배포복원/인수 목표도 계속 남아 있다.

## 2026-09-11 · 실행기 소재 시도·단계 요청과 최초 접수 근거

- Cell.BeginPartAttempt와 Workflow.ResolveActivation을 실제 mTLS→typed command→writer/SQLite에 연결했다. 계정/session/협상 definition과 executor 배정을 현재 transaction에서 확인한다.
- 공개 요청의 전체 payload(명시한 mandate·visit·객체 CAS 포함)를 key에 결합했다. 동일 요청 회수와 새 의도를 구별하고, 바뀐 payload의 같은 key는 ALREADY_EXISTS/KEY_CONFLICT로 반환한다.
- 기존 trusted composition 경로와 공개 요청 경로가 part 예산 소비·activation 할당의 같은 transition 함수를 사용하도록 정리했다. handler에 별도 상태기계나 SQL을 만들지 않았다.
- PartAttempt 응답의 실제 record revision, activation/slot/intent snapshot과 요청 결과를 core 변경 및 Run checkpoint와 같은 commit에 보존한다. 실제 소재 identity가 없는 material_id는 absent다.
- 저장 직전 실패/commit 후 응답 유실에서 part/예산/activation 유일성과 checkpoint cut을 검증했다. 새 key의 기존 activation 회수, 바뀐 mandate/visit 거부, 역할 회수 후 cached 결과 접근 거부를 포함한다.
- 실제 TLS 시험에서 simulation operator/qualification/Host Arm fixture로 시작한 후 원격 E가 part와 activation을 하나씩 만들고 GetRun에서 확인했다. 이 시험은 Work/native device를 생성·호출하지 않는다.
- 다음 Submit wire 연결에 필요한 ADMITTED Receipt 근거도 추가했다. 신규 Work의 실제 control record INSERT seq와 journal identity를 같은 T1에 저장한다. P boot와 store generation을 구별하고, 이후 Hold에도 원래 접수 확인서를 유지한다.
- 과거 Work에 원래 접수 위치가 없으면 현재 head로 꾸미지 않는다. 새 native 호출의 이유로 쓰지 않고 CONTINUITY_UNPROVEN으로 남긴다.
- P 일반115개·clippy, 별도 작업/자동 dispatcher/Host publisher E2E3개가 통과했다. 확정 규범8개를 유지했다. S 일반28개·실제 BT는 이전 범위의 증거이며 이번에 반복 실행했다고 표시하지 않는다.

[실행기 요청](../../rx-platform/crates/rx-application/EXECUTOR_REQUESTS.md), [접수 확인서](../../rx-platform/crates/rx-application/ADMISSION_RECEIPT.md), [검증 기록](../../references/implementation/phase18_checks.json).

다음 필수 연결은 Cell.SubmitOperation의 중첩 context/parent/part/두 CAS와 같은 T1·정확한 Receipt 반환, Operation 조회, branch/wait/CommitCheckpoint, E artifact/C++ Frame·영속 pending key 복원이다. 서비스 liveness, 전체 원장/장기 용량·index, 복구·현장 package·편집기·자사 두 제품 이미지·설치복원/인수도 계속 남아 있다.

## 2026-09-11 · 원격 실행기 유한 제출→자동 Host 전달→결과 조회

- Cell.SubmitOperation의 run mandate 경로를 연결했다. 중첩 CallContext의 session/call/key 일치와 revision 위치, cell/run/activation/part 관계, parent mandate, 두 객체 CAS와 normalized intent를 검증한다.
- 현재 peer/셀 권한 검사 뒤 전체 typed payload/key를 비교한다. cached 결과와 새 slot을 구별하며 기존 slot은 Work/Operation/Permit의 상호 연결과 digest/parent까지 확인한다.
- 유한 작업의 실제 T1 전이는 trusted composition 경로와 공유한다. 새로운 wire 경로에 별도 상태기계/allocator/native 호출을 만들지 않았다.
- 원래 접수 확인서를 반환하며, T1 뒤 receipt 읽기/전송 실패가 commit 취소가 되지 않는다. 같은 key/body로 원래 ADMITTED stage/revision/journal 위치를 회수한다. base Submit은 cell 검사 우회 경로로 활성화하지 않는다.
- Operation.Get을 현재 executor 범위에 연결하고 phase/knowledge/outcome/integrity/disposition/evidence를 독립적으로 표현했다. Work와 Operation의 intent digest 차이는 DATA_LOSS다. UNKNOWN·후발 모순·인계 전 격리 상태를 검증했다.
- core 시험은 잘못된 parent/part/CAS, T1 rollback/응답 유실, 전체 payload 충돌, 다른 key의 기존 slot, Hold 뒤 원래 receipt 회수와 역할 회수를 확인한다. API 시험은 실제 TLS에서 중첩 context/다른 run/part/parent·stale CAS 및 새 call trace ID의 동일 요청 회수를 확인한다.
- 기존 별도 Host 통합에 원격 E client 시나리오를 추가했다. E→P Submit 응답은 T1 뒤, P→H Authorize 응답은 실제 모의 제출 뒤 각각1회 유실한다. 두 part에 Authorize 호출2회·Host effects2회만 남으며, 원래 receipt 회수·P 결과 조회·인계·part/run 완료를 확인한다.
- 더 엄격하게 추가한 시험에서 ‘성공이면 HELD’라는 oracle 가정이 잘못임을 확인했다. 응답 유실로 격리된 자원은 성공 근거 후에도 인계 전까지 QUARANTINED일 수 있다. 계약대로 HELD/QUARANTINED를 허용하고, 인계 전 RELEASED를 거부하도록 시험을 바로잡았다. 최초 실패 로그도 보존한다.
- Domain의 read-only intent digest getter를 S SDK에 수출했고58개 inventory를 유지했다. P 일반117개, S 기본27개+test-harness crash1개, 양쪽 clippy와 별도 E2E4개가 통과했다. frozen 규범8개는 변경하지 않았다. 기존 C++ BT 검증을 이번에 다시 실행했다고 표시하지 않는다.

[유한 작업 제출 명세](../../rx-platform/crates/rx-application/EXECUTOR_SUBMISSION.md), [검증 기록](../../references/implementation/phase19_checks.json).

실제 C++ BT worker/Frame·영속 pending key·artifact 확보·branch/wait/CommitCheckpoint, cancel/recovery/control-session, 서비스 liveness, 원장 전체·장기 용량/index, UI와 자사 두 제품 이미지·설치복원/인수는 미완료다. 새 원격 client는 test-only이며 operator 시작/초기 모의 근거·인계/part 완료는 명시적 composition 경로다. 물리 로봇·PLC 운전 또는 현장 qualification 완료를 의미하지 않는다.

## 2026-09-11 · P 현재 상태→S 복원 client→실제 C++ Frame

- Run/Purpose/상태/ProcessCheckpoint/WaitWindow와 checkpoint/activation/slot DTO를 shared rx-process-contract로 옮겼다. 원래 checkpoint v1의 필드/정규화 표현을 유지하며 P Engine은 S SDK에 넣지 않았다.
- 현재 execution snapshot을 실제 P read transaction/control cut에 연결했다. 현재 cell revision/epoch/scopes, run/checkpoint, work/branch/wait, P 시각/만료와 요청 허용 여부/이유를 함께 읽는다. 단순 조회 실패를 허용 false로 숨기지 않는다.
- maintained condition이 새 보고 없이 age 한계를 넘는 경우를 확인하고, active_run에서 실제 처리 시점에 재평가하도록 고쳤다. 현재 read가 false인 것과 과거 Run=EXECUTING 기록은 구별한다.
- 선택적 rx.executor.v1 GetSnapshot/GetArtifact와 별도 source-pinned read binding을 추가했다. 기존 base/cell 필수 협상과 mutation은 유지하며, caller는 추가 binding hash도 맞아야 한다. GetArtifact는 run-owned checkpoint 또는 정확한 resolved process만 읽는다.
- S에 rx-executor client를 만들었다. P session/셀 협상, payload hash/size/schema, runtime/순서/시계·공정/작업 연결을 검증한다. epoch/session/digest를 기존 Context에 자동 채택하지 않는다.
- trusted same-host Clock port와 Linux CLOCK_BOOTTIME/kernel boot ID adapter를 추가했다. source absolute expiry와 local request-send bound를 함께 적용한다. C++ Frame에도 source clock을 넣고 publish/tick/handoff에서 검사한다.
- C++ strict IPC decoder와 source-clock 시험을 추가했다. duplicate/extra JSON key, 숫자/overflow uint64, 중복 node, clock 부재/변경/만료를 거부한다. 아직 넘기지 않은 request는 만료 중 queue에 유지하고 새 유효 frame에서 한 번 전달한다.
- 별도 S test-harness reader를 새 boot로 실행해 실제 mTLS로 checkpoint/live snapshot/resolved를 회수했다. 기존 작업 ID는 보존되며 Run은 RECOVERY_REQUIRED이고 새 admission은 false다. 이 데이터로 만든 Frame을 실제 Linux BT.CPP에서 읽어 작업 재발행/미실행 작업의 성공 처리가 없음을 확인했다.
- P 일반118개·S32개, 별도 E2E5개와 기존/추가 C++ BT 시나리오가 통과했다. macOS에서 Linux cross-check는 C cross compiler 부재로 끝났고, Linux용 고정 Rust1.98.1 toolchain을 기존 검증 이미지에서 native/offline으로 실행해 client5개 시험(실제 boottime 포함)을 통과했다. 교차 검사 실패와 native 대체 근거를 구별해 보존한다.
- 선택적 Docker Rust 이미지 metadata 조회는 응답 없이 장시간 유지되어 해당 작업만 중지했다. 새 이미지를 추정해 사용하지 않았고, 기존 검증 image와 공식 고정 Linux toolchain을 사용했다. 확정 규범8개는 유지한다.

[현재 실행 상태와 Frame 명세](../../rx-platform/crates/rx-application/EXECUTION_READ.md), [S client](../../rx-solutions/runtime/rx-executor/README.md), [검증 기록](../../references/implementation/phase20_checks.json).

실제 운영 BT daemon/요청 worker·영속 pending key, branch/wait/Workflow.CommitCheckpoint·복구/취소/control-session, supervisor liveness, 장기 용량/index/전체 원장, UI·자사 두 제품 image·설치복원/인수는 남아 있다. 선택적 읽기 binding과 fixture client를 그 기능의 대체 완료로 취급하지 않는다. 시계/단말/qualification/장비 입력은 simulation fixture이며 실물 운전 검증이 아니다.

## 2026-09-11 · S 요청 journal과 실제 C++ 유한 작업 worker

- S 전용 journal을 installation/store generation/principal/release/cell definition/run/recipe에 고정했다. logical visit/node/stage의 current pointer와 불변 attempt generation을 분리하고 이전 key/body를 보존한다.
- prepare·enter를 실제 SQLite에 commit한 뒤에만 network client를 호출한다. 응답 유실/프로세스 종료의 EMIT_ENTERED를 Prepared로 되돌리거나 임의 새 key로 바꾸지 않는다. P atomic Resolve/Submit의 ABORTED가 확인된 경우에만 같은 의미의 새 CAS/key를 허용한다. detail 문자열을 machine 판정으로 읽지 않는다.
- local RPC reply와 P projection 관측을 분리했다. 새 snapshot에서 기존 작업이 보여도 없던 응답을 만들지 않는다. mapping/intent identity 변화는 거부하고 unchanged observation을 매 tick 기록하지 않는다.
- 실제 C++ request의 context/node/kind/argument/timeout을 P의 validated process에 대조하는 worker를 만들었다. 유한 operation에 ResolveActivation→새 snapshot→SubmitOperation을 실행하고, 각 RPC의 전체 body와 key를 선행 기록한다.
- 이미 P에 있는 작업은 그 ID를 확인해 사용한다. 알려진 응답의 mapping이 완전한 P snapshot에서 사라지거나 context가 바뀌면 조정 대상으로 남긴다. 나머지 BT request 종류는 Unsupported이며 성공으로 위장하지 않는다.
- C++ validation-only request producer를 추가했다. test harness 옵션을 켠 빌드에서만 만들고, S fixture는 고정된 local image digest를 network none/read-only/cap-drop/pull never로 실행한다.
- 실제 C++ request→별도 S worker→P mTLS/SQLite 시험에서 정상 처리, Submit 진입 직후 종료, P Submit 응답 뒤 local 저장 전 종료, Resolve/Submit 응답의 commit 후 유실을 각각 확인했다. 다섯 시나리오 모두 같은 key와 작업 수를 보존했고 새 boot recovery에서 무허가 재발행이 없었다.
- local rollback/commit 응답 유실·재개방·key 변경 제한·observed/received 구분·store generation 거부 시험도 통과했다. 이 통합은 P admission까지이며 기존 별도 Host 시험이 P→H/native/인계를 검증한다. 전체 운영 daemon이나 연속 복구 완료로 확대하지 않는다.

[S journal/worker 명세](../../rx-solutions/runtime/rx-executor/JOURNAL_AND_WORKER.md), [검증 기록](../../references/implementation/phase21_checks.json).

아직 part coordinator/상주 BT loop, branch/wait/개입·인계·pause 요청 worker, CommitCheckpoint/명시적 restart/clearance/control-session, liveness·전체 원장/장기 용량/index, UI·두 제품 image·자사 native stack·설치복원/인수는 미완료다. Goal과 요구 추적표 범위를 유지한다.

## 2026-09-11 · 실제 BT halt→영속 PauseRun→허가 철회

- Workflow.PauseRun을 현재 executor session/definition/run CAS와 전체 요청 key에 연결했다. origin Run은 PAUSED이며, 이미 제한/완료된 상태를 더 약한 상태로 바꾸지 않는다.
- current Host authority가 cell epoch/scope에 묶이므로 실행/Arm 중인 run은 관련 closure의 epoch/block/mandate/permit/fence를 함께 처리한다. 준비 허가 없는 PREPARED run은 자체 상태만 바꾼다. budget/part/operation identity는 보존한다.
- 새로운 Finalized view는 capture 후 같은 transaction에서 projection을 읽고 요청 결과를 저장하되 core mutation을 노출하지 않는다. 응답 유실 뒤에도 원래 최종 RunSnapshot을 회수하며 origin revision을 중복 증가시키지 않는다.
- NEW operation 전송은 봉인하고 증명 가능한 미발행만 NOT_EXECUTED로 기록한다. EmitEntered를 취소 완료로 만들지 않는다. late PREPARED의 새 Authorize 생성과 late Arm의 자동 시작을 거부하고, 실제 후속 상관 결과는 계속 기록한다.
- S journal에 optional session/epoch control identity와 PauseRun body/완전한 RunView 응답을 추가했다. 기존 operation key의 canonical encoding은 유지한다. 새 context의 명시적 halt를 이전 pause key와 구별한다.
- 실제 C++ halt request→S worker→P mTLS PauseRun, pause 응답 유실, 새 boot recovery에서 key/미수신 상태 보존을 검증했다. worker 통합은 기존5개에 pause2개를 더한7개 시나리오다.
- core의5개 추가 시나리오가 pause rollback/응답 유실·shared closure·예산/원래 응답 보존·pending Arm·late receipt/result·준비 run 범위를 확인한다. S control identity 회귀 시험도 추가했다.

[PauseRun 명세](../../rx-platform/crates/rx-application/EXECUTOR_PAUSE.md), [검증 기록](../../references/implementation/phase22_checks.json).

Pause는 물리 정지/취소/안전 접근/인계 확인이 아니다. 전체 restart/clearance·분기/대기/개입·handover/control-session, 상주 loop/part coordinator/liveness, 원장 전체·장기 용량/index, UI·두 제품 image·자사 stack·설치복원/인수는 여전히 남아 있다.

## 2026-09-11 · 영속 조회 계획과 실제 BT 인계 요청

- Operation.Reconcile을 현재 Executor 권한·셀 협상과 P 영속 조회 계획에 연결했다. 진행 중 계획은 operation별 병합, 후속 명시적 조회는 새 ID/generation으로 구별한다. 계획 완료에는 실제 RELEASED 저장이 필요하다.
- Host dispatcher는 기존 receipt/evidence를 읽어 원래 처리기와 T2에 적용하고 세 인계 관측을 확인한다. 생산 invocation을 새로 만들지 않는다. 일시적 조회 실패와 권한·기록 충돌을 구별했다.
- false/불충분 관측도 별도 transaction에 원문 보존한다. 동일 관측 ID의 내용 충돌은 덮어쓰지 않고 제한·사건을 commit한다. 실제 resource release는 기존 freshness/상관관계/epoch/CAS 조건을 전부 통과해야 한다.
- S의 ReconcileOperation 요청 journal·client·RequestHandover worker를 연결했다. 접수 응답과 RELEASED 관측을 분리하고, 응답 유실 및 새 boot 복원에서도 원래 key/PENDING을 유지한다. CAS 없는 조회를 ABORTED로 재작성하지 않는다.
- 실제 Linux C++ BT 요청→별도 S worker→P mTLS의 정상 인계와 조회 응답 유실 2시나리오를 추가했다. 총 9시나리오에서 원래 작업 수/요청 key·응답 상태/해제 관측을 확인했다. Host 근거는 합성 fixture이며 별도 모의 Host 통합에서 처음 support=false를 거부하고 후속 인계 근거로 두 소재를 처리했다. native effect는 2회다.
- 최초 추가 통합은 증거 출력 상대 경로 처리와 시험용 EnsureState 완료 조건 누락 때문에 각각 실패했다. 출력 경로를 절대화하고 해당 시험을 명시적 모의 유한 프로그램으로 구성했다. 제품의 완료 조건 검사는 완화하지 않았다. 실패 로그도 보존했다.

[조회·인계 명세](../../rx-platform/crates/rx-application/RECONCILIATION.md), [검증 기록](../../references/implementation/phase23_checks.json).

P 일반126개, S37개, Linux executor10개 및 별도 E2E6개가 통과했다. 기존 C++ 검증 이미지를 사용했고 이번 C++ 소스는 변경하지 않았다. 규범8개와 선택적 read binding을 유지한다.

전체 운영 완료는 아니다. 조회 스케줄링과 원장 index/용량, ATTENTION 상세 UI, 상주 loop/part coordinator, branch/wait/개입/CommitCheckpoint·취소/복구/control-session, 자사 stack·두 제품 이미지·설치복원/인수는 계속 남아 있다. 실물 qualification은 수행하지 않았다.

## 2026-09-11 · P 분기·대기 후보와 frozen CommitCheckpoint

- 선택적 ExecutorPlan.PrepareCheckpoint를 추가했다. P가 현재 조건·frontier·시각으로 전체 rx.executor-state.v1 후보를 만들고, 기존 Workflow.CommitCheckpoint가 이를 확정한다. 상태 artifact를 명령 봉투로 바꾸지 않았고 임의 artifact 업로드를 허용하지 않는다.
- 후보 준비는 Run revision·공정 결정·작업을 바꾸지 않는다. 준비 기록/내용 주소 artifact만 보존한다. 유효한 반복 준비는 같은 후보로 병합하며 조건 UNKNOWN은 WAITING, 이미 확정된 전이는 ALREADY_APPLIED다.
- 확정은 현재 접근권→전체 key/body→run CAS·후보 session/boot/epoch/만료→현재 운전 적격성→현재 사실로 재계산 순서다. 후보와 실제 저장된 전체 상태·activation/slot을 비교하고 T3·최종 artifact·원래 응답을 같은 commit에 보존한다.
- 분기·대기 판단을 process_transition.rs로 모았다. 기존 내부 경로와 새 통신 경로가 같은 상태 전이 및 checkpoint 저장을 사용한다. 대기는 원래 P 준비 시각을 확정하며 재요청으로 deadline을 늘리지 않는다. 성공 후보가 deadline 이후 도착하면 timeout을 다시 준비해야 한다.
- core는 준비/확정 rollback·응답 유실·만료, 현재 권한, 후보/mapping 변조, 바뀐 관측, deadline 경계, 앞선 visit의 실제 자식 슬롯 보존을 검증했다. 실제 mTLS의 분기/대기 2시험은 준비 비적용·frozen CommitCheckpoint·응답 유실 후 동일 결과·artifact 조회를 확인한다.
- 두 확정 규범의8개 파일과 기존 executor-read binding은 유지했다. 준비용 binding은 별도 고정했고 SDK67개 파일과 wire semantic fields604개로 수출했다. P 일반133개·S37개, Linux executor10개, 양쪽 clippy와 별도 E2E6개가 통과했다. 기존 S worker의9개 시나리오를 회귀 검증했으며, 분기/대기 S worker까지 검증했다고 확대하지 않는다.

[후보 준비·체크포인트 확정](../../rx-platform/crates/rx-application/CHECKPOINT_COMMIT.md), [검증 기록](../../references/implementation/phase24_checks.json).

다음 연결은 S Client의 준비 응답/후보 검증, 분기·대기 단계별 journal, 동일 key의 CommitCheckpoint, 응답 유실 후 P 결정/window/result의 별도 관측이다. EXPIRED·확인된 CAS 거부와 transport 미확정을 구별하는 machine-readable 재준비 처리도 함께 필요하다. 상세 ErrorDetail의 통신 처리는 아직 전체 구현으로 표시하지 않는다. 상주 loop/part coordinator·개입/복구/control-session, 후보 보존 정책·원장 index/용량, UI·자사 stack·두 제품 이미지·설치복원/인수는 계속 남아 있다.

## 2026-09-11 · S 분기·대기 worker와 확정 거부·관측 복원

- 실제 BT ResolveBranch/BeginWait를 S의 CHECKPOINT_BRANCH/START_WAIT/CHECK_WAIT journal 단계에 연결했다. P의 준비 결과와 두 artifact를 검증하고 전체 상태·기존 작업 연결이 보존된 후보만 frozen CommitCheckpoint로 보낸다.
- 대기 window 존재 여부로 시작과 결과 확인을 나눴다. 반복 WAITING은 mutation attempt를 만들지 않는다. 상태는 P가 결정하며 S는 현재 확정된 branch/window/result를 각각 관측한다.
- CommitCheckpoint의 확인된 atomic 거부에 한해 strict ErrorDetail binary metadata를 추가했다. bare status/문구·중복·malformed metadata·transport 실패는 새 key의 근거가 아니다. 정확한 만료/충돌 거부 뒤에만 새 P 상태/후보와 다음 generation을 만든다. 다른 RPC의 실패로 일반화하지 않는다.
- journal은 원래 attempt의 body/key/거부 이유 또는 PENDING을 보존한다. 다른 후보가 먼저 확정된 경우 P 결정을 관측할 수 있지만 우리 RPC 응답으로 만들지 않는다. 이미 관측한 결정과 모순된 늦은 응답도 거부한다.
- 실제 Linux C++ BT→별도 S→P mTLS/SQLite 시험에 참·거짓 분기, 대기 성공/반복 대기/timeout, checkpoint 응답 유실, 진입/응답 직후 프로세스 종료, 실제 P 시계의 후보 만료를 추가했다. 총18개 시나리오에서 새 boot 복원·원래 key/응답 상태·P 결정/작업 수를 검증했다. 만료 사례는 generation1의 EXPIRED 기록과 generation2의 다른 key/정상 응답을 함께 보존한다.
- P134개·S38개, Linux executor11개, 양쪽 clippy와 별도 E2E6개가 통과했다. 규범8개·기존 read binding·base/cell protobuf는 유지했다. 선택적 preparation binding은 구조화된 거부와 공통 decision DTO를 포함하도록 갱신했고 SDK68개 파일을 수출했다.

[실행기 분기·대기와 복원](../../rx-solutions/runtime/rx-executor/DECISIONS_AND_RECOVERY.md), [검증 기록](../../references/implementation/phase25_checks.json).

전체 상주 loop/supervision·part coordinator, 개입/clearance/취소·명시적 restart와 continuous-control, 장기 journal/index·후보 보존/용량, 전체 ErrorDetail·UI, 자사 stack·두 제품 이미지·설치복원/인수는 남아 있다. 새 시나리오는 operator/part 시작·조건/시계를 모의 구성하고 P admission/공정 상태를 검증한다. 실제 native 결과/인계는 별도 모의 Host 시험 범위이며 실물 qualification은 수행하지 않았다.

## 2026-09-11 · 지속 BT 프로세스·private pipe·pending queue

- 생산용 C++ rx-bt-engine을 추가했다. INITIALIZE는 tree만 구성하며 무동작이다. 명시적 STEP에서만 같은 context의 상태를 읽고 요청을 제안한다. malformed/다른 context/무결성 오류는 엔진을 재사용하지 못하게 하고, 같은 context의 만료 frame은 STALE로 무시한다. HALT 뒤 STEP과 시계 override를 금지한다.
- Rust EngineProcess는 release binary SHA-256·경로/크기를 확인하고 환경/현장 argv 없이 실행한다. bounded private-pipe protocol, sequence/응답/state/context 검사, I/O deadline과 실패 latch를 갖는다. 전체 service supervisor나 native Host 종료를 대신하지 않는다.
- PendingRequests가 최대32 일반 제안과 우선 pause를 관리한다. BT는 BeginWait를 한 번만 내고 Rust가 시작 이후 결과까지 요청을 유지한다. 같은 요청의 의미 변경·잘못 연결된 완료를 거부하고, transient backoff와 공정한 대기 순서를 사용한다. mutation의 durable key/미확정 상태는 기존 journal에 남는다.
- C++는 확정 wait 결과의 변경을 막고, P가 이미 해결한 미전달 제안을 내부 큐에서 제거한다. 기존 내부 BT 시험과 생성5단계 예제도 새 binary로 검증했다.
- 기존18개 통합 중 분기/대기9개를 지속 엔진+queue로 전환했다. 같은 자식 PID, BeginWait 제안1회, 반복 대기/결과 처리, 응답 유실·만료/재시작 보존과 정상 fixture 종료의 P pause 관측을 검증했다. 별도IPC9개는 malformed/중복/잘림/크기/시간/context/immutable wait 및 생산용 시계 보호를 확인한다.
- Linux 실시간 시계 검사에서는 실제 production binary digest 검증·반복 pipe 처리·동일PID·무권한 view의 요청 없음·CLOSE를 확인했다. 입력은 합성 복원 상태다. 그 상태의 NOT_EXECUTED를 RUNNING으로 예상한 최초 시험 오류를 BT FAILURE로 정확히 수정했으며 제품 동작은 완화하지 않았다.
- 초기 IPC 시계 시험에서 재사용한 fixture 파일의 잘린 JSON을 관측했다. 사례별 독립 파일로 바꾼 뒤 통과했고, 최초 오류/FAULT 응답도 보존했다. 미관측 wait 노드가 frame.nodes에 없을 수 있는 점도 시험 입력에 반영했다.
- Tokio process/I/O 기능을 활성화하고 rx-process를 runtime 필수 의존성으로 옮겼다. offline lock 갱신은 signal-hook-registry1.4.8을 추가했으며 기존 package 버전은 변경하지 않았다. P gRPC connect/RPC에 2초 제한을 추가하고 timeout을 미적용 증거로 해석하지 않는다.

[지속 BT 엔진 명세](../../rx-solutions/native/executor/PERSISTENT_ENGINE.md), [검증 기록](../../references/implementation/phase26_checks.json).

P134개·S40개·양쪽 clippy, 별도E2E6개, Linux14개(명시적으로 활성화한 production binary 검사 포함), C++/IPC 시험이 통과했다. 규범8개와 두 optional binding은 유지했다. 새 image는 validation image다. 전체 daemon/signal/durable stop intent·part coordinator, intervention/recovery/control-session, 원장 index/용량·전체 UI·자사 stack·두 제품 이미지·설치복원/인수는 여전히 미완료다.

## 2026-09-11 · Run/visit 실행 서비스와 durable stop intent

- Linux rx-executor-service와 공통 RunService를 추가했다. P 배정/part 대기, 현재 view·지속 planner·pending queue 조정, 통신 grace·중단 window와 SIGINT/SIGTERM 연결을 제공한다. 소프트웨어 시작 시 P admission이나 part를 만들지 않는다.
- 중단 의도를 BT 단계 요청과 분리한 run-scoped journal에 먼저 보존한다. 실행 전 root/part가 없어도 중단할 수 있다. 시도별 key/session/expected revision은 고정하고, 응답 유실 뒤에는 원래 ENTERED와 응답 부재를 유지한다. P 제한 상태의 관측을 RPC 응답으로 꾸미지 않는다.
- 정상 요청을 동결한 뒤 planner만 닫고 P pause를 확인한다. 미응답은 Pending으로 남긴다. restart는 stop intent를 먼저 처리하며 BT를 띄우거나 기록을 지우지 않는다. 다른 executor/실행 세대에 오래된 중단 의도를 자동 적용하지 않는다.
- 로컬 journal 실패 시 planner를 동결하고 안정된 메모리 key/body로 P pause를 시도한다. 결과에 durability_fault를 남기며, 이를 durable stop 보존으로 주장하지 않는다. run 제어 조회는 실제 checkpoint artifact의 cell/recipe/state/연결도 검사한다.
- 실제 서비스 loop·별도 S·지속 C++·P mTLS/SQLite 통합6개를 추가했다: 실행 중/배정 전 중단, pause 응답 유실, 의도 commit 직후 종료, journal 장애, P pause 미응답. 전체24개에서 원래 기록·재시작 BT 기동0회·작업 수·미수신 응답을 검증했다.
- P134개·S42개, Linux16개(production planner 검사와 Linux service binary compile 포함), 양쪽 clippy·별도E2E6개가 통과했다. 규범8개·두 optional binding·SDK68개는 유지했다.

[실행 서비스와 중단 기록](../../rx-solutions/runtime/rx-executor/SERVICE_LIFECYCLE.md), [검증 기록](../../references/implementation/phase27_checks.json).

이는 지정한 run/visit 서비스다. GraphComplete가 P part/run 완료를 뜻하지 않으며 part coordinator·같은 run의 명시적 restart/rebind는 후속이다. 전체 P/Host/S supervisor·실제 CLI signal-to-P 통합·장비 종료, intervention/clearance/cancel/control-session, 긴 원장/index·전체 UI·자사 stack·두 제품 이미지·설치복원/인수도 남아 있다. 시연 장비의 실물 qualification은 수행하지 않았다.

## 2026-09-11 · 직렬 소재 admission·완료·다음 context

- Production.Inspect/CompletePart를 별도 optional binding으로 추가했다. 첫 part 이전부터 종료 이후까지 part ID/ordinal/revision/disposition, budget·Run checkpoint·권한/epoch·시각을 같은 P control cut에서 읽는다. base/cell 및 기존 optional read/prepare binding은 유지한다.
- P completion을 공통 transition으로 정리했다. 실제 선택된 graph 결과·인계 근거를 확인한 뒤 part와 run/mandate·사건·응답을 원자적으로 갱신한다. 이미 완료한 part의 재요청은 새 revision/예산 소비를 만들지 않는다. 전체 body/key·현재 접근권·run/part CAS를 검사한다.
- S는 BEGIN_PART/COMPLETE_PART journal과 별도 part 관측을 추가했다. 원래 미수신 응답을 만들지 않고 P의 기존 part ID를 회수한다. 같은 revision의 다른 값과 모순된 늦은 part reply를 거부한다.
- 서비스의 기본 SerialProduction이 최초·다음 part를 조정한다. P 완료가 검증된 CompletedVisit으로만 planner를 retire하고, CLOSE의 run-pause 제안을 전달하지 않는다. 이전 context는 보존해 다음 part에서 새로운 session/epoch를 자동 채택하지 않는다. ManualVisit은 별도 옵션으로 유지한다.
- 두 소재를 처리하는 정상/첫 Begin 응답 유실/첫 Complete 응답 유실 3통합을 추가했다. P part2개·budget 소비2회·work2개·planner2회, 중간 pause 없음, 최종 P run 완료와 재시작 추가planner0회를 확인했다. Host 완료/인계는 명시적 합성 근거이며 실제 모의 Host 전송은 별도 기존 시험이다.
- P136개·S43개, Linux17개, 양쪽 clippy·별도E2E6개가 통과했다. worker 통합은 총27시나리오다. 규범8개는 유지하고 SDK72개와 wire semantic fields614개를 수출했다.

[직렬 소재 조정](../../rx-solutions/runtime/rx-executor/PRODUCTION_COORDINATOR.md), [검증 기록](../../references/implementation/phase28_checks.json).

남은 것은 병렬 소재/실물 genealogy, 명시적 restart/rebind, intervention/clearance/cancel/control-session, 큰 run의 index/paging/용량, 전체 supervisor·UI·자사 stack·두 제품 이미지·설치복원/인수다. 실물 qualification을 수행한 것으로 표시하지 않는다.

## 2026-09-11 · 개입 사건 접수·보류·알림 확인 UI

- P Case/Open/Get/List와 notification ACK를 구현했다. 진단 사건은 non-latched block으로 새 admission을 보류하고 epoch/ACTIVE mandate를 유지한다. 접근·복구·정비·변경 사건은 기존 closure invalidation과 같은 transaction으로 허가를 철회하고 case/block membership을 보존한다.
- 현재 actor·lead 역할/영향 셀, 실제 operation 참조, 전체 key/body와 case CAS를 확인한다. 알 수 없는 scope/소재 참조는 불명 표시와 cell/resource closure로 보존하며 확인된 MaterialState로 만들지 않는다.
- ACK는 실제 계정·보고 UTC·P 기록 시각과 typed notification assertion artifact를 보존한다. case 상태·참여자·epoch/block·운전/접근/reset/restart를 바꾸지 않는다. 중복 key는 확인 기록을 늘리지 않고 다른 case의 제한도 제거하지 않는다.
- frozen executor Cell.OpenCase/GetCase와 개발 HTTP/운영 화면의 사건 목록·ACK를 연결했다. UI는 ‘알림 확인과 작업 허가는 별도’임을 표시하고 참여 기록 없음과 사람 없음도 구별한다. 생성 catalog/UI와 실제 ProcedureRecord/clearance/restart는 아직 연결하지 않는다.
- core2개와 HTTP1개 시험을 추가하고 실제 mTLS 사건 조회를 기존 API 시험에 포함했다. 브라우저는 commit 뒤 ACK 응답을 잃고 reload한 다음 같은 body/key로 회수했다. record1개·CONTAINMENT_PENDING·동일 epoch/block을 확인했고 desktop/mobile·JavaScript 오류를 검사했다. 화면을 직접 확인했다.
- P139개·S43개·양쪽 clippy, UI3개/build/format·브라우저, 별도E2E6개(실행기27시나리오)가 통과했다. time0.3.55의 parsing 기능을 직접 사용했으며 기존 package 버전은 바꾸지 않았다. 규범8개·세 optional binding·SDK72개는 유지한다.

[개입 사건과 알림 확인](../../rx-platform/crates/rx-application/INTERVENTION_CASES.md), [검증 기록](../../references/implementation/phase29_checks.json), [운영 화면](../../references/implementation/phase29-browser-final/operator-cases.png).

완성된 개입/복구 절차가 아니다. typed 외부 절차 근거와 stale-CAS 사실 보존, 절차 진입/참여자·인수, recovery plan/step slot, clearance cohort·restart/비운전 종료, 전체 원장/보존, 생성 catalog/UI·제품 supervisor·자사 stack/두 이미지/설치복원·인수는 후속이다. 실장비나 물리 접근 시험은 수행하지 않았다.
