# 규범 원본 보존

두 v1.0 폴더는 RX 설계 작업 공간에서 복사한 기준판이다. 본문과 protocol manifest는 수정하지 않는다. 원문 상대 링크에는 원래 설계 작업 공간의 구조가 남아 있다.

구현 결정과 진행 기록은 workspace의 docs/implementation을 따른다. 이 보존본의 hash 일치만으로 구현 적합성이 증명되지는 않는다.

검사: python3 tools/check_contract_baselines.py
