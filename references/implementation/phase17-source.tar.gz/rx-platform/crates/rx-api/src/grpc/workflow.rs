use super::*;
#[tonic::async_trait]
impl base::workflow_service_server::WorkflowService for PlatformIngress {
    async fn get_run(
        &self,
        request: Request<base::RunRequest>,
    ) -> Result<Response<base::RunView>, Status> {
        let identity = self
            .validated_executor_identity(&request, request.get_ref().context.as_ref())
            .await?;
        let value = request.into_inner();
        if !value.recipe_digest.is_empty() || !value.site_config_digest.is_empty() {
            return Err(Status::invalid_argument(
                "GetRun does not accept creation digests",
            ));
        }
        let run = id(value
            .run_id
            .as_deref()
            .ok_or_else(|| Status::invalid_argument("run_id required"))?)?;
        let Reply::RunCheckpoint(snapshot) = self
            .call(Command::ExecutorRunCheckpoint { identity, run })
            .await?
        else {
            return Err(Status::internal("run checkpoint reply"));
        };
        let view = rx_protocol_adapter::workflow::run_view(&snapshot);
        // Validate the release's exact representation before returning it over the network.
        rx_protocol::json::to_value(&view)?;
        Ok(Response::new(view))
    }
    async fn create_run(
        &self,
        _: Request<base::RunRequest>,
    ) -> Result<Response<base::RunView>, Status> {
        Err(Status::unimplemented(
            "Workflow mutation binding is not enabled",
        ))
    }
    async fn start_run(
        &self,
        _: Request<base::RunRequest>,
    ) -> Result<Response<base::RunView>, Status> {
        Err(Status::unimplemented(
            "cell start requires the cell authorization contract",
        ))
    }
    async fn pause_run(
        &self,
        _: Request<base::RunRequest>,
    ) -> Result<Response<base::RunView>, Status> {
        Err(Status::unimplemented(
            "Workflow mutation binding is not enabled",
        ))
    }
    async fn abandon_run(
        &self,
        _: Request<base::RunRequest>,
    ) -> Result<Response<base::RunView>, Status> {
        Err(Status::unimplemented(
            "Workflow mutation binding is not enabled",
        ))
    }
    async fn resolve_activation(
        &self,
        _: Request<base::ResolveActivation>,
    ) -> Result<Response<base::ActivationView>, Status> {
        Err(Status::unimplemented(
            "Workflow mutation binding is not enabled",
        ))
    }
    async fn commit_checkpoint(
        &self,
        _: Request<base::ChangeCheckpoint>,
    ) -> Result<Response<base::RunView>, Status> {
        Err(Status::unimplemented(
            "Workflow mutation binding is not enabled",
        ))
    }
}
