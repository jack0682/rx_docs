//! ROBOTIS ROS action adapter. Physical authority must come from a separate release-owned provider.
mod adapter;
mod journal;
pub mod process;
mod profile;
pub use adapter::{Boundary, Jtc, NoBoundary};
pub use journal::{Entry, Identity};
pub use profile::{Authority, AuthoritySnapshot, Profile, TrajectoryAsset, UnavailableAuthority};
pub mod protocol;
