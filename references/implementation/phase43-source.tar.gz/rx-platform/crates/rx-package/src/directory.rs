//! Capability-rooted, bounded acquisition. VerifiedPackage owns the bytes, not source paths.
use crate::{Error, PackagePath, Result, VerificationPolicy, VerifiedPackage, verify_package};
use cap_fs_ext::{DirExt, FollowSymlinks, OpenOptionsFollowExt};
use cap_std::fs::{Dir, OpenOptions};
use std::{collections::BTreeMap, io::Read, path::Path};

pub fn verify_directory(path: &Path, policy: &VerificationPolicy) -> Result<VerifiedPackage> {
    let mut files = acquire_directory(path, policy.max_files, policy.max_content_bytes)?;
    let manifest = files
        .remove(&PackagePath::new("manifest.json").expect("constant path"))
        .ok_or_else(|| Error::Invalid("manifest.json missing".into()))?;
    let signature = files
        .remove(&PackagePath::new("manifest.sig.json").expect("constant path"))
        .ok_or_else(|| Error::Invalid("manifest.sig.json missing".into()))?;
    verify_package(&manifest, &signature, files, policy)
}
/// Owned but UNVERIFIED directory bytes, for candidate/signature tooling.
/// This does not construct VerifiedPackage or grant trust.
#[derive(Clone, Copy)]
struct Limits {
    max_files: usize,
    max_content_bytes: u64,
}
pub fn acquire_directory(
    path: &Path,
    max_files: usize,
    max_content_bytes: u64,
) -> Result<BTreeMap<PackagePath, Vec<u8>>> {
    if max_files == 0 || max_files > 4096 {
        return Err(Error::Invalid("acquisition file limit".into()));
    }
    let root = Dir::open_ambient_dir(path, cap_std::ambient_authority()).map_err(io_error)?;
    let mut files = BTreeMap::new();
    let mut total = 0;
    let mut count = 0;
    read_tree(
        &root,
        "",
        Limits {
            max_files,
            max_content_bytes,
        },
        &mut files,
        &mut total,
        &mut count,
        0,
    )?;
    Ok(files)
}
fn read_tree(
    dir: &Dir,
    prefix: &str,
    limits: Limits,
    files: &mut BTreeMap<PackagePath, Vec<u8>>,
    total: &mut u64,
    count: &mut usize,
    depth: usize,
) -> Result<()> {
    if depth > 24 {
        return Err(Error::Invalid("package directory depth".into()));
    }
    for entry in dir.entries().map_err(io_error)? {
        *count += 1;
        if *count > limits.max_files.saturating_mul(4).saturating_add(2) {
            return Err(Error::Invalid("directory entry limit".into()));
        }
        let entry = entry.map_err(io_error)?;
        let component = entry
            .file_name()
            .into_string()
            .map_err(|_| Error::Invalid("non-UTF8 filename".into()))?;
        let relative = if prefix.is_empty() {
            component.clone()
        } else {
            format!("{prefix}/{component}")
        };
        let path = PackagePath::new(relative.clone()).map_err(Error::Invalid)?;
        let kind = dir
            .symlink_metadata(&component)
            .map_err(io_error)?
            .file_type();
        if kind.is_symlink() {
            return Err(Error::Content(
                "symbolic links are not package files".into(),
            ));
        }
        if kind.is_dir() {
            let child = dir.open_dir_nofollow(&component).map_err(io_error)?;
            read_tree(&child, &relative, limits, files, total, count, depth + 1)?;
        } else if kind.is_file() {
            let remaining = limits
                .max_content_bytes
                .saturating_add(2 * 1024 * 1024)
                .saturating_sub(*total);
            let mut options = OpenOptions::new();
            options.read(true).follow(FollowSymlinks::No);
            #[cfg(unix)]
            {
                use cap_std::fs::OpenOptionsExt;
                options.custom_flags(rustix::fs::OFlags::NONBLOCK.bits() as i32);
            }
            let file = dir.open_with(&component, &options).map_err(io_error)?;
            if !file.metadata().map_err(io_error)?.is_file() {
                return Err(Error::Content("regular file required".into()));
            }
            let mut bytes = Vec::new();
            file.take(remaining.saturating_add(1))
                .read_to_end(&mut bytes)
                .map_err(io_error)?;
            if bytes.len() as u64 > remaining {
                return Err(Error::Invalid("acquisition size limit".into()));
            }
            *total += bytes.len() as u64;
            if files.insert(path, bytes).is_some() {
                return Err(Error::Content("duplicate acquired path".into()));
            }
        } else {
            return Err(Error::Content("regular package file required".into()));
        }
    }
    Ok(())
}
fn io_error(_: std::io::Error) -> Error {
    Error::Content("package directory could not be acquired".into())
}
