//! Bounded simulation-only BT/decision worker. Never a production launcher.
use rx_domain::{canonical, types::*};
use rx_executor::{
    Client, Error, PeerPin, TlsEndpoint,
    clock::Clock,
    frame::Request,
    journal::{Journal, Logical, Scope, Stage},
    worker::{Outcome, TestPoint, Worker},
};
use rx_storage::SqliteRepository;
use serde::Deserialize;
use std::{path::PathBuf, sync::Arc, time::Duration};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Config {
    uri: String,
    server_name: String,
    ca: PathBuf,
    certificate: PathBuf,
    key: PathBuf,
    pin: PeerPin,
    run: Id,
    visit: Counter,
    ticks: Counter,
    output: PathBuf,
    journal: PathBuf,
    ready: PathBuf,
    trigger: PathBuf,
    cpp_image: String,
    mode: String,
    scenario: String,
    clock_file: PathBuf,
}
struct SimulationClock(PathBuf);
impl Clock for SimulationClock {
    fn now(&self) -> Result<TimePoint, Error> {
        let bytes = std::fs::read(&self.0).map_err(|e| Error::Invalid(e.to_string()))?;
        let ticks_ns: Counter =
            canonical::decode_json(&bytes).map_err(|e| Error::Invalid(e.to_string()))?;
        Ok(TimePoint {
            clock_id: "test-clock".into(),
            ticks_ns,
        })
    }
}
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config: Config = canonical::decode_json(&std::fs::read(
        std::env::args().nth(1).ok_or("config required")?,
    )?)?;
    if !config.uri.starts_with("https://127.0.0.1:")
        || config.pin.clock_id != "test-clock"
        || config.ticks != Counter(1000)
        || !config.cpp_image.starts_with("sha256:")
        || config.cpp_image.len() != 71
        || !config.cpp_image[7..]
            .bytes()
            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase())
    {
        return Err("explicit pinned loopback simulation only".into());
    }
    let clock = Arc::new(SimulationClock(config.clock_file.clone()));
    let mut client = Client::connect(
        TlsEndpoint {
            uri: config.uri.clone(),
            server_name: config.server_name.clone(),
            ca_pem: std::fs::read(&config.ca)?,
            certificate_pem: std::fs::read(&config.certificate)?,
            private_key_pem: std::fs::read(&config.key)?,
        },
        config.pin.clone(),
        clock.clone(),
    )
    .await?;
    std::fs::write(
        &config.ready,
        serde_json::to_vec(&serde_json::json!({"session":client.session_id()}))?,
    )?;
    if config.mode != "RECOVER" {
        let deadline = tokio::time::Instant::now() + Duration::from_secs(25);
        while !config.trigger.exists() {
            if tokio::time::Instant::now() >= deadline {
                return Err("assignment timeout".into());
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    }
    let initial = client.snapshot(&config.run, config.visit).await?;
    let scope = Scope {
        installation: config.pin.installation.clone(),
        store_generation: config.pin.store_generation.clone(),
        principal: config.pin.principal.clone(),
        release: config.pin.release,
        cell: config.pin.cell.clone(),
        definition: config.pin.definition,
        run: config.run.clone(),
        resolved_digest: initial.data().resolved.sha256,
    };
    let mut worker = Worker::new(
        client,
        Journal::open(SqliteRepository::open(&config.journal)?, scope)?,
    )?;
    std::fs::create_dir(&config.output)?;
    let scenario = config.scenario.clone();
    let output = config.output.clone();
    if config.mode != "RECOVER" {
        worker = worker.with_test_hook(Arc::new(move |point, entry| {
            if entry.logical.stage.is_checkpoint()
                && ((scenario == "CHECKPOINT_CRASH_BEFORE" && point == TestPoint::Entered)
                    || (scenario == "CHECKPOINT_CRASH_AFTER" && point == TestPoint::RemoteReply))
            {
                std::fs::write(
                    output.join("boundary.json"),
                    serde_json::to_vec(entry).unwrap(),
                )
                .unwrap();
                std::process::exit(if scenario.ends_with("BEFORE") { 75 } else { 76 });
            }
        }));
    }
    let mut waiting = 0;
    for round in 0..16 {
        let view = worker.snapshot(config.visit).await?;
        worker.recover(&view)?;
        if config.mode == "RECOVER" {
            if view.data().request_admission_allowed {
                return Err("recovery restored authority".into());
            }
            break;
        }
        if !view.data().progress.operations.is_empty()
            || view.data().process_checkpoint.waits.values().any(|w| {
                matches!(
                    w,
                    rx_process_contract::frontier::WaitProgress::TimedOut { .. }
                )
            })
            || waiting >= 3
        {
            break;
        }
        std::fs::write(
            config.output.join("resolved.json"),
            canonical::bytes(view.process())?,
        )?;
        std::fs::write(
            config.output.join("process.bt.xml"),
            rx_process::bt_xml::generate(view.process()).map_err(std::io::Error::other)?,
        )?;
        let frame_file = format!("frame-{round}.json");
        std::fs::write(
            config.output.join(&frame_file),
            canonical::bytes(&view.frame(&view.context_identity())?)?,
        )?;
        let result = std::process::Command::new("docker")
            .args([
                "run",
                "--rm",
                "--pull=never",
                "--network",
                "none",
                "--read-only",
                "--cap-drop",
                "ALL",
                "--security-opt",
                "no-new-privileges",
                "-v",
            ])
            .arg(format!("{}:/fixture:ro", config.output.display()))
            .args(["--entrypoint", "/build/executor/rx-bt-request-fixture"])
            .arg(&config.cpp_image)
            .args([
                "/fixture/resolved.json",
                "/fixture/process.bt.xml",
                &format!("/fixture/{frame_file}"),
                "test-clock",
                &clock.now()?.ticks_ns.0.to_string(),
            ])
            .output()?;
        if !result.status.success() {
            return Err(
                format!("C++ producer: {}", String::from_utf8_lossy(&result.stderr)).into(),
            );
        }
        std::fs::write(
            config.output.join(format!("requests-{round}.json")),
            &result.stdout,
        )?;
        let requests: Vec<Request> = canonical::decode_json(&result.stdout)?;
        if requests.is_empty() {
            return Err("BT stalled before expected decision/admission".into());
        }
        for request in requests {
            match worker.handle(request).await {
                Ok(Outcome::WaitingCondition) => waiting += 1,
                Ok(
                    Outcome::RefreshRequired
                    | Outcome::CheckpointObserved { .. }
                    | Outcome::CheckpointCommitted { .. }
                    | Outcome::Admitted(_)
                    | Outcome::ObservedOperation(_),
                ) => {}
                Err(Error::Rpc(status))
                    if matches!(
                        status.code(),
                        tonic::Code::Unavailable | tonic::Code::DeadlineExceeded
                    ) => {}
                other => return Err(format!("decision worker: {other:?}").into()),
            }
        }
    }
    let view = worker.snapshot(config.visit).await?;
    worker.recover(&view)?;
    let mut entries = vec![];
    let mut observations = vec![];
    for node in rx_process_contract::validation::nodes(view.process()) {
        for stage in [
            Stage::CheckpointBranch,
            Stage::CheckpointStartWait,
            Stage::CheckpointCheckWait,
            Stage::ResolveActivation,
            Stage::SubmitOperation,
        ] {
            let logical = Logical {
                node: node.id.clone(),
                visit: config.visit,
                stage,
                control: None,
            };
            if let Some(value) = worker.journal().get(&logical)? {
                entries.push(value);
            }
            if let Some(value) = worker.journal().observation(&logical)? {
                observations.push(value);
            }
        }
    }
    let attempts = worker.journal().test_attempts()?;
    std::fs::write(
        config.output.join("report.json"),
        serde_json::to_vec(
            &serde_json::json!({"work_count":view.data().progress.operations.len(),"admission":view.data().request_admission_allowed,"process_checkpoint":view.data().process_checkpoint,"entries":entries,"observations":observations,"attempts":attempts,"waiting":waiting}),
        )?,
    )?;
    Ok(())
}
