use super::*;
use super::{
    executor_peer::executor_scope,
    workflow::{begin_part_transition, resolve_activation_transition},
};
use crate::checkpoint_artifact::{ActivationSnapshot, activation_snapshot};
const PART_REPLY: &str = "rx.internal.part-attempt-reply.v1";
const ACTIVATION_REPLY: &str = "rx.internal.activation-reply.v1";
impl<R: Repository, C: Clock, A: QualificationAuthority> Engine<R, C, A> {
    pub fn executor_begin_part(
        &mut self,
        identity: &Identity,
        request_key: &str,
        command: BeginPartRequest,
    ) -> Result<PartSnapshot> {
        let clock = &self.clock;
        let meta = &self.installation;
        self.repository.transact(|tx| {
            let now = clock.now();
            let (principal, cell_revision, cell) = executor_scope(
                tx,
                ProcessingContext {
                    identity,
                    meta,
                    now: &now,
                },
                &command.cell,
            )?;
            let (revision, mut run): (_, Run) = load(tx, "run", &command.run, RUN)?;
            if run.cell != command.cell {
                return reject(Reject::InvalidInput);
            }
            let (scope, fingerprint) = request(
                meta,
                &principal,
                "Cell.BeginPartAttempt",
                request_key,
                &command,
            )?;
            if let Some(saved) = prior(tx, &scope, fingerprint, PART_REPLY)? {
                return Ok(saved);
            }
            if run.mandate.as_ref() != Some(&command.mandate) {
                return reject(Reject::MandateRevoked);
            }
            if let Some(expected) = command.expected_cell {
                check_revision(cell_revision, expected)?;
            }
            let result = begin_part_transition(
                tx,
                &cell,
                &mut run,
                revision,
                command.expected_budget,
                ProcessingContext {
                    identity,
                    meta,
                    now: &now,
                },
            )?;
            remember(tx, &scope, fingerprint, PART_REPLY, &result)?;
            Ok(result)
        })
    }
    pub fn executor_resolve_activation(
        &mut self,
        identity: &Identity,
        request_key: &str,
        command: ResolveActivationRequest,
    ) -> Result<ActivationSnapshot> {
        let clock = &self.clock;
        let meta = &self.installation;
        self.repository.transact(|tx| {
            let now = clock.now();
            let (revision, run): (_, Run) = load(tx, "run", &command.run, RUN)?;
            let (principal, _, _) = executor_scope(
                tx,
                ProcessingContext {
                    identity,
                    meta,
                    now: &now,
                },
                &run.cell,
            )?;
            let (scope, fingerprint) = request(
                meta,
                &principal,
                "Workflow.ResolveActivation",
                request_key,
                &command,
            )?;
            if let Some(saved) = prior(tx, &scope, fingerprint, ACTIVATION_REPLY)? {
                return Ok(saved);
            }
            let activation = resolve_activation_transition(
                tx,
                &run,
                revision,
                &command.node,
                command.visit,
                command.expected_run,
                ProcessingContext {
                    identity,
                    meta,
                    now: &now,
                },
            )?;
            let result = activation_snapshot(tx, &activation, &run.cell)?;
            remember(tx, &scope, fingerprint, ACTIVATION_REPLY, &result)?;
            Ok(result)
        })
    }
}
