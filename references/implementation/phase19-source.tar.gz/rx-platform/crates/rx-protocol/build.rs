use std::{env, path::PathBuf};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let root = PathBuf::from(env::var("CARGO_MANIFEST_DIR")?).join("../../proto");
    let output = PathBuf::from(env::var("OUT_DIR")?);
    let mut config = tonic_prost_build::Config::new();
    config.protoc_executable(protoc_bin_vendored::protoc_bin_path()?);
    config.enable_type_names();
    config.boxed(".rx.cell.v1.SnapshotEntity.value.base_entity");
    config.boxed(".rx.cell.v1.SnapshotEntity.value.cell_entity");
    tonic_prost_build::configure()
        .codec_path("crate::strict::StrictCodec")
        .file_descriptor_set_path(output.join("rx_descriptor.bin"))
        .compile_with_config(
            config,
            &[
                root.join("rx/contract/v1/contract.proto"),
                root.join("rx/cell/v1/cell.proto"),
            ],
            std::slice::from_ref(&root),
        )?;
    println!("cargo:rerun-if-changed={}", root.display());
    Ok(())
}
