use super::*;
#[tonic::async_trait]
impl cell::cell_service_server::CellService for PlatformIngress {
    async fn open(
        &self,
        request: Request<cell::CellHello>,
    ) -> Result<Response<cell::CellSession>, Status> {
        let (fingerprint, principal) = self.certificate(&request)?;
        let hello = request.into_inner();
        if hello.peer_id != principal.as_str()
            || hello.base_manifest_hash != base_hash()
            || hello.cell_manifest_hash != cell_hash()
            || hello.shared_clock_id != self.configuration.installation.clock_id
        {
            return Err(Status::failed_precondition(
                "cell manifest/peer/clock mismatch",
            ));
        }
        let identity = Identity {
            principal: principal.clone(),
            session: id(&hello.base_session_id)?,
            terminal: None,
        };
        let Reply::ServicePeer(peer) = self
            .call(Command::InspectServicePeer(identity.clone()))
            .await?
        else {
            return Err(Status::internal("service peer reply"));
        };
        let definition = digest(&hello.cell_definition_digest)?;
        let command = match peer {
            rx_application::ServicePeer::Host(producer) => {
                if producer.authentication_binding != self.authentication_binding(fingerprint)? {
                    return Err(Status::unauthenticated("session/certificate mismatch"));
                }
                Command::NegotiateEvidenceCell {
                    identity,
                    definition,
                }
            }
            rx_application::ServicePeer::Executor(executor) => {
                if executor.authentication_binding
                    != self.executor_authentication_binding(fingerprint)?
                {
                    return Err(Status::unauthenticated("session/certificate mismatch"));
                }
                Command::NegotiateExecutorCell {
                    identity,
                    definition,
                }
            }
        };
        let Reply::CellName(cell) = self.call(command).await? else {
            return Err(Status::internal("cell negotiation reply"));
        };
        let hash = canonical::digest(
            "RX-CELL-NEGOTIATION-v1",
            &(&hello.base_session_id, cell, definition),
        )
        .map_err(|_| Status::internal("cell negotiation identity"))?;
        let mut bytes = [0; 16];
        bytes.copy_from_slice(&hash.as_bytes()[..16]);
        bytes[6] = (bytes[6] & 15) | 0x80;
        bytes[8] = (bytes[8] & 63) | 0x80;
        Ok(Response::new(cell::CellSession {
            session_id: uuid::Uuid::from_bytes(bytes).to_string(),
            base_session_id: hello.base_session_id,
            peer_id: principal.to_string(),
            manifest_hash: cell_hash(),
        }))
    }

    async fn inspect(
        &self,
        _: Request<cell::CellCall>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn evaluate(
        &self,
        _: Request<cell::EvaluateRequest>,
    ) -> std::result::Result<Response<cell::EvaluationSet>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn start_run(
        &self,
        _: Request<cell::StartRunRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn get_start_attempt(
        &self,
        _: Request<cell::GetStartAttemptRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn begin_part_attempt(
        &self,
        _: Request<cell::BeginPartAttemptRequest>,
    ) -> std::result::Result<Response<cell::PartAttempt>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn submit_operation(
        &self,
        _: Request<cell::SubmitOperationRequest>,
    ) -> std::result::Result<Response<base::Receipt>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn hold(
        &self,
        _: Request<cell::HoldRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn clear_transient_block(
        &self,
        _: Request<cell::ClearTransientBlockRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn open_case(
        &self,
        _: Request<cell::OpenCaseRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn record_procedure(
        &self,
        _: Request<cell::RecordProcedureRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn set_recovery_plan(
        &self,
        _: Request<cell::SetRecoveryPlanRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn prepare_restart(
        &self,
        _: Request<cell::PrepareRestartRequest>,
    ) -> std::result::Result<Response<cell::RestartPreparation>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn get_restart_preparation(
        &self,
        _: Request<cell::GetRestartPreparationRequest>,
    ) -> std::result::Result<Response<cell::RestartPreparation>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn prepare_close(
        &self,
        _: Request<cell::PrepareCloseRequest>,
    ) -> std::result::Result<Response<cell::Clearance>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn restart_run(
        &self,
        _: Request<cell::RestartRunRequest>,
    ) -> std::result::Result<Response<cell::StartAttempt>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn close_without_restart(
        &self,
        _: Request<cell::CloseWithoutRestartRequest>,
    ) -> std::result::Result<Response<cell::CellContext>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn record_change(
        &self,
        _: Request<cell::RecordChangeRequest>,
    ) -> std::result::Result<Response<cell::ChangeRecord>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn register_qualification(
        &self,
        _: Request<cell::RegisterQualificationRequest>,
    ) -> std::result::Result<Response<cell::Qualification>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn get_case(
        &self,
        _: Request<cell::GetCaseRequest>,
    ) -> std::result::Result<Response<cell::InterventionCase>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }

    async fn get_material(
        &self,
        _: Request<cell::GetMaterialRequest>,
    ) -> std::result::Result<Response<cell::MaterialState>, Status> {
        Err(Status::unimplemented(
            "Only Cell.Open is enabled on this cell service binding",
        ))
    }
}
