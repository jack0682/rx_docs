use rx_domain::{canonical, intent::*, types::*};
use rx_host::{
    native::*,
    service::{self, config::*},
    simulation::*,
    *,
};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicU64, Ordering},
    },
    time::Duration,
};
fn name(s: &str) -> Name {
    Name::new(s).unwrap()
}
fn id() -> Id {
    Id::new(uuid::Uuid::new_v4().to_string()).unwrap()
}
fn pinned(root: &Path, label: &str, bytes: &[u8], secret: bool) -> PinnedFile {
    let path = root.join(label);
    std::fs::write(&path, bytes).unwrap();
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(
            &path,
            std::fs::Permissions::from_mode(if secret { 0o600 } else { 0o644 }),
        )
        .unwrap();
    }
    PinnedFile {
        path,
        sha256: rx_package::content_digest(bytes),
    }
}
fn fixture() -> (tempfile::TempDir, PathBuf, ManualClock) {
    use rcgen::*;
    let dir = tempfile::tempdir().unwrap();
    let root = dir.path();
    let mut params = CertificateParams::new(vec![]).unwrap();
    params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
    params
        .distinguished_name
        .push(DnType::CommonName, "RX Host Test CA");
    params.key_usages = vec![KeyUsagePurpose::KeyCertSign, KeyUsagePurpose::CrlSign];
    let ca = CertifiedIssuer::self_signed(params, KeyPair::generate().unwrap()).unwrap();
    let key = KeyPair::generate().unwrap();
    let mut params = CertificateParams::new(vec!["localhost".into(), "127.0.0.1".into()]).unwrap();
    params
        .distinguished_name
        .push(DnType::CommonName, "RX Host Test Server");
    params.key_usages = vec![KeyUsagePurpose::DigitalSignature];
    params.use_authority_key_identifier_extension = true;
    params.extended_key_usages = vec![ExtendedKeyUsagePurpose::ServerAuth];
    let cert = params.signed_by(&key, &ca).unwrap();
    let client_key = KeyPair::generate().unwrap();
    let mut client_params = CertificateParams::new(vec!["platform".into()]).unwrap();
    client_params
        .distinguished_name
        .push(DnType::CommonName, "RX Host Test Client");
    client_params.key_usages = vec![KeyUsagePurpose::DigitalSignature];
    client_params.use_authority_key_identifier_extension = true;
    client_params.extended_key_usages = vec![ExtendedKeyUsagePurpose::ClientAuth];
    let client = client_params.signed_by(&client_key, &ca).unwrap();
    pinned(root, "client.pem", client.pem().as_bytes(), false);
    pinned(
        root,
        "client.key",
        client_key.serialize_pem().as_bytes(),
        true,
    );

    let bindings = vec![Binding {
        host: name("host/sim"),
        platform: name("platform"),
        cell: name("cell/sim"),
        definition: ArtifactRef {
            sha256: Digest::from_bytes([3; 32]),
            schema_id: name("rx.cell-definition.v1"),
            size_bytes: Counter(1),
        },
        envelope: ArtifactRef {
            sha256: Digest::from_bytes([4; 32]),
            schema_id: name("rx.operating-envelope.v1"),
            size_bytes: Counter(1),
        },
        qualification: id(),
        qualification_revision: Counter(1),
        allowed_intents: vec![Intent {
            kind: Kind::EnsureState,
            target: name("sim/chuck"),
            profile_digest: Digest::from_bytes([1; 32]),
            site_config_digest: Digest::from_bytes([2; 32]),
            calibration_digests: vec![],
            resource_set: vec![name("sim/controller")],
            execution_timeout_ms: Counter(1000),
            prepare_validity_ms: Counter(1000),
            completion_rule: name("sim/closed"),
            cancel_rule: name("sim/stop"),
            body: Body::Predicate(PredicateGoal {
                predicate_id: name("closed"),
                target: TypedValue::Boolean(true),
                settle_ms: Counter(0),
            }),
        }],
        scope_ids: vec![name("scope/main")],
        condition_ids: vec![name("sim/ready")],
        environment: Environment::Simulation,
        purposes: BTreeSet::from([Purpose::Production]),
    }];
    let runtime = root.join("runtime");
    std::fs::create_dir(&runtime).unwrap();
    let config = Configuration {
        schema: name("rx.host-startup.v1"),
        installation: id(),
        release_digest: Digest::from_bytes([8; 32]),
        host: name("host/sim"),
        bind: "127.0.0.1:0".parse().unwrap(),
        data_directory: root.join("data"),
        runtime_directory: runtime,
        bindings: pinned(
            root,
            "bindings.json",
            &canonical::bytes(&bindings).unwrap(),
            false,
        ),
        backend: Backend::FileSimulation,
        tls: TlsFiles {
            certificate: pinned(root, "server.pem", cert.pem().as_bytes(), false),
            key: pinned(root, "server.key", key.serialize_pem().as_bytes(), true),
            ca: pinned(root, "ca.pem", ca.pem().as_bytes(), false),
        },
        allowed_platform_certificates: BTreeMap::from([(
            rx_package::content_digest(client.der().as_ref()),
            name("platform"),
        )]),
        publisher: None,
        publication_drain_ms: Counter(0),
    };
    let path = root.join("startup.json");
    std::fs::write(&path, canonical::bytes(&config).unwrap()).unwrap();
    (
        dir,
        path,
        ManualClock {
            clock_id: "test/service-clock".into(),
            ticks: Arc::new(AtomicU64::new(1000)),
        },
    )
}
async fn status(path: &Path, phase: &str) -> serde_json::Value {
    tokio::time::timeout(Duration::from_secs(5), async {
        loop {
            if let Ok(bytes) = std::fs::read(path) {
                let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
                if value["phase"] == phase {
                    return value;
                }
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .unwrap()
}
#[tokio::test]
async fn product_composition_has_immutable_installation_real_owner_and_clean_software_stop() {
    let (dir, file, clock) = fixture();
    let loaded = Loaded::read(&file).unwrap();
    service::initialize_with(&loaded, clock.clone(), &service::Builtin).unwrap();
    assert!(!loaded.config.data_directory.join("device").exists());
    assert!(service::initialize_with(&loaded, clock.clone(), &service::Builtin).is_err());
    let status_file = loaded.config.runtime_directory.join("host-status.json");
    let (stop, stopped) = tokio::sync::oneshot::channel();
    let c = clock.clone();
    let task = tokio::spawn(service::run_with(loaded, c, service::Builtin, async {
        let _ = stopped.await;
    }));
    let first = status(&status_file, "SOFTWARE_READY_UNARMED").await;
    assert_eq!(first["admission_open"], true);
    assert_eq!(first["qualification_or_arm_restored"], false);
    let duplicate = service::run_with(
        Loaded::read(&file).unwrap(),
        clock.clone(),
        service::Builtin,
        std::future::pending(),
    )
    .await;
    assert!(duplicate.is_err());
    stop.send(()).unwrap();
    tokio::time::timeout(Duration::from_secs(5), task)
        .await
        .unwrap()
        .unwrap()
        .unwrap();
    let stopped = status(&status_file, "STOPPED").await;
    assert_eq!(stopped["stop"]["safe_to_drop"], true);
    assert_eq!(stopped["stop"]["physical_shutdown_assessed"], false);
    assert!(!dir.path().join("data/device/effects.jsonl").exists());
    std::fs::remove_file(dir.path().join("data/host.db")).unwrap();
    assert!(
        service::run_with(
            Loaded::read(&file).unwrap(),
            clock,
            service::Builtin,
            std::future::pending()
        )
        .await
        .is_err()
    );
}
#[test]
fn startup_rejects_policy_tampering_unknown_fields_and_unimplemented_physical_backend() {
    let (dir, file, clock) = fixture();
    let loaded = Loaded::read(&file).unwrap();
    std::fs::write(&loaded.config.bindings.path, b"[]").unwrap();
    assert!(Loaded::read(&file).is_err());
    assert!(!dir.path().join("data").exists());
    let (_dir, file, clock2) = fixture();
    let mut value: serde_json::Value =
        serde_json::from_slice(&std::fs::read(&file).unwrap()).unwrap();
    value["ticks"] = serde_json::json!(1000);
    std::fs::write(&file, serde_json::to_vec(&value).unwrap()).unwrap();
    assert!(Loaded::read(&file).is_err());
    let _ = (clock, clock2);
    let (dir, file, clock) = fixture();
    let mut loaded = Loaded::read(&file).unwrap();
    loaded.config.backend = Backend::ValidatedDriver {
        profile: name("robotis/omy"),
        driver_digest: Digest::from_bytes([1; 32]),
    };
    assert!(service::initialize_with(&loaded, clock, &service::Builtin).is_err());
    assert!(!dir.path().join("data").exists());
}
struct Held {
    native: FileDevice,
    safe: Arc<AtomicBool>,
    dropped: Arc<AtomicBool>,
}
impl Drop for Held {
    fn drop(&mut self) {
        self.dropped.store(true, Ordering::SeqCst);
    }
}
impl NativeAdapter for Held {
    fn environment(&self) -> Environment {
        Environment::Simulation
    }
    fn protection(&self) -> Arc<dyn LocalProtection> {
        self.native.protection()
    }
    fn guard(&self, i: &Intent, t: &TimePoint) -> Result<Guard> {
        self.native.guard(i, t)
    }
    fn can_handover(&self, r: &[Name]) -> bool {
        self.native.can_handover(r)
    }
    fn shutdown_snapshot(&self, r: &[Name]) -> Result<NativeShutdown> {
        let mut v = self.native.shutdown_snapshot(r)?;
        v.safe_to_drop = self.safe.load(Ordering::SeqCst);
        Ok(v)
    }
    fn submit(&mut self, o: &Id, v: &Id, i: &Intent) -> Result<NativeCapture> {
        self.native.submit(o, v, i)
    }
    fn lookup(&mut self, o: &Id, v: &Id) -> Result<Option<NativeCapture>> {
        self.native.lookup(o, v)
    }
}
struct Factory {
    safe: Arc<AtomicBool>,
    dropped: Arc<AtomicBool>,
    opened: Arc<AtomicU64>,
}
impl service::AdapterFactory<ManualClock> for Factory {
    type Adapter = Held;
    fn validate(&self, b: &Backend, bindings: &[Binding]) -> service::Result<()> {
        <service::Builtin as service::AdapterFactory<ManualClock>>::validate(
            &service::Builtin,
            b,
            bindings,
        )
    }
    fn open_passive(&self, _: &Backend, p: &Path, c: ManualClock) -> service::Result<Held> {
        self.opened.fetch_add(1, Ordering::SeqCst);
        Ok(Held {
            native: FileDevice::open(p.join("device"), c)?,
            safe: self.safe.clone(),
            dropped: self.dropped.clone(),
        })
    }
}
#[tokio::test]
async fn normal_stop_retains_adapter_until_drop_permission_is_explicit() {
    let (_dir, file, clock) = fixture();
    let loaded = Loaded::read(&file).unwrap();
    let status_file = loaded.config.runtime_directory.join("host-status.json");
    let safe = Arc::new(AtomicBool::new(false));
    let dropped = Arc::new(AtomicBool::new(false));
    let opened = Arc::new(AtomicU64::new(0));
    let factory = Factory {
        safe: safe.clone(),
        dropped: dropped.clone(),
        opened: opened.clone(),
    };
    service::initialize_with(&loaded, clock.clone(), &factory).unwrap();
    assert_eq!(opened.load(Ordering::SeqCst), 0);
    let (stop, stopped) = tokio::sync::oneshot::channel();
    let task = tokio::spawn(service::run_with(loaded, clock, factory, async {
        let _ = stopped.await;
    }));
    status(&status_file, "SOFTWARE_READY_UNARMED").await;
    stop.send(()).unwrap();
    let waiting = status(&status_file, "STOP_WAITING_FOR_ADAPTER").await;
    assert_eq!(waiting["admission_open"], false);
    assert!(!dropped.load(Ordering::SeqCst));
    assert!(!task.is_finished());
    safe.store(true, Ordering::SeqCst);
    tokio::time::timeout(Duration::from_secs(5), task)
        .await
        .unwrap()
        .unwrap()
        .unwrap();
    assert!(dropped.load(Ordering::SeqCst));
}

#[test]
#[ignore = "exports isolated container fixture"]
fn export_host_image_fixture() {
    let (_dir, path, _clock) = fixture();
    let target = std::path::PathBuf::from(std::env::var("RX_HOST_IMAGE_FIXTURE").unwrap());
    assert!(!target.exists());
    std::fs::create_dir_all(&target).unwrap();
    let mut config: Configuration = canonical::decode_json(&std::fs::read(&path).unwrap()).unwrap();
    for file in [
        "bindings.json",
        "server.pem",
        "server.key",
        "ca.pem",
        "client.pem",
        "client.key",
    ] {
        std::fs::copy(path.parent().unwrap().join(file), target.join(file)).unwrap();
    }
    for file in [
        &mut config.bindings,
        &mut config.tls.certificate,
        &mut config.tls.key,
        &mut config.tls.ca,
    ] {
        file.path = PathBuf::from("/config").join(file.path.file_name().unwrap());
    }
    config.data_directory = PathBuf::from("/data/host");
    config.runtime_directory = PathBuf::from("/data/runtime");
    config.bind = "0.0.0.0:7444".parse().unwrap();
    std::fs::write(
        target.join("startup.json"),
        canonical::bytes(&config).unwrap(),
    )
    .unwrap();
}

#[tokio::test]
async fn empty_replacement_database_is_not_reinitialized_as_a_fresh_host() {
    use rx_ports::Repository;
    let (dir, file, clock) = fixture();
    let loaded = Loaded::read(&file).unwrap();
    service::initialize_with(&loaded, clock.clone(), &service::Builtin).unwrap();
    let db = dir.path().join("data/host.db");
    std::fs::remove_file(&db).unwrap();
    drop(rx_storage::SqliteRepository::open(&db).unwrap());
    assert!(
        service::run_with(
            Loaded::read(&file).unwrap(),
            clock,
            service::Builtin,
            std::future::pending()
        )
        .await
        .is_err()
    );
    let mut store = rx_storage::SqliteRepository::open(&db).unwrap();
    assert!(
        store
            .transact(|tx| tx.get(&name("host/meta")))
            .unwrap()
            .is_none()
    );
}
